from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

class PerformerArchetype(str, Enum):
    AMPLIFIER = "amplifier"
    REGULAR   = "regular"
    REGRESSOR = "regressor"

@dataclass
class SituationalPressure:
    elimination_game: bool = False
    series_deficit: int = 0
    overtime_frequency: float = 0.0
    hostile_venue_score: float = 0.0  # 0.0 to 1.0

@dataclass
class PerformerPressureDelta:
    pds_score: float = 0.0
    prior_playoff_experience: int = 0
    clutch_fg_percentage: float = 0.0
    fourth_quarter_delta: float = 0.0

@dataclass
class OrganizationalPressure:
    coach_tenure_security: float = 1.0  # 1.0 (Secure) to 0.0 (At risk)
    contract_year_count: int = 0
    ownership_urgency_signal: float = 0.0
    front_office_public_statements: float = 0.0

@dataclass
class MarketPressureSignal:
    line_movement_magnitude: float = 0.0
    opening_close_delta: float = 0.0
    handle_distribution: float = 0.5  # % of money on home
    steam_move_detected: bool = False

@dataclass
class NarrativePressureIndex:
    media_mention_volume: int = 0
    social_sentiment_score: float = 0.0  # -1.0 to 1.0
    injury_news_velocity: float = 0.0
    star_player_narrative_weight: float = 0.0

@dataclass
class PressureFeatureVector:
    # L1 Baselines
    elo_baseline_prob: float
    
    # L2 Pressure Classes
    situational: SituationalPressure = field(default_factory=SituationalPressure)
    performer_delta: PerformerPressureDelta = field(default_factory=PerformerPressureDelta)
    organizational: OrganizationalPressure = field(default_factory=OrganizationalPressure)
    market_signal: MarketPressureSignal = field(default_factory=MarketPressureSignal)
    narrative_index: NarrativePressureIndex = field(default_factory=NarrativePressureIndex)

    def to_array(self):
        """Flatten for ML ingestion"""
        return [
            self.elo_baseline_prob,
            float(self.situational.elimination_game),
            self.situational.series_deficit,
            self.performer_delta.pds_score,
            self.organizational.coach_tenure_security,
            self.market_signal.line_movement_magnitude,
            self.narrative_index.social_sentiment_score
        ]

class PressureFeatureEngine:
    def build_vector(self, game_data: Dict, baseline_prob: float) -> PressureFeatureVector:
        # Implementation would parse raw game_data into the dataclasses
        return PressureFeatureVector(elo_baseline_prob=baseline_prob)
