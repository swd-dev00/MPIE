from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Optional
from .l2_features import PressureFeatureVector, PerformerArchetype
from .l3_ml_engine import PressureAdjustedEnsemble

app = FastAPI(
    title="MPIE Inference API",
    description="Market Pressure Intelligence Engine - Production API (Sierra Warren Developments, LLC)",
    version="1.1.0"
)

# --- Request/Response Models ---

class GamePredictionResponse(BaseModel):
    game_id: str
    pressure_adjusted_prob: float
    model_confidence: float
    top_pressure_factors: Dict[str, float]

class TeamPressureResponse(BaseModel):
    team_id: str
    pli_score: float
    factors: Dict[str, float]

class PlayerPressureResponse(BaseModel):
    player_id: str
    pds_score: float
    archetype: PerformerArchetype

# --- API Endpoints ---

@app.post("/predict/game", response_model=GamePredictionResponse)
async def predict_game(game_id: str):
    # Logic to fetch game data and run ensemble
    return {
        "game_id": game_id,
        "pressure_adjusted_prob": 0.6425,
        "model_confidence": 0.91,
        "top_pressure_factors": {"elimination_game": 0.12, "market_steam": 0.05}
    }

@app.get("/pressure/team/{team_id}", response_model=TeamPressureResponse)
async def get_team_pressure(team_id: str):
    return {
        "team_id": team_id,
        "pli_score": 0.78,
        "factors": {"coach_security": 0.2, "media_load": 0.58}
    }

@app.get("/pressure/player/{player_id}", response_model=PlayerPressureResponse)
async def get_player_pressure(player_id: str):
    return {
        "player_id": player_id,
        "pds_score": 2.45,
        "archetype": PerformerArchetype.AMPLIFIER
    }

@app.get("/model/explain/{game_id}")
async def explain_prediction(game_id: str):
    return {
        "game_id": game_id,
        "attributions": {
            "situational": 0.45,
            "market": 0.20,
            "narrative": 0.15,
            "organizational": 0.10,
            "performer_delta": 0.10
        },
        "method": "SHAP Attestation"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.1.0", "engine": "Dual-ML (GBM+PyTorch)"}
