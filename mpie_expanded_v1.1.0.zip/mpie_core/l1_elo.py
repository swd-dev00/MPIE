import math
from dataclasses import dataclass

@dataclass
class EloState:
    team_id: str
    current_elo: float
    season_starting_elo: float
    rolling_mov: float

class EloModel:
    HOME_ADVANTAGE = 65.0
    K_BASE = 20.0
    MOV_SCALE = 0.001

    def baseline_win_prob(self, home: EloState, away: EloState, neutral_site: bool = False) -> float:
        hfa = 0.0 if neutral_site else self.HOME_ADVANTAGE
        rating_diff = (home.current_elo - away.current_elo) + hfa
        prob = 1.0 / (1.0 + math.pow(10.0, -rating_diff / 400.0))
        return round(prob, 6)
