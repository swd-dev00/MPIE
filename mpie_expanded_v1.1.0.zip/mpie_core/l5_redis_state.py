import json
import redis

class MPIEStateManager:
    def __init__(self, host="redis-cluster", port=6379):
        self.client = redis.Redis(host=host, port=port, decode_responses=True)

    def set_prediction_cache(self, game_id, data):
        self.client.setex(f"mpie:pred:{game_id}", 300, json.dumps(data))
