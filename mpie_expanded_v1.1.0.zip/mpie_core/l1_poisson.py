import math
from dataclasses import dataclass

@dataclass
class PoissonBaseline:
    lambda_home: float
    lambda_away: float
    p_home_win: float
    p_draw: float
    p_away_win: float
    max_goals: int = 10

class PoissonDixonColes:
    def _dc_correction(self, goals_h: int, goals_a: int, lh: float, la: float, rho: float = -0.13) -> float:
        if goals_h == 0 and goals_a == 0: return 1.0 - lh * la * rho
        elif goals_h == 0 and goals_a == 1: return 1.0 + lh * rho
        elif goals_h == 1 and goals_a == 0: return 1.0 + la * rho
        elif goals_h == 1 and goals_a == 1: return 1.0 - rho
        return 1.0

    def _poisson_pmf(self, k: int, lam: float) -> float:
        return (math.exp(-lam) * math.pow(lam, k)) / math.factorial(k)
