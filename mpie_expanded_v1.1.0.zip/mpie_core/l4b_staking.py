def calculate_fractional_kelly(model_prob: float, decimal_odds: float, bankroll: float, alpha: float = 0.25):
    if model_prob <= 0: return 0.0
    b = decimal_odds - 1.0
    q = 1.0 - model_prob
    f_star = ((b * model_prob) - q) / b
    if f_star <= 0: return 0.0
    
    f = alpha * f_star
    raw_stake = f * bankroll
    return round(min(raw_stake, 1000.0, bankroll * 0.05), 2)
