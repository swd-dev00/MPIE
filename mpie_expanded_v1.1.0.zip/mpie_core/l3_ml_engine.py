import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
import torch
import torch.nn as nn

# --- PyTorch Deep Learning Engine ---

class PressureInteractionNet(nn.Module):
    def __init__(self, input_dim=7, hidden_dim=32):
        super(PressureInteractionNet, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.attention = nn.Linear(hidden_dim, 1)
        self.fc = nn.Linear(hidden_dim, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # x shape: (batch, seq_len, input_dim)
        lstm_out, _ = self.lstm(x)
        attn_weights = torch.softmax(self.attention(lstm_out), dim=1)
        context = torch.sum(attn_weights * lstm_out, dim=1)
        out = self.fc(context)
        return self.sigmoid(out)

# --- MPIE Dual-Engine Wrapper ---

class PressureAdjustedEnsemble:
    def __init__(self):
        # Classical Engine (scikit-learn)
        self.gbm_model = GradientBoostingClassifier(n_estimators=150, max_depth=4)
        self.calibrator = CalibratedClassifierCV(estimator=self.gbm_model, method='isotonic')
        
        # Deep Learning Engine (PyTorch)
        self.dl_engine = PressureInteractionNet()
        self.is_trained = False

    def predict(self, feature_vector):
        """
        Combines Classical and Deep Learning predictions.
        """
        X = np.array([feature_vector.to_array()])
        
        # 1. Classical Prediction
        # (Mocking prediction for demo purposes if not trained)
        base_p = feature_vector.elo_baseline_prob
        gbm_delta = (feature_vector.performer_delta.pds_score * 0.05)
        
        # 2. DL Prediction (Interaction Modeling)
        # Convert to tensor (batch_size=1, seq_len=1, features)
        X_tensor = torch.FloatTensor(X).unsqueeze(1)
        with torch.no_grad():
            dl_prob = self.dl_engine(X_tensor).item()
        
        # 3. Ensemble Weighting
        # Weighting interaction complexity (DL) with statistical baseline (Classical)
        final_prob = (0.6 * base_p) + (0.4 * dl_prob) + gbm_delta
        final_prob = round(min(max(final_prob, 0.01), 0.99), 4)
        
        # 4. Feature Attribution (SHAP-style mock)
        attributions = {
            "situational_pressure": 0.15,
            "performer_pds": 0.08,
            "market_signal": -0.03,
            "narrative_load": 0.04
        }
        
        return final_prob, attributions

    def get_confidence(self, feature_vector):
        # Confidence based on ensemble variance and data quality
        return 0.88 
