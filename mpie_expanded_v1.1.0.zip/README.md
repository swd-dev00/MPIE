# Market Pressure Intelligence Engine (MPIE)

**Architect:** Sierra N. Warren, M.Eng.  
**Organization:** Sierra Warren Developments, LLC  
**Status:** Active Development | Proprietary & Confidential  

## Executive Summary
The Market Pressure Intelligence Engine (MPIE) is a proprietary predictive modeling system developed by Sierra Warren Developments, LLC. It is designed to forecast sports market outcomes by quantifying **pressure** as a primary analytical variable. 

MPIE extends beyond conventional statistical approaches by modeling the compounding situational, psychological, and contextual forces that determine performance in high-stakes competitive environments.

## Core Thesis
> "Pressure is not noise — it is signal."

Standard sports models treat psychological and situational load as variance to be filtered. MPIE treats it as a primary predictive feature class with measurable, computable structure.

## Technical Architecture (6-Layer Stack)

| Layer | Function | Component |
| :--- | :--- | :--- |
| **L1 — Data Ingestion** | Real-time and historical sports data collection | `mpie_core/l1_elo.py`, `mpie_core/l1_poisson.py` |
| **L2 — Pressure Features** | Computes pressure feature classes from raw inputs | `mpie_core/l2_features.py` |
| **L3 — ML Prediction** | Dual-engine: scikit-learn (Classical) + PyTorch (DL) | `mpie_core/l3_ml_engine.py` |
| **L4 — Inference API** | FastAPI service for real-time predictions | `mpie_core/l4_api.py`, `mpie_core/l4b_staking.py` |
| **L5 — Caching & State** | Redis layer for high-frequency data | `mpie_core/l5_redis_state.py` |
| **L6 — Orchestration** | Kubernetes deployment management | `kubernetes/mpie-inference.yaml` |

## Dual-Engine ML Architecture
MPIE deploys a dual-engine prediction architecture:
1.  **Classical Engine (scikit-learn):** Gradient Boosted Decision Trees for base outcome prediction and probability calibration.
2.  **Deep Learning Engine (PyTorch):** LSTM-based sequence models with attention mechanisms to capture temporal pressure dynamics and interaction complexity.

## Pressure Feature Classes
The system models five primary pressure feature classes:
- **Situational Pressure:** Game-state and series-position factors.
- **Performer Historical Pressure Delta:** Individual player's measured response to stakes (PDS score).
- **Organizational Pressure Load:** Front-office and coaching-level pressure transmission.
- **Market Pressure Signal:** Information embedded in betting line movement and handle distribution.
- **Narrative Pressure Index:** Quantified media and public attention load.

## Governance & Accountability
MPIE is designed to integrate with the **Glass Substrate Protocol (GSP)** for cryptographic AI accountability, providing an audit trail for every prediction generated.

---
*© 2025–2026 Sierra Warren Developments, LLC. All Rights Reserved.*
