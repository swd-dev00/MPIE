export type League = "NBA" | "NFL" | "MLB" | "WNBA";
export type GameStatus = "LIVE" | "UPCOMING" | "FINAL";

export type MpieHealth = {
  status: "ok";
  mode: "demo" | "clickhouse";
  version: string;
};

export type PressureFactor = {
  label: string;
  shortLabel: string;
  impact: number;
  detail: string;
};

export type OddsAvailability = "ACTIVE" | "STALE" | "SUSPENDED";

export type BookmakerQuote = {
  bookmakerKey: string;
  bookmakerTitle: string;
  marketKey: string;
  marketName: string;
  outcome: string;
  decimalOdds: number;
  impliedProbability: number;
  lastUpdatedAt: string;
  status: OddsAvailability;
  isBestPrice: boolean;
  differenceFromConsensusPct: number;
};

export type MarketPriceResponse = {
  eventId: string;
  marketKey: string;
  marketName: string;
  outcome: string;
  bestBookmakerKey?: string | null;
  bestBookmakerTitle?: string | null;
  bestDecimalOdds?: number | null;
  consensusDecimalOdds?: number | null;
  quoteCount: number;
  quotes: BookmakerQuote[];
};

export type MpieGame = {
  id: string;
  league: League;
  status: GameStatus;
  startAt: string;
  venue: string;
  home: {
    name: string;
    city: string;
    abbreviation: string;
    record: string;
    score?: number;
  };
  away: {
    name: string;
    city: string;
    abbreviation: string;
    record: string;
    score?: number;
  };
  pick: string;
  pickSide: "home" | "away";
  market: string;
  marketKey: string;
  outcome: string;
  decimalOdds: number;
  impliedProbability: number;
  bestBookmakerKey?: string | null;
  bestBookmakerTitle?: string | null;
  oddsUpdatedAt?: string | null;
  oddsStatus: OddsAvailability;
  consensusDecimalOdds?: number | null;
  bookmakerCount: number;
  differenceFromConsensusPct: number;
  modelVersion: string;
  calculatedAt?: string | null;
  modelProbability: number;
  baselineProbability: number;
  edge: number;
  confidence: number;
  pressureIndex: number;
  projectedReturn: number;
  factors: PressureFactor[];
  insight: string;
};

export const games: MpieGame[] = [
  {
    "id": "bos-ny-0710",
    "league": "MLB",
    "status": "UPCOMING",
    "startAt": "2026-07-10T19:05:00-04:00",
    "venue": "Yankee Stadium",
    "home": {
      "name": "Yankees",
      "city": "New York",
      "abbreviation": "NYY",
      "record": "53–38"
    },
    "away": {
      "name": "Red Sox",
      "city": "Boston",
      "abbreviation": "BOS",
      "record": "49–42"
    },
    "pick": "Boston ML",
    "pickSide": "away",
    "market": "Moneyline",
    "decimalOdds": 2.1,
    "impliedProbability": 0.4762,
    "modelProbability": 0.574,
    "baselineProbability": 0.526,
    "edge": 0.093,
    "confidence": 0.86,
    "pressureIndex": 82,
    "projectedReturn": 110.0,
    "insight": "Boston's late-inning bullpen form and New York's compressed recovery window create the strongest pressure-adjusted value on today's board.",
    "factors": [
      {
        "label": "Bullpen fatigue",
        "shortLabel": "Fatigue",
        "impact": 0.071,
        "detail": "New York used four high-leverage relievers in the previous 36 hours."
      },
      {
        "label": "Travel compression",
        "shortLabel": "Travel",
        "impact": 0.038,
        "detail": "Boston enters with the cleaner recovery profile despite the road designation."
      },
      {
        "label": "Market resistance",
        "shortLabel": "Market",
        "impact": -0.016,
        "detail": "Price movement has partially absorbed the model advantage."
      },
      {
        "label": "Lineup continuity",
        "shortLabel": "Lineup",
        "impact": 0.024,
        "detail": "Boston's projected order has the higher continuity score."
      }
    ],
    "marketKey": "h2h",
    "outcome": "Boston",
    "bestBookmakerKey": "draftkings",
    "bestBookmakerTitle": "DraftKings",
    "oddsUpdatedAt": "2026-07-11T00:14:00Z",
    "oddsStatus": "ACTIVE",
    "consensusDecimalOdds": 2.076412,
    "bookmakerCount": 4,
    "differenceFromConsensusPct": 1.136,
    "modelVersion": "demo-pressure-v1.1.2",
    "calculatedAt": "2026-07-11T00:14:00Z"
  },
  {
    "id": "lv-sea-0710",
    "league": "WNBA",
    "status": "LIVE",
    "startAt": "2026-07-10T22:00:00-04:00",
    "venue": "Climate Pledge Arena",
    "home": {
      "name": "Storm",
      "city": "Seattle",
      "abbreviation": "SEA",
      "record": "14–9",
      "score": 54
    },
    "away": {
      "name": "Aces",
      "city": "Las Vegas",
      "abbreviation": "LVA",
      "record": "16–7",
      "score": 58
    },
    "pick": "Las Vegas -2.5",
    "pickSide": "away",
    "market": "Spread",
    "decimalOdds": 1.95,
    "impliedProbability": 0.5128,
    "modelProbability": 0.603,
    "baselineProbability": 0.557,
    "edge": 0.079,
    "confidence": 0.82,
    "pressureIndex": 78,
    "projectedReturn": 95.0,
    "insight": "Las Vegas is sustaining offensive efficiency under elevated pace while Seattle's rotation is showing late-quarter load sensitivity.",
    "factors": [
      {
        "label": "Rotation load",
        "shortLabel": "Load",
        "impact": 0.052,
        "detail": "Seattle's primary rotation has accumulated a materially higher workload."
      },
      {
        "label": "Clutch efficiency",
        "shortLabel": "Clutch",
        "impact": 0.041,
        "detail": "Las Vegas grades better in final-five-minute possession quality."
      },
      {
        "label": "Home environment",
        "shortLabel": "Venue",
        "impact": -0.022,
        "detail": "Seattle's home-court effect reduces the net model edge."
      }
    ],
    "marketKey": "spreads",
    "outcome": "Las Vegas -2.5",
    "bestBookmakerKey": "fanduel",
    "bestBookmakerTitle": "FanDuel",
    "oddsUpdatedAt": "2026-07-11T00:15:05Z",
    "oddsStatus": "ACTIVE",
    "consensusDecimalOdds": 1.929881,
    "bookmakerCount": 4,
    "differenceFromConsensusPct": 1.042,
    "modelVersion": "demo-pressure-v1.1.2",
    "calculatedAt": "2026-07-11T00:15:05Z"
  },
  {
    "id": "la-sf-0711",
    "league": "MLB",
    "status": "UPCOMING",
    "startAt": "2026-07-11T21:15:00-04:00",
    "venue": "Oracle Park",
    "home": {
      "name": "Giants",
      "city": "San Francisco",
      "abbreviation": "SF",
      "record": "47–44"
    },
    "away": {
      "name": "Dodgers",
      "city": "Los Angeles",
      "abbreviation": "LAD",
      "record": "58–34"
    },
    "pick": "Under 7.5",
    "pickSide": "home",
    "market": "Total",
    "decimalOdds": 2.0,
    "impliedProbability": 0.5,
    "modelProbability": 0.578,
    "baselineProbability": 0.541,
    "edge": 0.065,
    "confidence": 0.77,
    "pressureIndex": 71,
    "projectedReturn": 100.0,
    "insight": "Park suppression, starter command, and a low-variance weather profile combine to pull the projected run environment below market.",
    "factors": [
      {
        "label": "Park suppression",
        "shortLabel": "Park",
        "impact": 0.046,
        "detail": "The venue's run-suppression profile is amplified by the projected conditions."
      },
      {
        "label": "Starter command",
        "shortLabel": "Command",
        "impact": 0.033,
        "detail": "Both projected starters carry above-average command stability."
      },
      {
        "label": "Bullpen uncertainty",
        "shortLabel": "Bullpen",
        "impact": -0.014,
        "detail": "Recent relief volatility keeps confidence below elite range."
      }
    ],
    "marketKey": "totals",
    "outcome": "Under 7.5",
    "bestBookmakerKey": "caesars",
    "bestBookmakerTitle": "Caesars",
    "oddsUpdatedAt": "2026-07-11T00:15:00Z",
    "oddsStatus": "ACTIVE",
    "consensusDecimalOdds": 1.976415,
    "bookmakerCount": 4,
    "differenceFromConsensusPct": 1.193,
    "modelVersion": "demo-pressure-v1.1.2",
    "calculatedAt": "2026-07-11T00:15:00Z"
  },
  {
    "id": "kc-det-0711",
    "league": "MLB",
    "status": "UPCOMING",
    "startAt": "2026-07-11T18:10:00-04:00",
    "venue": "Comerica Park",
    "home": {
      "name": "Tigers",
      "city": "Detroit",
      "abbreviation": "DET",
      "record": "55–36"
    },
    "away": {
      "name": "Royals",
      "city": "Kansas City",
      "abbreviation": "KC",
      "record": "46–45"
    },
    "pick": "Detroit ML",
    "pickSide": "home",
    "market": "Moneyline",
    "decimalOdds": 1.78,
    "impliedProbability": 0.5618,
    "modelProbability": 0.632,
    "baselineProbability": 0.597,
    "edge": 0.057,
    "confidence": 0.74,
    "pressureIndex": 68,
    "projectedReturn": 78.0,
    "insight": "Detroit's home leverage and matchup-specific contact profile outweigh Kansas City's recent form bump.",
    "factors": [
      {
        "label": "Contact quality",
        "shortLabel": "Contact",
        "impact": 0.039,
        "detail": "Detroit's projected lineup owns the stronger hard-contact matchup."
      },
      {
        "label": "Home leverage",
        "shortLabel": "Home",
        "impact": 0.027,
        "detail": "The venue and last-at-bat state improve late-game win probability."
      },
      {
        "label": "Form regression",
        "shortLabel": "Form",
        "impact": -0.011,
        "detail": "Kansas City's recent streak carries some sustainable signal."
      }
    ],
    "marketKey": "h2h",
    "outcome": "Detroit",
    "bestBookmakerKey": "betmgm",
    "bestBookmakerTitle": "BetMGM",
    "oddsUpdatedAt": "2026-07-11T00:14:57Z",
    "oddsStatus": "ACTIVE",
    "consensusDecimalOdds": 1.757392,
    "bookmakerCount": 4,
    "differenceFromConsensusPct": 1.286,
    "modelVersion": "demo-pressure-v1.1.2",
    "calculatedAt": "2026-07-11T00:14:57Z"
  },
  {
    "id": "chi-min-0711",
    "league": "WNBA",
    "status": "UPCOMING",
    "startAt": "2026-07-11T20:00:00-04:00",
    "venue": "Target Center",
    "home": {
      "name": "Lynx",
      "city": "Minnesota",
      "abbreviation": "MIN",
      "record": "18–5"
    },
    "away": {
      "name": "Sky",
      "city": "Chicago",
      "abbreviation": "CHI",
      "record": "8–15"
    },
    "pick": "Minnesota -8.5",
    "pickSide": "home",
    "market": "Spread",
    "decimalOdds": 1.94,
    "impliedProbability": 0.5155,
    "modelProbability": 0.581,
    "baselineProbability": 0.552,
    "edge": 0.055,
    "confidence": 0.71,
    "pressureIndex": 64,
    "projectedReturn": 94.0,
    "insight": "Minnesota's pressure advantage is broad, but the current number leaves less margin than the matchup alone suggests.",
    "factors": [
      {
        "label": "Defensive continuity",
        "shortLabel": "Defense",
        "impact": 0.043,
        "detail": "Minnesota's primary units maintain elite communication and switch stability."
      },
      {
        "label": "Rest advantage",
        "shortLabel": "Rest",
        "impact": 0.025,
        "detail": "Chicago enters the more compressed segment of its schedule."
      },
      {
        "label": "Price efficiency",
        "shortLabel": "Price",
        "impact": -0.026,
        "detail": "The spread already reflects much of the talent gap."
      }
    ],
    "marketKey": "spreads",
    "outcome": "Minnesota -8.5",
    "bestBookmakerKey": "draftkings",
    "bestBookmakerTitle": "DraftKings",
    "oddsUpdatedAt": "2026-07-11T00:15:02Z",
    "oddsStatus": "ACTIVE",
    "consensusDecimalOdds": 1.9232,
    "bookmakerCount": 4,
    "differenceFromConsensusPct": 0.874,
    "modelVersion": "demo-pressure-v1.1.2",
    "calculatedAt": "2026-07-11T00:15:02Z"
  }
];

export type PortfolioPosition = {
  id: string;
  eventId?: string;
  marketKey?: string;
  outcome?: string;
  label: string;
  game: string;
  stake: number;
  odds: number;
  bookmakerKey?: string | null;
  bookmakerTitle?: string | null;
  status: string;
  pnl: number;
  openedAt?: string;
};


export type MpiePlaybookEntry = {
  id: string;
  title: string;
  bodyMarkdown: string;
  createdAt: string;
  updatedAt: string;
};

export type PressureSignal = {
  id: string;
  eventId?: string;
  title: string;
  subtitle: string;
  value: string;
  strength: number;
  direction: "positive" | "negative";
  detail: string;
  severity?: "INFO" | "WARNING" | "CRITICAL";
  triggeredAt?: string;
};

export const portfolioPositions: PortfolioPosition[] = [
  {
    "id": "p1",
    "label": "Boston ML",
    "game": "BOS @ NYY",
    "stake": 42,
    "odds": 2.08,
    "status": "Open",
    "pnl": 0,
    "bookmakerKey": "draftkings",
    "bookmakerTitle": "DraftKings"
  },
  {
    "id": "p2",
    "label": "Las Vegas -2.5",
    "game": "LVA @ SEA",
    "stake": 35,
    "odds": 1.91,
    "status": "Live",
    "pnl": 8.6,
    "bookmakerKey": "fanduel",
    "bookmakerTitle": "FanDuel"
  },
  {
    "id": "p3",
    "label": "Under 8.0",
    "game": "ATL @ PHI",
    "stake": 28,
    "odds": 1.94,
    "status": "Won",
    "pnl": 26.32,
    "bookmakerKey": "caesars",
    "bookmakerTitle": "Caesars"
  }
];

export const marketPriceBoards: Record<string, MarketPriceResponse> = {
  "bos-ny-0710": {
    "eventId": "bos-ny-0710",
    "marketKey": "h2h",
    "marketName": "Moneyline",
    "outcome": "Boston",
    "bestBookmakerKey": "draftkings",
    "bestBookmakerTitle": "DraftKings",
    "bestDecimalOdds": 2.1,
    "consensusDecimalOdds": 2.076412,
    "quoteCount": 4,
    "quotes": [
      {
        "bookmakerKey": "draftkings",
        "bookmakerTitle": "DraftKings",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Boston",
        "decimalOdds": 2.1,
        "impliedProbability": 0.4762,
        "lastUpdatedAt": "2026-07-11T00:14:00Z",
        "status": "ACTIVE",
        "isBestPrice": true,
        "differenceFromConsensusPct": 1.136
      },
      {
        "bookmakerKey": "fanduel",
        "bookmakerTitle": "FanDuel",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Boston",
        "decimalOdds": 2.08,
        "impliedProbability": 0.4808,
        "lastUpdatedAt": "2026-07-11T00:13:35Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": 0.173
      },
      {
        "bookmakerKey": "betmgm",
        "bookmakerTitle": "BetMGM",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Boston",
        "decimalOdds": 2.05,
        "impliedProbability": 0.4878,
        "lastUpdatedAt": "2026-07-11T00:12:55Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.272
      },
      {
        "bookmakerKey": "caesars",
        "bookmakerTitle": "Caesars",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Boston",
        "decimalOdds": 2.06,
        "impliedProbability": 0.4854,
        "lastUpdatedAt": "2026-07-10T23:58:00Z",
        "status": "STALE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -0.79
      }
    ]
  },
  "lv-sea-0710": {
    "eventId": "lv-sea-0710",
    "marketKey": "spreads",
    "marketName": "Spread",
    "outcome": "Las Vegas -2.5",
    "bestBookmakerKey": "fanduel",
    "bestBookmakerTitle": "FanDuel",
    "bestDecimalOdds": 1.95,
    "consensusDecimalOdds": 1.929881,
    "quoteCount": 4,
    "quotes": [
      {
        "bookmakerKey": "fanduel",
        "bookmakerTitle": "FanDuel",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Las Vegas -2.5",
        "decimalOdds": 1.95,
        "impliedProbability": 0.5128,
        "lastUpdatedAt": "2026-07-11T00:15:05Z",
        "status": "ACTIVE",
        "isBestPrice": true,
        "differenceFromConsensusPct": 1.042
      },
      {
        "bookmakerKey": "draftkings",
        "bookmakerTitle": "DraftKings",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Las Vegas -2.5",
        "decimalOdds": 1.93,
        "impliedProbability": 0.5181,
        "lastUpdatedAt": "2026-07-11T00:14:52Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": 0.006
      },
      {
        "bookmakerKey": "betmgm",
        "bookmakerTitle": "BetMGM",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Las Vegas -2.5",
        "decimalOdds": 1.91,
        "impliedProbability": 0.5236,
        "lastUpdatedAt": "2026-07-11T00:14:11Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.03
      },
      {
        "bookmakerKey": "caesars",
        "bookmakerTitle": "Caesars",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Las Vegas -2.5",
        "decimalOdds": 1.9,
        "impliedProbability": 0.5263,
        "lastUpdatedAt": "2026-07-10T23:59:00Z",
        "status": "STALE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.548
      }
    ]
  },
  "la-sf-0711": {
    "eventId": "la-sf-0711",
    "marketKey": "totals",
    "marketName": "Total",
    "outcome": "Under 7.5",
    "bestBookmakerKey": "caesars",
    "bestBookmakerTitle": "Caesars",
    "bestDecimalOdds": 2.0,
    "consensusDecimalOdds": 1.976415,
    "quoteCount": 4,
    "quotes": [
      {
        "bookmakerKey": "caesars",
        "bookmakerTitle": "Caesars",
        "marketKey": "totals",
        "marketName": "Total",
        "outcome": "Under 7.5",
        "decimalOdds": 2.0,
        "impliedProbability": 0.5,
        "lastUpdatedAt": "2026-07-11T00:15:00Z",
        "status": "ACTIVE",
        "isBestPrice": true,
        "differenceFromConsensusPct": 1.193
      },
      {
        "bookmakerKey": "draftkings",
        "bookmakerTitle": "DraftKings",
        "marketKey": "totals",
        "marketName": "Total",
        "outcome": "Under 7.5",
        "decimalOdds": 1.98,
        "impliedProbability": 0.5051,
        "lastUpdatedAt": "2026-07-11T00:14:45Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": 0.181
      },
      {
        "bookmakerKey": "fanduel",
        "bookmakerTitle": "FanDuel",
        "marketKey": "totals",
        "marketName": "Total",
        "outcome": "Under 7.5",
        "decimalOdds": 1.95,
        "impliedProbability": 0.5128,
        "lastUpdatedAt": "2026-07-11T00:14:19Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.336
      },
      {
        "bookmakerKey": "betmgm",
        "bookmakerTitle": "BetMGM",
        "marketKey": "totals",
        "marketName": "Total",
        "outcome": "Under 7.5",
        "decimalOdds": 1.94,
        "impliedProbability": 0.5155,
        "lastUpdatedAt": "2026-07-11T00:13:12Z",
        "status": "SUSPENDED",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.842
      }
    ]
  },
  "kc-det-0711": {
    "eventId": "kc-det-0711",
    "marketKey": "h2h",
    "marketName": "Moneyline",
    "outcome": "Detroit",
    "bestBookmakerKey": "betmgm",
    "bestBookmakerTitle": "BetMGM",
    "bestDecimalOdds": 1.78,
    "consensusDecimalOdds": 1.757392,
    "quoteCount": 4,
    "quotes": [
      {
        "bookmakerKey": "betmgm",
        "bookmakerTitle": "BetMGM",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Detroit",
        "decimalOdds": 1.78,
        "impliedProbability": 0.5618,
        "lastUpdatedAt": "2026-07-11T00:14:57Z",
        "status": "ACTIVE",
        "isBestPrice": true,
        "differenceFromConsensusPct": 1.286
      },
      {
        "bookmakerKey": "caesars",
        "bookmakerTitle": "Caesars",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Detroit",
        "decimalOdds": 1.76,
        "impliedProbability": 0.5682,
        "lastUpdatedAt": "2026-07-11T00:14:33Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": 0.148
      },
      {
        "bookmakerKey": "draftkings",
        "bookmakerTitle": "DraftKings",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Detroit",
        "decimalOdds": 1.75,
        "impliedProbability": 0.5714,
        "lastUpdatedAt": "2026-07-11T00:14:01Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -0.421
      },
      {
        "bookmakerKey": "fanduel",
        "bookmakerTitle": "FanDuel",
        "marketKey": "h2h",
        "marketName": "Moneyline",
        "outcome": "Detroit",
        "decimalOdds": 1.74,
        "impliedProbability": 0.5747,
        "lastUpdatedAt": "2026-07-11T00:13:40Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -0.99
      }
    ]
  },
  "chi-min-0711": {
    "eventId": "chi-min-0711",
    "marketKey": "spreads",
    "marketName": "Spread",
    "outcome": "Minnesota -8.5",
    "bestBookmakerKey": "draftkings",
    "bestBookmakerTitle": "DraftKings",
    "bestDecimalOdds": 1.94,
    "consensusDecimalOdds": 1.9232,
    "quoteCount": 4,
    "quotes": [
      {
        "bookmakerKey": "draftkings",
        "bookmakerTitle": "DraftKings",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Minnesota -8.5",
        "decimalOdds": 1.94,
        "impliedProbability": 0.5155,
        "lastUpdatedAt": "2026-07-11T00:15:02Z",
        "status": "ACTIVE",
        "isBestPrice": true,
        "differenceFromConsensusPct": 0.874
      },
      {
        "bookmakerKey": "caesars",
        "bookmakerTitle": "Caesars",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Minnesota -8.5",
        "decimalOdds": 1.92,
        "impliedProbability": 0.5208,
        "lastUpdatedAt": "2026-07-11T00:14:48Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -0.166
      },
      {
        "bookmakerKey": "fanduel",
        "bookmakerTitle": "FanDuel",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Minnesota -8.5",
        "decimalOdds": 1.91,
        "impliedProbability": 0.5236,
        "lastUpdatedAt": "2026-07-11T00:14:10Z",
        "status": "ACTIVE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -0.686
      },
      {
        "bookmakerKey": "betmgm",
        "bookmakerTitle": "BetMGM",
        "marketKey": "spreads",
        "marketName": "Spread",
        "outcome": "Minnesota -8.5",
        "decimalOdds": 1.9,
        "impliedProbability": 0.5263,
        "lastUpdatedAt": "2026-07-10T23:57:00Z",
        "status": "STALE",
        "isBestPrice": false,
        "differenceFromConsensusPct": -1.206
      }
    ]
  }
};

export const pressureSignals: PressureSignal[] = [
  {
    id: "signal-1",
    title: "Fatigue divergence",
    subtitle: "BOS @ NYY",
    value: "+7.1%",
    strength: 0.91,
    direction: "positive" as const,
    detail: "The rest and bullpen-usage gap widened after New York's high-leverage relief sequence.",
  },
  {
    id: "signal-2",
    title: "Rotation stress",
    subtitle: "LVA @ SEA",
    value: "+5.2%",
    strength: 0.84,
    direction: "positive" as const,
    detail: "Seattle's minute concentration is increasing fourth-quarter performance risk.",
  },
  {
    id: "signal-3",
    title: "Market compression",
    subtitle: "LAD @ SF",
    value: "-1.4%",
    strength: 0.62,
    direction: "negative" as const,
    detail: "Recent price movement has reduced—but not eliminated—the under position's edge.",
  },
];

export function findGameById(id: string | string[] | undefined) {
  const normalized = Array.isArray(id) ? id[0] : id;
  return games.find((game) => game.id === normalized);
}

export function formatPercent(value: number, digits = 1) {
  return `${(value * 100).toFixed(digits)}%`;
}

export function formatGameDate(value: string) {
  const date = new Date(value);
  return date.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

export function formatGameTime(value: string) {
  return new Date(value).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}
