# MPIE Mobile v1.1.2 — Complete Delivery

This is the complete v1.1.2 application, not a patch-only archive.

## Application features

- Overview, Markets, Signals, Portfolio, Playbook, and Settings navigation
- Markdown-only Playbook with backend persistence and local draft recovery
- Bookmaker-level prices, best-price and consensus calculations, freshness state,
  sportsbook selection, and tracked-position attribution
- Model version and calculation timestamp
- Functional Data Source, Watchlist Sync, About, Methodology, Data Provenance,
  and Privacy destinations
- Typed `DELETE` account confirmation
- Demo and ClickHouse analytical modes with explicit provenance labels
- LAN-mode Expo startup and FastAPI Swagger documentation

## OAuth and account lifecycle prebuild

- Additive SQLite `users`, `auth_identities`, and `auth_sessions` structures
- Identity-attributed sessions with conservative legacy-session handling
- User CRUD, provider lookup/linking, login timestamps, disable, rotation, and revocation
- Google and Apple RS256 identity-token verification
- Signed Apple account-change notification verification
- Conditional Apple identity detach versus full user deletion
- Authenticated `DELETE /api/v1/auth/me`
- SecureStore/localStorage auth-token helpers
- Mocked-JWK provider tests and end-to-end session/deletion tests
- Environment placeholders, setup guide, PR description, and reconciliation table

OAuth is disabled by default and no provider secret or Apple signing key is
included. Existing v1.1.2 development identity behavior remains intact.

## Preserved contracts

- Application version remains `1.1.2`
- ClickHouse analytical schema remains unchanged
- Existing watchlist, portfolio, Playbook, `.env`, `backend/.env`, and SQLite data
  are preserved by the Ubuntu updater
- Provider authorization buttons remain intentionally unconnected until real
  Apple and Google client configuration is available

See `OAUTH_SETUP.md`, `ACCOUNT_LIFECYCLE_RECONCILIATION.md`, `UBUNTU_UPDATE.md`,
`TEST_REPORT.md`, and `API_VERIFICATION.md`.
