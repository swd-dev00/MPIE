import { describe, expect, it } from "vitest";

import { isSafeMarkdownLink, markdownExcerpt, parseMarkdownBlocks } from "../lib/markdown";

describe("Playbook Markdown", () => {
  it("parses headings, tasks, quotes, and code blocks", () => {
    const blocks = parseMarkdownBlocks([
      "# Market idea",
      "",
      "- [ ] Compare books",
      "- [x] Capture opening line",
      "",
      "> Recheck before lock.",
      "",
      "```",
      "edge = model - implied",
      "```",
    ].join("\n"));

    expect(blocks).toEqual([
      { type: "heading", level: 1, text: "Market idea" },
      {
        type: "task",
        items: [
          { checked: false, text: "Compare books" },
          { checked: true, text: "Capture opening line" },
        ],
      },
      { type: "quote", text: "Recheck before lock." },
      { type: "code", code: "edge = model - implied" },
    ]);
  });

  it("creates a plain searchable excerpt without Markdown controls", () => {
    const excerpt = markdownExcerpt(
      "# Thesis\n\n- [ ] **Track** [sharp book](https://example.com) movement",
    );

    expect(excerpt).toBe("Thesis Track sharp book movement");
  });

  it("limits long excerpts", () => {
    expect(markdownExcerpt("abcdefghij", 6)).toBe("abcde…");
  });

  it("allows ordinary web and email links but blocks executable schemes", () => {
    expect(isSafeMarkdownLink("https://example.com")).toBe(true);
    expect(isSafeMarkdownLink("mailto:research@example.com")).toBe(true);
    expect(isSafeMarkdownLink("javascript:alert(1)")).toBe(false);
    expect(isSafeMarkdownLink("data:text/html,test")).toBe(false);
  });
});
