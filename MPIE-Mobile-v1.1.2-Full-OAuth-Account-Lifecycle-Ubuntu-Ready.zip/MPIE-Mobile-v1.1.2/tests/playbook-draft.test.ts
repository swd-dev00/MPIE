import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = vi.hoisted(() => new Map<string, string>());

vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(async (key: string) => storage.get(key) ?? null),
    setItem: vi.fn(async (key: string, value: string) => {
      storage.set(key, value);
    }),
    removeItem: vi.fn(async (key: string) => {
      storage.delete(key);
    }),
  },
}));

import {
  clearPlaybookDraft,
  loadPlaybookDraft,
  savePlaybookDraft,
} from "../lib/playbook-draft";

describe("Playbook local drafts", () => {
  beforeEach(() => storage.clear());

  it("scopes drafts by both user and entry", async () => {
    await savePlaybookDraft("user-a", {
      entryId: "entry-1",
      title: "A1",
      bodyMarkdown: "# User A entry 1",
    });
    await savePlaybookDraft("user-a", {
      entryId: "entry-2",
      title: "A2",
      bodyMarkdown: "# User A entry 2",
    });
    await savePlaybookDraft("user-b", {
      entryId: "entry-1",
      title: "B1",
      bodyMarkdown: "# User B entry 1",
    });

    expect((await loadPlaybookDraft("user-a", "entry-1"))?.bodyMarkdown).toBe("# User A entry 1");
    expect((await loadPlaybookDraft("user-a", "entry-2"))?.bodyMarkdown).toBe("# User A entry 2");
    expect((await loadPlaybookDraft("user-b", "entry-1"))?.bodyMarkdown).toBe("# User B entry 1");
  });

  it("keeps a new-entry draft separate from existing entries", async () => {
    await savePlaybookDraft("user-a", {
      entryId: null,
      title: "New",
      bodyMarkdown: "# New idea",
    });
    await savePlaybookDraft("user-a", {
      entryId: "entry-1",
      title: "Existing",
      bodyMarkdown: "# Existing idea",
    });

    expect((await loadPlaybookDraft("user-a", null))?.title).toBe("New");
    expect((await loadPlaybookDraft("user-a", "entry-1"))?.title).toBe("Existing");
  });

  it("clears only the requested draft", async () => {
    await savePlaybookDraft("user-a", {
      entryId: "entry-1",
      title: "One",
      bodyMarkdown: "Draft one",
    });
    await savePlaybookDraft("user-a", {
      entryId: "entry-2",
      title: "Two",
      bodyMarkdown: "Draft two",
    });

    await clearPlaybookDraft("user-a", "entry-1");
    expect(await loadPlaybookDraft("user-a", "entry-1")).toBeNull();
    expect(await loadPlaybookDraft("user-a", "entry-2")).not.toBeNull();
  });

  it("removes malformed stored data", async () => {
    storage.set("mpie:playbook:draft:v1:user-a:entry-1", "not-json");

    expect(await loadPlaybookDraft("user-a", "entry-1")).toBeNull();
    expect(storage.has("mpie:playbook:draft:v1:user-a:entry-1")).toBe(false);
  });
});
