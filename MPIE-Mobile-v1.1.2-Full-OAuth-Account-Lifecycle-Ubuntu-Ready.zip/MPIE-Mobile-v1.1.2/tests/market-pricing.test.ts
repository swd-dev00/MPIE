import { describe, expect, it } from "vitest";

import { games, marketPriceBoards } from "../constants/mpie-data";

describe("market pricing fixtures", () => {
  it("keeps each game summary aligned with its bookmaker comparison board", () => {
    for (const game of games) {
      const board = marketPriceBoards[game.id];
      if (!board) throw new Error(`Missing market-price board for ${game.id}`);

      expect(board.quotes.length).toBeGreaterThanOrEqual(3);
      expect(board.marketKey).toBe(game.marketKey);
      expect(board.outcome).toBe(game.outcome);

      const activeQuotes = board.quotes.filter((quote) => quote.status === "ACTIVE");
      const bestQuotes = board.quotes.filter((quote) => quote.isBestPrice);
      expect(activeQuotes.length).toBeGreaterThan(0);
      expect(bestQuotes).toHaveLength(1);

      const bestQuote = bestQuotes[0];
      if (!bestQuote) throw new Error(`Missing best quote for ${game.id}`);
      const expectedBest = Math.max(...activeQuotes.map((quote) => quote.decimalOdds));
      expect(bestQuote.decimalOdds).toBe(expectedBest);
      expect(game.decimalOdds).toBe(expectedBest);
      expect(game.bestBookmakerKey).toBe(bestQuote.bookmakerKey);
      expect(game.bestBookmakerTitle).toBe(bestQuote.bookmakerTitle);
      expect(game.bookmakerCount).toBe(board.quoteCount);
    }
  });

  it("keeps displayed consensus deltas mathematically reproducible", () => {
    for (const board of Object.values(marketPriceBoards)) {
      const consensus = board.consensusDecimalOdds;
      if (!consensus) throw new Error(`Missing consensus odds for ${board.eventId}`);
      expect(consensus).toBeGreaterThan(1);
      for (const quote of board.quotes) {
        const expected = (quote.decimalOdds / consensus - 1) * 100;
        expect(quote.differenceFromConsensusPct).toBeCloseTo(expected, 2);
      }
    }
  });
});
