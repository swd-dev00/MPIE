import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const root = process.cwd();

function read(relativePath: string) {
  return fs.readFileSync(path.join(root, relativePath), "utf8");
}

describe("settings navigation", () => {
  it("wires every chevron row to a real destination", () => {
    const settings = read("app/(tabs)/settings.tsx");
    for (const route of [
      "/data-source",
      "/watchlist-sync",
      "/about",
      "/methodology",
      "/data-provenance",
      "/privacy",
    ]) {
      expect(settings).toContain(`router.push("${route}")`);
    }
  });

  it("registers every settings destination in the root stack", () => {
    const layout = read("app/_layout.tsx");
    for (const screen of [
      "data-source",
      "watchlist-sync",
      "about",
      "methodology",
      "data-provenance",
      "privacy",
    ]) {
      expect(layout).toContain(`<Stack.Screen name="${screen}" />`);
    }
  });

  it("ships actual source and synchronization detail screens", () => {
    expect(read("app/data-source.tsx")).toContain("Refresh connection");
    expect(read("app/watchlist-sync.tsx")).toContain("Retry synchronization");
  });


  it("requires an explicit typed DELETE confirmation", () => {
    const settings = read("app/(tabs)/settings.tsx");
    for (const token of [
      "DeleteAccountModal",
      "Type DELETE to confirm",
      "/api/v1/auth/me",
      'router.replace("/(auth)/login")',
    ]) {
      expect(settings).toContain(token);
    }
    expect(read("lib/mpie-auth.ts")).toContain("getStoredJwt");
    expect(read("app/(auth)/login.tsx")).toContain("Sign in to MPIE");
  });

});
