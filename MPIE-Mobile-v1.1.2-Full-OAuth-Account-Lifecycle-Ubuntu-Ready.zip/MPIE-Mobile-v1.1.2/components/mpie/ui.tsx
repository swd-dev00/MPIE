import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import type { ComponentProps, ReactNode } from "react";
import { Pressable, Text, View } from "react-native";

import type { MpieGame } from "@/constants/mpie-data";
import { formatGameDate, formatGameTime, formatPercent } from "@/constants/mpie-data";
import { useColors } from "@/hooks/use-colors";
import { useMpieStore } from "@/lib/mpie-store";

export function AppHeader({ eyebrow, title, right }: { eyebrow?: string; title: string; right?: ReactNode }) {
  return (
    <View className="flex-row items-center justify-between mb-5">
      <View className="flex-1 pr-4">
        {eyebrow ? <Text className="text-[11px] font-bold uppercase tracking-[2px] text-primary mb-1">{eyebrow}</Text> : null}
        <Text className="text-[28px] leading-9 font-black text-foreground">{title}</Text>
      </View>
      {right}
    </View>
  );
}

export function SectionHeader({ title, action, onPress }: { title: string; action?: string; onPress?: () => void }) {
  return (
    <View className="flex-row items-center justify-between mb-3">
      <Text className="text-lg font-extrabold text-foreground">{title}</Text>
      {action ? (
        <Pressable onPress={onPress} hitSlop={8}>
          <Text className="text-sm font-bold text-primary">{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function StatusPill({ status }: { status: MpieGame["status"] }) {
  const classes =
    status === "LIVE"
      ? "bg-error/10 text-error"
      : status === "FINAL"
        ? "bg-muted/10 text-muted"
        : "bg-primary/10 text-primary";
  return (
    <View className={`self-start px-2.5 py-1 rounded-full ${classes.split(" ")[0]}`}>
      <Text className={`text-[10px] font-black tracking-widest ${classes.split(" ")[1]}`}>
        {status === "LIVE" ? "● LIVE" : status}
      </Text>
    </View>
  );
}

export function MetricTile({ label, value, detail }: { label: string; value: string; detail?: string }) {
  return (
    <View className="flex-1 min-w-[104px] bg-surface border border-border rounded-2xl p-3.5">
      <Text className="text-[11px] uppercase tracking-wider font-bold text-muted">{label}</Text>
      <Text className="text-xl font-black text-foreground mt-1">{value}</Text>
      {detail ? <Text className="text-[11px] text-muted mt-1">{detail}</Text> : null}
    </View>
  );
}

export function ProgressBar({ value, tone = "primary" }: { value: number; tone?: "primary" | "success" | "warning" }) {
  const width = `${Math.max(0, Math.min(100, value * 100))}%` as `${number}%`;
  const color = tone === "success" ? "bg-success" : tone === "warning" ? "bg-warning" : "bg-primary";
  return (
    <View className="h-2 bg-border/50 rounded-full overflow-hidden">
      <View className={`h-full rounded-full ${color}`} style={{ width }} />
    </View>
  );
}

export function IconButton({
  icon,
  onPress,
  active = false,
  accessibilityLabel,
}: {
  icon: ComponentProps<typeof MaterialCommunityIcons>["name"];
  onPress?: () => void;
  active?: boolean;
  accessibilityLabel: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      className={`h-11 w-11 rounded-2xl items-center justify-center border ${active ? "bg-primary/10 border-primary/50" : "bg-surface border-border"}`}
    >
      <MaterialCommunityIcons name={icon} size={21} color={active ? colors.primary : colors.foreground} />
    </Pressable>
  );
}

export function GameCard({ game, compact = false }: { game: MpieGame; compact?: boolean }) {
  const colors = useColors();
  const { savedGameIds, toggleSavedGame } = useMpieStore();
  const isSaved = savedGameIds.includes(game.id);

  return (
    <Pressable
      onPress={() => router.push({ pathname: "/game/[id]", params: { id: game.id } })}
      className="bg-surface border border-border rounded-[22px] p-4 mb-3 active:opacity-90"
      accessibilityRole="button"
      accessibilityLabel={`Open ${game.away.city} at ${game.home.city} analysis`}
    >
      <View className="flex-row items-start justify-between">
        <View className="flex-row items-center gap-2">
          <StatusPill status={game.status} />
          <Text className="text-[11px] font-bold text-muted">{game.league}</Text>
        </View>
        <Pressable
          hitSlop={10}
          onPress={(event) => {
            event.stopPropagation();
            toggleSavedGame(game.id);
          }}
          accessibilityRole="button"
          accessibilityLabel={isSaved ? "Remove from watchlist" : "Add to watchlist"}
        >
          <MaterialCommunityIcons
            name={isSaved ? "bookmark" : "bookmark-outline"}
            size={22}
            color={isSaved ? colors.primary : colors.muted}
          />
        </Pressable>
      </View>

      <View className="flex-row items-center mt-4">
        <View className="flex-1">
          <Text className="text-[11px] uppercase tracking-wider font-bold text-muted">Away</Text>
          <Text className="text-lg font-black text-foreground mt-0.5">{game.away.abbreviation}</Text>
          <Text className="text-xs text-muted mt-0.5">{game.away.record}</Text>
        </View>
        <View className="items-center px-4">
          {game.status === "LIVE" ? (
            <Text className="text-2xl font-black text-foreground">{game.away.score}–{game.home.score}</Text>
          ) : (
            <>
              <Text className="text-xs font-bold text-foreground">{formatGameDate(game.startAt)}</Text>
              <Text className="text-[11px] text-muted mt-1">{formatGameTime(game.startAt)}</Text>
            </>
          )}
        </View>
        <View className="flex-1 items-end">
          <Text className="text-[11px] uppercase tracking-wider font-bold text-muted">Home</Text>
          <Text className="text-lg font-black text-foreground mt-0.5">{game.home.abbreviation}</Text>
          <Text className="text-xs text-muted mt-0.5">{game.home.record}</Text>
        </View>
      </View>

      {!compact ? (
        <View className="mt-4 pt-4 border-t border-border flex-row items-end justify-between">
          <View className="flex-1 pr-4">
            <Text className="text-[11px] uppercase tracking-wider font-bold text-muted">Model position</Text>
            <View className="flex-row items-center flex-wrap mt-1">
              <Text className="text-base font-black text-foreground mr-2">{game.pick}</Text>
              {game.bestBookmakerTitle ? (
                <View className="rounded-full bg-success/10 px-2 py-1">
                  <Text className="text-[9px] font-black uppercase tracking-wider text-success">Best price</Text>
                </View>
              ) : null}
            </View>
            <Text className="text-[11px] text-muted mt-1">
              {game.bestBookmakerTitle ?? "Book unavailable"} · {game.decimalOdds.toFixed(2)}
              {game.bookmakerCount ? ` · ${game.bookmakerCount} books` : ""}
            </Text>
          </View>
          <View className="items-end">
            <Text className="text-[11px] uppercase tracking-wider font-bold text-muted">Edge</Text>
            <Text className="text-lg font-black text-success mt-1">+{formatPercent(game.edge)}</Text>
          </View>
        </View>
      ) : null}
    </Pressable>
  );
}

export function SettingRow({
  icon,
  title,
  subtitle,
  right,
  onPress,
}: {
  icon: ComponentProps<typeof MaterialCommunityIcons>["name"];
  title: string;
  subtitle?: string;
  right?: ReactNode;
  onPress?: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress && !right}
      accessibilityRole={onPress ? "button" : undefined}
      accessibilityLabel={onPress ? title : undefined}
      accessibilityState={{ disabled: !onPress && !right }}
      style={({ pressed }) => ({ opacity: pressed && onPress ? 0.65 : 1 })}
      className="flex-row items-center py-4 border-b border-border last:border-b-0"
    >
      <View className="h-10 w-10 rounded-xl bg-primary/10 items-center justify-center mr-3">
        <MaterialCommunityIcons name={icon} size={20} color={colors.primary} />
      </View>
      <View className="flex-1">
        <Text className="text-[15px] font-bold text-foreground">{title}</Text>
        {subtitle ? <Text className="text-xs text-muted mt-0.5">{subtitle}</Text> : null}
      </View>
      {right ?? <MaterialCommunityIcons name="chevron-right" size={22} color={colors.muted} />}
    </Pressable>
  );
}
