import { Linking, Text, View } from "react-native";

import { useColors } from "@/hooks/use-colors";
import { isSafeMarkdownLink, parseMarkdownBlocks } from "@/lib/markdown";

const inlinePattern = /(\*\*[^*]+\*\*|__[^_]+__|`[^`]+`|\*[^*\n]+\*|_[^_\n]+_|\[[^\]]+\]\([^)]+\))/g;

function InlineMarkdown({ value }: { value: string }) {
  const colors = useColors();
  const parts = value.split(inlinePattern).filter(Boolean);

  return (
    <Text className="text-[15px] leading-6 text-foreground" selectable>
      {parts.map((part, index) => {
        if ((part.startsWith("**") && part.endsWith("**")) || (part.startsWith("__") && part.endsWith("__"))) {
          return (
            <Text key={`${part}-${index}`} className="font-black">
              {part.slice(2, -2)}
            </Text>
          );
        }
        if ((part.startsWith("*") && part.endsWith("*")) || (part.startsWith("_") && part.endsWith("_"))) {
          return (
            <Text key={`${part}-${index}`} className="italic">
              {part.slice(1, -1)}
            </Text>
          );
        }
        if (part.startsWith("`") && part.endsWith("`")) {
          return (
            <Text
              key={`${part}-${index}`}
              style={{ fontFamily: "monospace", backgroundColor: colors.background }}
            >
              {part.slice(1, -1)}
            </Text>
          );
        }
        const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
        if (link) {
          const target = link[2].trim();
          if (!isSafeMarkdownLink(target)) return link[1];
          return (
            <Text
              key={`${part}-${index}`}
              className="font-bold text-primary underline"
              accessibilityRole="link"
              onPress={() => void Linking.openURL(target)}
            >
              {link[1]}
            </Text>
          );
        }
        return part;
      })}
    </Text>
  );
}

export function MarkdownPreview({ markdown }: { markdown: string }) {
  const colors = useColors();
  const blocks = parseMarkdownBlocks(markdown);

  if (!blocks.length) {
    return <Text className="text-sm text-muted italic">Nothing to preview yet.</Text>;
  }

  return (
    <View>
      {blocks.map((block, blockIndex) => {
        if (block.type === "heading") {
          const classes = block.level === 1
            ? "text-2xl leading-8"
            : block.level === 2
              ? "text-xl leading-7"
              : "text-lg leading-6";
          return (
            <Text key={`heading-${blockIndex}`} className={`${classes} font-black text-foreground mb-3 mt-1`} selectable>
              {block.text}
            </Text>
          );
        }

        if (block.type === "paragraph") {
          return (
            <View key={`paragraph-${blockIndex}`} className="mb-4">
              <InlineMarkdown value={block.text} />
            </View>
          );
        }

        if (block.type === "bullet") {
          return (
            <View key={`bullet-${blockIndex}`} className="mb-4">
              {block.items.map((item, itemIndex) => (
                <View key={`${item}-${itemIndex}`} className="flex-row items-start mb-1.5">
                  <Text className="text-primary font-black mr-2">•</Text>
                  <View className="flex-1"><InlineMarkdown value={item} /></View>
                </View>
              ))}
            </View>
          );
        }

        if (block.type === "ordered") {
          return (
            <View key={`ordered-${blockIndex}`} className="mb-4">
              {block.items.map((item, itemIndex) => (
                <View key={`${item}-${itemIndex}`} className="flex-row items-start mb-1.5">
                  <Text className="text-primary font-black mr-2">{itemIndex + 1}.</Text>
                  <View className="flex-1"><InlineMarkdown value={item} /></View>
                </View>
              ))}
            </View>
          );
        }

        if (block.type === "task") {
          return (
            <View key={`task-${blockIndex}`} className="mb-4">
              {block.items.map((item, itemIndex) => (
                <View key={`${item.text}-${itemIndex}`} className="flex-row items-start mb-2">
                  <View className={`h-5 w-5 rounded-md border items-center justify-center mr-2 mt-0.5 ${item.checked ? "bg-success border-success" : "border-border"}`}>
                    {item.checked ? <Text className="text-[#071019] text-xs font-black">✓</Text> : null}
                  </View>
                  <View className="flex-1" style={{ opacity: item.checked ? 0.65 : 1 }}>
                    <InlineMarkdown value={item.text} />
                  </View>
                </View>
              ))}
            </View>
          );
        }

        if (block.type === "quote") {
          return (
            <View key={`quote-${blockIndex}`} className="border-l-4 border-primary bg-primary/5 rounded-r-xl px-4 py-3 mb-4">
              <InlineMarkdown value={block.text} />
            </View>
          );
        }

        if (block.type === "code") {
          return (
            <View key={`code-${blockIndex}`} className="bg-background border border-border rounded-2xl p-4 mb-4">
              <Text style={{ fontFamily: "monospace", color: colors.foreground }} selectable>
                {block.code}
              </Text>
            </View>
          );
        }

        return <View key={`rule-${blockIndex}`} className="h-px bg-border my-4" />;
      })}
    </View>
  );
}
