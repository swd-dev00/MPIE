import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import type { ComponentProps } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

type InfoSection = {
  title: string;
  body?: string[];
  bullets?: string[];
};

type InfoPageProps = {
  eyebrow: string;
  title: string;
  intro: string;
  icon: ComponentProps<typeof MaterialCommunityIcons>["name"];
  sections: InfoSection[];
  notice?: string;
};

export function InfoPage({ eyebrow, title, intro, icon, sections, notice }: InfoPageProps) {
  const router = useRouter();
  const colors = useColors();

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View className="flex-row items-center pt-2 mb-5">
          <Pressable
            onPress={() => router.back()}
            className="h-11 w-11 rounded-2xl bg-surface border border-border items-center justify-center mr-4"
            accessibilityLabel="Go back"
          >
            <MaterialCommunityIcons name="arrow-left" size={22} color={colors.foreground} />
          </Pressable>
          <View className="flex-1">
            <Text className="text-[10px] uppercase tracking-[2px] font-bold text-primary">{eyebrow}</Text>
            <Text className="text-2xl font-black text-foreground mt-1">{title}</Text>
          </View>
        </View>

        <View className="bg-primary/10 border border-primary/25 rounded-[24px] p-5 mb-5">
          <View className="h-11 w-11 rounded-2xl bg-primary/15 items-center justify-center mb-4">
            <MaterialCommunityIcons name={icon} size={23} color={colors.primary} />
          </View>
          <Text className="text-sm leading-6 text-foreground">{intro}</Text>
        </View>

        {sections.map((section) => (
          <View key={section.title} className="bg-surface border border-border rounded-[22px] p-4 mb-4">
            <Text className="text-base font-black text-foreground">{section.title}</Text>
            {section.body?.map((paragraph) => (
              <Text key={paragraph} className="text-xs leading-5 text-muted mt-3">
                {paragraph}
              </Text>
            ))}
            {section.bullets?.map((bullet) => (
              <View key={bullet} className="flex-row items-start mt-3">
                <View className="h-1.5 w-1.5 rounded-full bg-primary mt-2 mr-3" />
                <Text className="text-xs leading-5 text-muted flex-1">{bullet}</Text>
              </View>
            ))}
          </View>
        ))}

        {notice ? (
          <View className="bg-warning/10 border border-warning/25 rounded-[22px] p-4">
            <Text className="text-[11px] leading-5 text-muted">{notice}</Text>
          </View>
        ) : null}
      </ScrollView>
    </ScreenContainer>
  );
}
