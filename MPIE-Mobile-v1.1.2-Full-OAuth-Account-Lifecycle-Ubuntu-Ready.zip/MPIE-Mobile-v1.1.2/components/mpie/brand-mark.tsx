import Svg, { Circle, Defs, LinearGradient, Path, Stop } from "react-native-svg";

export function BrandMark({ size = 40 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 64 64" accessibilityLabel="MPIE logo">
      <Defs>
        <LinearGradient id="brand" x1="10" y1="8" x2="55" y2="57" gradientUnits="userSpaceOnUse">
          <Stop offset="0" stopColor="#4DE3FF" />
          <Stop offset="1" stopColor="#9DFF4F" />
        </LinearGradient>
      </Defs>
      <Circle cx="32" cy="32" r="29" fill="#0B1723" stroke="#1E3B4F" strokeWidth="2" />
      <Circle cx="32" cy="32" r="20" fill="none" stroke="#24495E" strokeWidth="2" strokeDasharray="4 4" />
      <Path
        d="M16 43V22h7.2L32 34.4 40.8 22H48v21h-7V32.1l-8.1 11h-1.8l-8.1-11V43h-7Z"
        fill="url(#brand)"
      />
      <Path d="M47 14l3.8 7.5-8.3-1.1L47 14Z" fill="#9DFF4F" />
    </Svg>
  );
}
