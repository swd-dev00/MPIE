# MPIE Mobile v1.1.2 — API Verification

## Existing application contract

Verified routes include health, markets, bookmaker prices, signals, predictions,
pressure, portfolio, watchlist, Playbook, OpenAPI, and Swagger. Existing state
routes retain their development identity behavior while OAuth is disabled.

## OAuth and account lifecycle contract

| Method | Route | Default behavior |
|---|---|---|
| POST | `/api/v1/auth/google` | 503 until OAuth and Google client IDs are configured |
| POST | `/api/v1/auth/apple` | 503 until OAuth and Apple client IDs are configured |
| POST | `/api/v1/auth/apple/webhook` | Verifies signed Apple notifications when Apple audiences are configured |
| POST | `/api/v1/auth/refresh` | 503 until OAuth is enabled |
| POST | `/api/v1/auth/logout` | 503 until OAuth is enabled |
| GET | `/api/v1/auth/me` | 503 until OAuth is enabled |
| DELETE | `/api/v1/auth/me` | 503 until OAuth is enabled; 204 after authenticated deletion |

When enabled, provider login verifies the ID token and nonce, resolves the provider
`sub` to an internal MPIE UUID, and returns an MPIE access token plus a rotating
refresh token. Protected state routes require `Authorization: Bearer <token>`.

## Deletion contract

`DELETE /api/v1/auth/me` revokes sessions, de-identifies retained audit rows when
present, and deletes the user, identities, watchlist, portfolio positions, and
Playbook entries.

Apple webhook behavior:

- `consent-revoked` → revoke Apple-attributed sessions and detach Apple
- `account-delete` → detach Apple; delete the user only when no other identity remains
- repeated notification → idempotent HTTP 200
- unknown subject → HTTP 200 `unknown_identity`
- invalid signature → logged and HTTP 200 `ignored`

## Provider validation

Google accepts only configured client-ID audiences and documented Google issuers.
Apple accepts only configured Apple client-ID audiences and the Apple issuer. Both
restrict signatures to RS256 and validate applicable issuer, audience, time,
subject, and nonce claims.

The test suite mocks JWK endpoints, including normal key rotation and an unknown
key after refresh. No real provider token or credential is embedded in the release.

## Standard smoke command

```bash
bash scripts/ubuntu_smoke_test.sh
```

The standard smoke test keeps `MPIE_AUTH_ENABLED=false` so it can verify the full
application without provider-console credentials. OAuth-specific behavior is
covered by the backend unit/integration suite.
