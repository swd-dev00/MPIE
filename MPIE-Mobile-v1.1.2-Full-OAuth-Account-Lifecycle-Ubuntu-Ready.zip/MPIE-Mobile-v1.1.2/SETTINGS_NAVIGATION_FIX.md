# MPIE Mobile v1.1.2 — Settings Navigation Fix

The Playbook-only v1.1.2 build displayed Product rows without `onPress` handlers. Data source only triggered an invisible refresh, while Watchlist sync could be disabled when no pending operation existed. This hotfix makes every chevron row open a real screen.

## Functional destinations

- Data source: connectivity, backend mode, API endpoint, errors, and manual refresh.
- Watchlist sync: saved count, pending count, synchronization errors, and retry.
- About MPIE.
- Methodology.
- Data provenance.
- Privacy.

The release remains MPIE Mobile v1.1.2 and does not modify the ClickHouse schema or saved user data.
