import { useThemeContext } from "@/lib/theme-provider";

/**
 * Keep web color tokens synchronized with the explicit app theme rather than
 * falling back to the browser's system preference after hydration.
 */
export function useColorScheme() {
  return useThemeContext().colorScheme;
}
