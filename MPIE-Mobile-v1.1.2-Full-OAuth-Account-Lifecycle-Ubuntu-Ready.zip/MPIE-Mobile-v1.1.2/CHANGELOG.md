# Changelog

## 1.1.2

### Account deletion and Apple account lifecycle

- Added a cross-platform typed `DELETE` confirmation modal in Settings.
- Added mobile access/refresh-token storage helpers using SecureStore on native
  platforms and localStorage on web.
- Added a valid post-deletion auth landing route.
- Added `DELETE /api/v1/auth/me` for authenticated permanent account deletion.
- Added `POST /api/v1/auth/apple/webhook` for signed Sign in with Apple
  server-to-server notifications.
- Added Apple notification JWK verification, audience/issuer validation, and
  safe parsing of `email-enabled`, `email-disabled`, `consent-revoked`, and
  `account-delete` events.
- Bound new server sessions to the provider identity that issued them.
- Added an additive `identity_id` migration for existing `auth_sessions`; legacy
  unscoped sessions are revoked conservatively when an identity is disconnected.
- Added conditional Apple deletion behavior: detach Apple when another identity
  remains, otherwise remove the full MPIE user and owned state.
- Added idempotent repeated-notification handling and an audit de-identification hook.
- Expanded the backend suite from 28 to 38 passing test methods.

### OAuth backend prebuild

- Added provider-neutral `users`, `auth_identities`, and `auth_sessions` SQLite tables.
- Added user CRUD, provider lookup/linking, login timestamp, disable, refresh rotation, and revocation methods.
- Added Google and Apple RS256 identity-token verification with issuer, audience, expiration, subject, and nonce validation.
- Added JWK caching that honors provider cache headers and refreshes once on an unknown `kid`.
- Added `/api/v1/auth/google`, `/api/v1/auth/apple`, `/api/v1/auth/refresh`, `/api/v1/auth/logout`, and `/api/v1/auth/me`.
- Added hashed refresh tokens and MPIE access tokens bound to active server sessions.
- Added mocked-JWK Google and Apple tests plus auth-state and session integration tests.
- Added OAuth environment placeholders, setup documentation, and a mobile PR description.
- Kept authentication disabled by default and preserved the development `X-MPIE-User-ID` boundary until real client credentials and mobile controls are ready.
- Left the ClickHouse schema and existing v1.1.2 user-state contracts unchanged.


- Added bookmaker-level market-price comparison without changing the ClickHouse schema.
- Added `GET /api/v1/markets/{event_id}/prices` with best price, consensus price,
  update timestamp, active/stale/suspended status, and per-book consensus delta.
- Added sportsbook selection to the game-detail tracking flow.
- Added nullable `bookmaker_key` and `bookmaker_title` columns to SQLite portfolio
  positions through an idempotent migration that preserves existing data.
- Added sportsbook attribution to tracked-position API responses and Portfolio UI.
- Replaced the ambiguous live badge with backend-aware labels for ClickHouse live,
  API demo analytics, and local demonstration fallback.
- Added best-price labels and bookmaker counts to market cards.
- Added model version and calculation timestamp to game detail and prediction responses.
- Wired complete About, Methodology, Data Provenance, and Privacy pages from Settings.
- Added market-pricing, SQLite migration, API-contract, repository, and Ubuntu
  smoke tests.
- Changed Metro startup to explicit LAN mode for access from devices on the same
  local network.
- Added the dedicated **Playbook** tab.
- Added Markdown-only entry creation, editing, previewing, searching, saving, and deletion.
- Added local draft autosave and restoration so unsynced writing is not lost.
- Added per-user FastAPI Playbook CRUD routes.
- Added parameterized SQLite `playbook_entries` persistence and a legacy `notes` migration.
- Added Playbook user-isolation and payload-validation tests.
- Added a live Playbook persistence smoke test.
- Added safe Markdown link-scheme filtering.
- Closed SQLite connections explicitly after transactions.
- Added `httpx` to the pinned backend requirements for FastAPI contract testing.
- Fixed the WSL Metro launcher to use the project-local Expo binary instead of Windows-routed `npx`.
- Removed the two existing Expo lint warnings and changed the ESLint config to an explicit ES module.
- Left the ClickHouse analytical schema unchanged.

## v1.1.2 Settings navigation hotfix

- Wired Data source and Watchlist sync rows to dedicated diagnostic screens.
- Preserved functional About, Methodology, Data provenance, and Privacy routes.
- Added visible refresh and retry actions instead of chevrons that appeared inert.
- Added pressed-state and accessibility behavior to setting rows.
- Added route-registration and navigation regression tests.
