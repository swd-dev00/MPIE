# Legacy generated server scaffold

This Node/tRPC/Drizzle directory is retained only as reference from the original generated project.

MPIE Mobile's active data path is:

```text
Expo mobile client -> lib/mpie-api.ts -> FastAPI -> ClickHouse / SQLite
```

The mobile root layout does not initialize a tRPC provider or Manus runtime, and `pnpm dev:full` does not start this server. Launch it only for explicit legacy-development work with `pnpm dev:legacy-server`.
