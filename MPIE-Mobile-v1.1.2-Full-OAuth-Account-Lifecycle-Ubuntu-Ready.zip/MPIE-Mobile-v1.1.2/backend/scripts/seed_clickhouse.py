from __future__ import annotations

import json
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import uuid4

import clickhouse_connect


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = Path(os.getenv("MPIE_FIXTURE_PATH", ROOT / "fixtures" / "demo.json"))


def market_key(name: str) -> str:
    return {
        "Moneyline": "h2h",
        "Spread": "spreads",
        "Total": "totals",
    }.get(name, name.lower().replace(" ", "_"))


def sport_key(league: str) -> str:
    return {
        "MLB": "baseball_mlb",
        "NBA": "basketball_nba",
        "WNBA": "basketball_wnba",
        "NFL": "americanfootball_nfl",
    }.get(league, league.lower())


def parse_datetime(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed.astimezone(UTC)


def main() -> None:
    payload: dict[str, Any] = json.loads(FIXTURE.read_text(encoding="utf-8"))
    client = clickhouse_connect.get_client(
        host=os.getenv("CLICKHOUSE_HOST", "localhost"),
        port=int(os.getenv("CLICKHOUSE_PORT", "8123")),
        username=os.getenv("CLICKHOUSE_USER", "default"),
        password=os.getenv("CLICKHOUSE_PASSWORD", ""),
        database=os.getenv("CLICKHOUSE_DATABASE", "mpie"),
        secure=os.getenv("CLICKHOUSE_SECURE", "false").lower() == "true",
    )

    now = datetime.now(UTC)
    event_rows: list[list[Any]] = []
    raw_rows: list[list[Any]] = []
    prediction_rows: list[list[Any]] = []
    pressure_rows: list[list[Any]] = []

    for game in payload.get("games", []):
        event_id = game["id"]
        league = game["league"]
        start_at = parse_datetime(game["startAt"])
        market = market_key(game["market"])
        outcome = game["pick"]
        event_rows.append(
            [
                event_id,
                sport_key(league),
                league,
                game["status"],
                start_at,
                game.get("venue", ""),
                game["home"]["name"],
                game["home"].get("city", ""),
                game["home"]["abbreviation"],
                game["home"].get("record", "—"),
                game["home"].get("score"),
                game["away"]["name"],
                game["away"].get("city", ""),
                game["away"]["abbreviation"],
                game["away"].get("record", "—"),
                game["away"].get("score"),
                now,
            ]
        )

        # Three deterministic ticks demonstrate chronological snapshot and velocity aggregation.
        prices = [
            round(game["decimalOdds"] * 1.015, 4),
            round(game["decimalOdds"] * 1.006, 4),
            float(game["decimalOdds"]),
        ]
        for offset, price in zip((10, 5, 0), prices, strict=True):
            received = now - timedelta(minutes=offset)
            raw_rows.append(
                [
                    event_id,
                    sport_key(league),
                    league,
                    start_at,
                    game["home"]["name"],
                    game["away"]["name"],
                    "demo_book",
                    "MPIE Demo Book",
                    market,
                    game["market"],
                    outcome,
                    price,
                    1.0 / price,
                    "decimal",
                    received,
                    received,
                ]
            )

        prediction_rows.append(
            [
                uuid4(),
                event_id,
                sport_key(league),
                market,
                game["market"],
                outcome,
                game["pick"],
                game["pickSide"],
                game["modelProbability"],
                game["baselineProbability"],
                game["impliedProbability"],
                game["edge"],
                game["confidence"],
                max(0.0, game["edge"] * game["confidence"]),
                "demo-1.1.0",
                now,
            ]
        )

        factors = game.get("factors", [])
        pressure_rows.append(
            [
                event_id,
                market,
                outcome,
                game["pressureIndex"],
                game["modelProbability"] - game["baselineProbability"],
                [factor["label"] for factor in factors],
                [factor["shortLabel"] for factor in factors],
                [factor["impact"] for factor in factors],
                [factor["detail"] for factor in factors],
                game["insight"],
                now,
            ]
        )

    client.insert(
        "mpie.event_catalog",
        event_rows,
        column_names=[
            "event_id", "sport_key", "league", "status", "commence_time", "venue",
            "home_name", "home_city", "home_abbreviation", "home_record", "home_score",
            "away_name", "away_city", "away_abbreviation", "away_record", "away_score",
            "updated_at",
        ],
    )
    client.insert(
        "mpie.raw_odds_events",
        raw_rows,
        column_names=[
            "event_id", "sport_key", "sport_title", "commence_time", "home_team",
            "away_team", "bookmaker_key", "bookmaker_title", "market_key", "market_name",
            "outcome", "price", "implied_prob", "odds_format", "api_received_at", "inserted_at",
        ],
    )
    client.insert(
        "mpie.predictions",
        prediction_rows,
        column_names=[
            "prediction_id", "event_id", "sport_key", "market_key", "market_name", "outcome",
            "pick_label", "pick_side", "model_prob", "baseline_prob", "market_implied_prob",
            "edge", "confidence", "recommended_size_pct", "model_version", "calculated_at",
        ],
    )
    client.insert(
        "mpie.market_pressure",
        pressure_rows,
        column_names=[
            "event_id", "market_key", "outcome", "pressure_load_index", "pressure_diff_score",
            "pressure_factor_labels", "pressure_factor_short_labels", "pressure_factor_impacts",
            "pressure_factor_details", "attribution", "updated_at",
        ],
    )

    signal_rows: list[list[Any]] = []
    games_by_subtitle = {
        f"{game['away']['abbreviation']} @ {game['home']['abbreviation']}": game
        for game in payload.get("games", [])
    }
    for signal in payload.get("signals", []):
        game = games_by_subtitle.get(signal["subtitle"])
        if game is None:
            continue
        numeric_value = float(signal["value"].replace("%", "")) / 100.0
        signal_rows.append(
            [
                uuid4(),
                game["id"],
                sport_key(game["league"]),
                market_key(game["market"]),
                signal["title"].upper().replace(" ", "_"),
                signal["title"],
                signal["subtitle"],
                signal.get("severity", "INFO"),
                signal["direction"],
                numeric_value,
                signal["strength"],
                signal["detail"],
                now,
            ]
        )
    if signal_rows:
        client.insert(
            "mpie.signal_history",
            signal_rows,
            column_names=[
                "signal_id", "event_id", "sport_key", "market_key", "signal_type", "title",
                "subtitle", "severity", "direction", "value", "strength", "description",
                "triggered_at",
            ],
        )

    print(
        f"Seeded {len(event_rows)} events, {len(raw_rows)} odds ticks, "
        f"{len(prediction_rows)} predictions, {len(pressure_rows)} pressure profiles, "
        f"and {len(signal_rows)} signals."
    )


if __name__ == "__main__":
    main()
