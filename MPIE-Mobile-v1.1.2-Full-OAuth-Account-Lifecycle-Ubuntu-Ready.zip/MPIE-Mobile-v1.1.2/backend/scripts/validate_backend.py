from __future__ import annotations

import ast
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = ROOT.parent
failures: list[str] = []

for path in sorted((ROOT / "app").rglob("*.py")) + sorted((ROOT / "scripts").rglob("*.py")) + sorted((ROOT / "tests").rglob("*.py")):
    try:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        failures.append(f"{path.relative_to(ROOT)}: {exc}")


expected_hashes = {
    ROOT / "sql" / "001_clickhouse_schema.sql": "e9844a46ee9649994f1952d26a5a2c58f6744f0f3304db8ec74dcb3e741ec571",
    ROOT / "app" / "models.py": "d4953817c5fbdd463451ba4572c586a7a7ef88edc57bb11f8ec587037af3d3cc",
}
for path, expected_hash in expected_hashes.items():
    actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual_hash != expected_hash:
        failures.append(
            f"{path.relative_to(PROJECT_ROOT)} changed unexpectedly; expected {expected_hash}, received {actual_hash}."
        )

sql_path = ROOT / "sql" / "001_clickhouse_schema.sql"
sql = sql_path.read_text(encoding="utf-8")
for forbidden in ("anyLast(", "SummingMergeTree", "HTTP_211_CREATED", "ALTER TABLE mpie.user_watchlist DELETE"):
    if forbidden in sql:
        failures.append(f"SQL contains forbidden pattern: {forbidden}")

for required in (
    "AggregateFunction(argMin",
    "AggregateFunction(argMax",
    "AggregatingMergeTree",
    "mpie.predictions",
    "mpie.market_pressure",
    "mpie.signal_history",
    "mpie.event_catalog",
):
    if required not in sql:
        failures.append(f"SQL missing required structure: {required}")

main_source = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
for route in (
    "/api/v1/markets",
    "/api/v1/markets/{event_id}",
    "/api/v1/markets/{event_id}/prices",
    "/api/v1/signals",
    "/api/v1/predictions/{event_id}",
    "/api/v1/pressure/{event_id}",
    "/api/v1/portfolio",
    "/api/v1/portfolio/positions",
    "/api/v1/watchlist",
    "/api/v1/watchlist/{event_id}",
    "/api/v1/playbook",
    "/api/v1/playbook/{entry_id}",
):
    if route not in main_source:
        failures.append(f"FastAPI contract missing route: {route}")

if "HTTP_201_CREATED" not in main_source or "HTTP_211_CREATED" in main_source:
    failures.append("FastAPI create endpoints must use HTTP 201.")
if "lifespan=lifespan" not in main_source or "analytics.close()" not in main_source:
    failures.append("FastAPI must close the shared analytical client during shutdown.")

repository_source = (ROOT / "app" / "repository.py").read_text(encoding="utf-8")
for forbidden in ("zero_as_nil", "float_overflow_mode", "max_memory_usage = 10000000000"):
    if forbidden in repository_source:
        failures.append(f"Repository contains unsafe/unsupported connection setting: {forbidden}")
for required in (
    "autogenerate_session_id=False",
    "tuple(calculated_at, prediction_id)",
    "event_id IN {event_ids:Array(String)}",
    "toIntervalDay({lookback_days:UInt16})",
    "Prediction references missing event_catalog row",
    "_build_market_price_response",
    "bookmaker_title",
    "differenceFromConsensusPct",
    "model_version",
    "modelVersion",
):
    if required not in repository_source:
        failures.append(f"Repository missing safety pattern: {required}")

state_source = (ROOT / "app" / "state.py").read_text(encoding="utf-8")
if re.search(r"execute\(f[\"']", state_source):
    failures.append("State store contains interpolated SQL; use bound parameters.")

for required in (
    "CREATE TABLE IF NOT EXISTS playbook_entries",
    "idx_playbook_user_updated",
    "list_playbook_entries",
    "create_playbook_entry",
    "update_playbook_entry",
    "delete_playbook_entry",
    "INSERT OR IGNORE INTO playbook_entries",
    "bookmaker_key",
    "bookmaker_title",
    "ALTER TABLE portfolio_positions ADD COLUMN bookmaker_key TEXT",
    "connection.close()",
    "@contextmanager",
):
    if required not in state_source:
        failures.append(f"Playbook persistence missing pattern: {required}")


auth_files = [
    ROOT / "app" / "auth" / "claims.py",
    ROOT / "app" / "auth" / "jwks.py",
    ROOT / "app" / "auth" / "google.py",
    ROOT / "app" / "auth" / "apple.py",
    ROOT / "app" / "auth" / "sessions.py",
    ROOT / "app" / "auth" / "service.py",
]
for path in auth_files:
    if not path.exists():
        failures.append(f"Missing OAuth implementation: {path.relative_to(PROJECT_ROOT)}")

for required in (
    "revoke_all_sessions_for_identity",
    "user_has_other_identities",
    "delete_user_and_cascade",
    "anonymize_stake_audit",
    "identity_id TEXT",
):
    if required not in state_source:
        failures.append(f"OAuth lifecycle state missing: {required}")

main_source = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
for required in (
    "/api/v1/auth/apple/webhook",
    "delete_current_user",
    "apple_webhook_verify_failed",
):
    if required not in main_source:
        failures.append(f"OAuth lifecycle API missing: {required}")

apple_source = (ROOT / "app" / "auth" / "apple.py").read_text(encoding="utf-8")
for required in ("verify_notification", "APPLE_NOTIFICATION_ISSUER"):
    if required not in apple_source:
        failures.append(f"Apple webhook verification missing: {required}")

config_source = (ROOT / "app" / "config.py").read_text(encoding="utf-8")
for required in (
    "MPIE_AUTH_ENABLED",
    "MPIE_SESSION_SECRET",
    "GOOGLE_CLIENT_IDS",
    "APPLE_CLIENT_IDS",
    "GOOGLE_JWKS_URL",
    "APPLE_JWKS_URL",
):
    if required not in config_source:
        failures.append(f"OAuth configuration missing: {required}")

requirements_source = (ROOT / "requirements.txt").read_text(encoding="utf-8")
if "PyJWT[crypto]==" not in requirements_source:
    failures.append("Backend requirements must pin PyJWT with cryptography support.")

env_example = (ROOT / ".env.example").read_text(encoding="utf-8")
if "MPIE_AUTH_ENABLED=false" not in env_example:
    failures.append("OAuth must be disabled by default in backend/.env.example.")
if not re.search(r"^MPIE_SESSION_SECRET=$", env_example, re.MULTILINE):
    failures.append("MPIE_SESSION_SECRET must remain an empty placeholder.")

for test_name in (
    "test_auth_state.py",
    "test_auth_service.py",
    "test_auth_api_contract.py",
    "test_oauth_google.py",
    "test_oauth_apple.py",
):
    if not (ROOT / "tests" / test_name).exists():
        failures.append(f"Missing OAuth test: backend/tests/{test_name}")

fixture = json.loads((ROOT / "fixtures" / "demo.json").read_text(encoding="utf-8"))
if len(fixture.get("games", [])) < 5:
    failures.append("Demo fixture must contain at least five games.")
for game in fixture.get("games", []):
    for key in ("modelProbability", "baselineProbability", "impliedProbability", "confidence"):
        value = game.get(key)
        if not isinstance(value, (int, float)) or not 0 <= value <= 1:
            failures.append(f"{game.get('id')}.{key} must be between 0 and 1.")
    for key in ("marketKey", "outcome", "bestBookmakerKey", "bestBookmakerTitle", "modelVersion", "calculatedAt"):
        if not game.get(key):
            failures.append(f"{game.get('id')}.{key} is required for market transparency.")
    if not isinstance(game.get("bookmakerCount"), int) or game["bookmakerCount"] < 1:
        failures.append(f"{game.get('id')}.bookmakerCount must be at least 1.")

market_prices = fixture.get("marketPrices", {})
for game in fixture.get("games", []):
    quotes = market_prices.get(game.get("id"), [])
    if len(quotes) < 3:
        failures.append(f"{game.get('id')} must include at least three bookmaker quotes.")
    if quotes and not any(quote.get("isBestPrice") for quote in quotes):
        failures.append(f"{game.get('id')} market prices must identify a best price.")

for script in (
    ROOT / "install_backend.sh",
    ROOT / "start_api.sh",
    PROJECT_ROOT / "scripts" / "ubuntu_update.sh",
    PROJECT_ROOT / "scripts" / "ubuntu_smoke_test.sh",
):
    if not script.exists():
        failures.append(f"Missing Ubuntu deployment script: {script.relative_to(PROJECT_ROOT)}")

if failures:
    raise SystemExit("MPIE backend validation failed:\n - " + "\n - ".join(failures))

print("MPIE backend validation passed.")
print("Validated Python syntax, ClickHouse aggregate design, OAuth state and verification, bounded analytical reads, API routes, deployment scripts, state writes, and demo fixtures.")
