# MPIE API Backend v1.1.2

## Run

```bash
bash install_backend.sh
cp .env.example .env   # only if backend/.env does not already exist
bash start_api.sh
```

The launcher uses Python 3.12 through `uv`, installs pinned requirements only when they change, loads `backend/.env`, and binds to `0.0.0.0:8000` by default.

## Modes

- `MPIE_DEMO_MODE=true`: bundled analytical fixtures plus SQLite user state
- `MPIE_DEMO_MODE=false`: ClickHouse analytical reads plus SQLite user state

SQLite stores watchlist, portfolio, and Playbook data. Set `MPIE_STATE_DB` to a durable volume in production.

Portfolio positions persist the selected sportsbook through nullable
`bookmaker_key` and `bookmaker_title` columns. The migration is idempotent and
preserves existing rows.

## Market-price route

```text
GET /api/v1/markets/{event_id}/prices?market_key={market_key}&outcome={outcome}
```

ClickHouse mode reads the latest row per sportsbook from `mpie.odds_snapshot`,
calculates a consensus price, identifies the best active price, and labels each
quote as active, stale, or suspended.

## Playbook routes

```text
GET    /api/v1/playbook
POST   /api/v1/playbook
GET    /api/v1/playbook/{entry_id}
PATCH  /api/v1/playbook/{entry_id}
DELETE /api/v1/playbook/{entry_id}
```

Titles are trimmed and limited to 160 characters. Markdown bodies are limited to 100,000 characters. All SQL uses bound parameters and every operation is scoped to the current user UUID.

## Query controls

- `MPIE_MARKET_LIMIT`: default 100, range 1–500
- `MPIE_MARKET_LOOKBACK_DAYS`: default 30, range 1–365
- `MPIE_SIGNAL_LIMIT`: default 50, range 1–500
- `MPIE_ODDS_STALE_SECONDS`: default 300, range 30–86,400

## Verification

```bash
.venv/bin/python scripts/validate_backend.py
.venv/bin/python -m unittest discover -s tests -v
../scripts/ubuntu_smoke_test.sh
```

## Documentation

- `http://localhost:8000/docs`
- `http://localhost:8000/openapi.json`
- `http://localhost:8000/health`

## Authentication warning

`X-MPIE-User-ID` is a development identity header, not proof of identity.

## OAuth prebuild

The backend includes additive `users`, `auth_identities`, and `auth_sessions`
tables plus Google/Apple ID-token verification and MPIE access/refresh sessions.
Authentication remains disabled by default:

```env
MPIE_AUTH_ENABLED=false
```

When disabled, `X-MPIE-User-ID` keeps the existing development workflow. When
enabled, protected state routes require an MPIE Bearer access token. Configure
provider audiences and a 32+ character session secret before enabling. See
`../OAUTH_SETUP.md`.

OAuth routes:

```text
POST /api/v1/auth/google
POST /api/v1/auth/apple
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
GET  /api/v1/auth/me
```

## Account lifecycle routes

```text
POST   /api/v1/auth/apple/webhook
DELETE /api/v1/auth/me
```

`DELETE /api/v1/auth/me` requires an authenticated Bearer session and removes the
internal user plus owned SQLite state after audit de-identification. Apple
notifications are signature-verified and handled idempotently. `consent-revoked`
detaches Apple only; `account-delete` deletes the full user only when no other
provider identity remains.

New auth sessions store the issuing `identity_id`. Existing unscoped sessions are
revoked conservatively when an identity is disconnected.
