#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BACKEND_DIR"

if [[ "${MPIE_SKIP_INSTALL:-false}" != "true" ]]; then
  bash "$BACKEND_DIR/install_backend.sh"
fi

PORT="${PORT:-8000}"
HOST="${HOST:-0.0.0.0}"
args=(app.main:app --host "$HOST" --port "$PORT")

if [[ -f .env ]]; then
  args+=(--env-file .env)
fi
if [[ "${MPIE_RELOAD:-false}" == "true" ]]; then
  args+=(--reload)
fi

exec .venv/bin/python -m uvicorn "${args[@]}"
