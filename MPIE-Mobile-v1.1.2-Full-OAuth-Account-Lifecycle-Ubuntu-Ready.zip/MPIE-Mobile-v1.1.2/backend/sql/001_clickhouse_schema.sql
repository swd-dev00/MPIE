-- MPIE analytical schema for ClickHouse 24.x+
-- Sierra Warren Developments, LLC
-- Analytical facts live in ClickHouse. Transactional user state is handled by the API state store.

CREATE DATABASE IF NOT EXISTS mpie;

CREATE TABLE IF NOT EXISTS mpie.raw_odds_events
(
    event_id String,
    sport_key LowCardinality(String),
    sport_title String,
    commence_time DateTime64(3, 'UTC'),
    home_team String,
    away_team String,
    bookmaker_key LowCardinality(String),
    bookmaker_title String,
    market_key LowCardinality(String),
    market_name String,
    outcome String,
    price Float64,
    implied_prob Float64,
    odds_format LowCardinality(String),
    api_received_at DateTime64(3, 'UTC'),
    inserted_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(commence_time)
ORDER BY (event_id, bookmaker_key, market_key, outcome, api_received_at)
TTL inserted_at + INTERVAL 18 MONTH DELETE;

CREATE TABLE IF NOT EXISTS mpie.event_catalog
(
    event_id String,
    sport_key LowCardinality(String),
    league LowCardinality(String),
    status LowCardinality(String),
    commence_time DateTime64(3, 'UTC'),
    venue String,
    home_name String,
    home_city String,
    home_abbreviation String,
    home_record String,
    home_score Nullable(Int32),
    away_name String,
    away_city String,
    away_abbreviation String,
    away_record String,
    away_score Nullable(Int32),
    updated_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = ReplacingMergeTree(updated_at)
PARTITION BY toYYYYMM(commence_time)
ORDER BY event_id;

CREATE TABLE IF NOT EXISTS mpie.odds_snapshot
(
    event_id String,
    sport_key LowCardinality(String),
    sport_title String,
    commence_time DateTime64(3, 'UTC'),
    home_team String,
    away_team String,
    bookmaker_key LowCardinality(String),
    bookmaker_title String,
    market_key LowCardinality(String),
    market_name String,
    outcome String,
    last_price Float64,
    last_implied_prob Float64,
    last_update DateTime64(3, 'UTC')
)
ENGINE = ReplacingMergeTree(last_update)
PARTITION BY toYYYYMM(commence_time)
ORDER BY (event_id, bookmaker_key, market_key, outcome);

DROP VIEW IF EXISTS mpie.mv_update_snapshot;
CREATE MATERIALIZED VIEW mpie.mv_update_snapshot
TO mpie.odds_snapshot
AS
SELECT
    event_id,
    argMax(sport_key, api_received_at) AS sport_key,
    argMax(sport_title, api_received_at) AS sport_title,
    argMax(commence_time, api_received_at) AS commence_time,
    argMax(home_team, api_received_at) AS home_team,
    argMax(away_team, api_received_at) AS away_team,
    bookmaker_key,
    argMax(bookmaker_title, api_received_at) AS bookmaker_title,
    market_key,
    argMax(market_name, api_received_at) AS market_name,
    outcome,
    argMax(price, api_received_at) AS last_price,
    argMax(implied_prob, api_received_at) AS last_implied_prob,
    max(api_received_at) AS last_update
FROM mpie.raw_odds_events
GROUP BY event_id, bookmaker_key, market_key, outcome;

-- Aggregate-state tables are required because a materialized view only sees each inserted block.
-- Storing states allows ClickHouse merges and final queries to combine every partial block in a bucket.
CREATE TABLE IF NOT EXISTS mpie.odds_velocity_5m_state
(
    event_id String,
    bookmaker_key LowCardinality(String),
    market_key LowCardinality(String),
    outcome String,
    window_start DateTime64(3, 'UTC'),
    first_price AggregateFunction(argMin, Float64, DateTime64(3, 'UTC')),
    last_price AggregateFunction(argMax, Float64, DateTime64(3, 'UTC')),
    first_at AggregateFunction(min, DateTime64(3, 'UTC')),
    last_at AggregateFunction(max, DateTime64(3, 'UTC')),
    ticks AggregateFunction(count)
)
ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(window_start)
ORDER BY (event_id, bookmaker_key, market_key, outcome, window_start)
TTL window_start + INTERVAL 18 MONTH DELETE;

DROP VIEW IF EXISTS mpie.mv_populate_velocity_5m;
CREATE MATERIALIZED VIEW mpie.mv_populate_velocity_5m
TO mpie.odds_velocity_5m_state
AS
SELECT
    event_id,
    bookmaker_key,
    market_key,
    outcome,
    toStartOfFiveMinutes(api_received_at) AS window_start,
    argMinState(price, api_received_at) AS first_price,
    argMaxState(price, api_received_at) AS last_price,
    minState(api_received_at) AS first_at,
    maxState(api_received_at) AS last_at,
    countState() AS ticks
FROM mpie.raw_odds_events
GROUP BY event_id, bookmaker_key, market_key, outcome, window_start;

CREATE OR REPLACE VIEW mpie.odds_velocity_5m AS
SELECT
    event_id,
    bookmaker_key,
    market_key,
    outcome,
    window_start,
    window_start + INTERVAL 5 MINUTE AS window_end,
    argMinMerge(first_price) AS first_price,
    argMaxMerge(last_price) AS last_price,
    last_price - first_price AS price_delta,
    if(
        dateDiff('millisecond', minMerge(first_at), maxMerge(last_at)) > 0,
        price_delta / dateDiff('millisecond', minMerge(first_at), maxMerge(last_at)) * 60000.0,
        0.0
    ) AS price_delta_per_min,
    countMerge(ticks) AS ticks
FROM mpie.odds_velocity_5m_state
GROUP BY event_id, bookmaker_key, market_key, outcome, window_start;

CREATE TABLE IF NOT EXISTS mpie.hourly_market_state
(
    event_id String,
    sport_key LowCardinality(String),
    market_key LowCardinality(String),
    outcome String,
    hour DateTime64(3, 'UTC'),
    min_price AggregateFunction(min, Float64),
    max_price AggregateFunction(max, Float64),
    avg_price AggregateFunction(avg, Float64),
    ticks AggregateFunction(count)
)
ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(hour)
ORDER BY (event_id, sport_key, market_key, outcome, hour)
TTL hour + INTERVAL 36 MONTH DELETE;

DROP VIEW IF EXISTS mpie.mv_hourly_market_state;
CREATE MATERIALIZED VIEW mpie.mv_hourly_market_state
TO mpie.hourly_market_state
AS
SELECT
    event_id,
    sport_key,
    market_key,
    outcome,
    toStartOfHour(api_received_at) AS hour,
    minState(price) AS min_price,
    maxState(price) AS max_price,
    avgState(price) AS avg_price,
    countState() AS ticks
FROM mpie.raw_odds_events
GROUP BY event_id, sport_key, market_key, outcome, hour;

CREATE OR REPLACE VIEW mpie.hourly_market_aggregates AS
SELECT
    event_id,
    sport_key,
    market_key,
    outcome,
    hour,
    minMerge(min_price) AS min_price,
    maxMerge(max_price) AS max_price,
    avgMerge(avg_price) AS avg_price,
    countMerge(ticks) AS ticks
FROM mpie.hourly_market_state
GROUP BY event_id, sport_key, market_key, outcome, hour;

CREATE TABLE IF NOT EXISTS mpie.predictions
(
    prediction_id UUID DEFAULT generateUUIDv4(),
    event_id String,
    sport_key LowCardinality(String),
    market_key LowCardinality(String),
    market_name String,
    outcome String,
    pick_label String,
    pick_side LowCardinality(String),
    model_prob Float64,
    baseline_prob Float64,
    market_implied_prob Float64,
    edge Float64,
    confidence Float64,
    recommended_size_pct Float64,
    model_version LowCardinality(String),
    calculated_at DateTime64(3, 'UTC') DEFAULT now64(3),
    CONSTRAINT predictions_model_prob CHECK model_prob >= 0 AND model_prob <= 1,
    CONSTRAINT predictions_baseline_prob CHECK baseline_prob >= 0 AND baseline_prob <= 1,
    CONSTRAINT predictions_market_prob CHECK market_implied_prob >= 0 AND market_implied_prob <= 1,
    CONSTRAINT predictions_confidence CHECK confidence >= 0 AND confidence <= 1
)
ENGINE = ReplacingMergeTree(calculated_at)
PARTITION BY toYYYYMM(calculated_at)
ORDER BY (event_id, market_key, outcome);

CREATE TABLE IF NOT EXISTS mpie.market_pressure
(
    event_id String,
    market_key LowCardinality(String),
    outcome String,
    pressure_load_index Float64,
    pressure_diff_score Float64,
    pressure_factor_labels Array(String),
    pressure_factor_short_labels Array(String),
    pressure_factor_impacts Array(Float64),
    pressure_factor_details Array(String),
    attribution String,
    updated_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = ReplacingMergeTree(updated_at)
PARTITION BY toYYYYMM(updated_at)
ORDER BY (event_id, market_key, outcome);

CREATE TABLE IF NOT EXISTS mpie.signal_history
(
    signal_id UUID DEFAULT generateUUIDv4(),
    event_id String,
    sport_key LowCardinality(String),
    market_key LowCardinality(String),
    signal_type LowCardinality(String),
    title String,
    subtitle String,
    severity LowCardinality(String),
    direction LowCardinality(String),
    value Float64,
    strength Float64,
    description String,
    triggered_at DateTime64(3, 'UTC') DEFAULT now64(3),
    CONSTRAINT signals_strength CHECK strength >= 0 AND strength <= 1
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(triggered_at)
ORDER BY (sport_key, triggered_at, signal_type, event_id)
TTL triggered_at + INTERVAL 36 MONTH DELETE;
