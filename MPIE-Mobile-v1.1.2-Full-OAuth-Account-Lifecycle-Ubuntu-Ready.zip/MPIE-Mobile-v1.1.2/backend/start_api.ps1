$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    throw "uv is required. Install it from https://docs.astral.sh/uv/ and rerun."
}

uv python install 3.12
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    uv venv --python 3.12 .venv
}

$stampFile = ".venv\.mpie-requirements.sha256"
$currentHash = (Get-FileHash "requirements.txt" -Algorithm SHA256).Hash.ToLowerInvariant()
$savedHash = if (Test-Path $stampFile) { (Get-Content $stampFile -Raw).Trim() } else { "" }
if ($savedHash -ne $currentHash) {
    uv pip install --python .venv\Scripts\python.exe -r requirements.txt
    Set-Content -Path $stampFile -Value $currentHash -NoNewline
}

New-Item -ItemType Directory -Force -Path data | Out-Null
$port = if ($env:PORT) { $env:PORT } else { "8000" }
$arguments = @("-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", $port)
if (Test-Path ".env") { $arguments += @("--env-file", ".env") }
if ($env:MPIE_RELOAD -eq "true") { $arguments += "--reload" }
& .venv\Scripts\python.exe @arguments
