from __future__ import annotations

import sys
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from app.repository import AnalyticsRepository


class RepositorySafetyTest(unittest.TestCase):
    def make_settings(self, **overrides):
        values = {
            "fixture_path": Path(tempfile.gettempdir()) / "missing-mpie-fixture.json",
            "demo_mode": False,
            "clickhouse_host": "localhost",
            "clickhouse_port": 8123,
            "clickhouse_user": "default",
            "clickhouse_password": "",
            "clickhouse_database": "mpie",
            "clickhouse_secure": False,
            "market_limit": 100,
            "market_lookback_days": 30,
            "signal_limit": 50,
            "odds_stale_seconds": 300,
        }
        values.update(overrides)
        return SimpleNamespace(**values)

    def test_shared_client_disables_generated_sessions(self) -> None:
        captured = {}
        fake_client = object()

        def get_client(**kwargs):
            captured.update(kwargs)
            return fake_client

        fake_module = SimpleNamespace(get_client=get_client)
        with patch.dict(sys.modules, {"clickhouse_connect": fake_module}):
            repository = AnalyticsRepository(self.make_settings())
            self.assertIs(repository._get_client(), fake_client)

        self.assertIs(captured["autogenerate_session_id"], False)
        self.assertNotIn("zero_as_nil", captured.get("settings", {}))
        self.assertNotIn("float_overflow_mode", captured.get("settings", {}))

    def test_single_game_uses_filtered_clickhouse_path(self) -> None:
        repository = AnalyticsRepository(self.make_settings())
        repository._get_clickhouse_games = Mock(return_value=["game-result"])

        result = repository.get_game("event-123")

        self.assertEqual(result, "game-result")
        repository._get_clickhouse_games.assert_called_once_with(event_id="event-123", limit=1)

    def test_pressure_array_mismatch_is_observable_without_crashing(self) -> None:
        row = (
            "event-1",
            "h2h",
            "home",
            75.0,
            0.12,
            ["Velocity", "Liquidity"],
            ["VEL"],
            [0.6, 0.4],
            ["Fast move", "Deep market"],
            "Attribution",
            "2026-07-10T00:00:00Z",
        )

        with self.assertLogs("app.repository", level="ERROR") as logs:
            factors = AnalyticsRepository._pressure_factors(row)

        self.assertEqual(len(factors), 1)
        self.assertIn("array length mismatch", " ".join(logs.output))

    def test_clickhouse_game_mapping_uses_filtered_related_queries(self) -> None:
        now = datetime.now(UTC)

        class FakeClient:
            def __init__(self):
                self.calls = []

            def query(self, query, parameters=None):
                self.calls.append((query, parameters or {}))
                if "FROM mpie.predictions" in query:
                    rows = [[
                        "event-1", "h2h", "Home ML", "basketball_nba", "Moneyline",
                        "Home ML", "home", 0.61, 0.55, 0.52, 0.09, 0.84, "model-v2.3", now, 1,
                    ]]
                elif "FROM mpie.event_catalog" in query:
                    rows = [[
                        "event-1", "NBA", "UPCOMING", now, "Arena",
                        "Home Team", "Home City", "HOM", "10-2", None,
                        "Away Team", "Away City", "AWY", "8-4", None,
                    ]]
                elif "FROM mpie.market_pressure" in query:
                    rows = [[
                        "event-1", "h2h", "Home ML", 72.0, 0.06,
                        ["Velocity"], ["VEL"], [0.7], ["Fast move"],
                        "Pressure supports the home side.", now,
                    ]]
                elif "FROM mpie.odds_snapshot" in query:
                    rows = [
                        [
                            "event-1", "draftkings", "DraftKings", "h2h",
                            "Moneyline", "Home ML", 2.05, 0.4878, now,
                        ],
                        [
                            "event-1", "fanduel", "FanDuel", "h2h",
                            "Moneyline", "Home ML", 2.02, 0.4950, now,
                        ],
                    ]
                else:
                    raise AssertionError(query)
                return SimpleNamespace(result_rows=rows)

        repository = AnalyticsRepository(self.make_settings())
        fake_client = FakeClient()
        repository._client = fake_client

        games = repository.get_games()

        self.assertEqual(len(games), 1)
        game = games[0]
        self.assertEqual(game.id, "event-1")
        self.assertEqual(game.decimalOdds, 2.05)
        self.assertAlmostEqual(game.impliedProbability, 0.4878)
        self.assertEqual(game.bestBookmakerKey, "draftkings")
        self.assertEqual(game.bestBookmakerTitle, "DraftKings")
        self.assertEqual(game.bookmakerCount, 2)
        self.assertIsNotNone(game.consensusDecimalOdds)
        self.assertEqual(game.pressureIndex, 72.0)
        self.assertEqual(game.modelVersion, "model-v2.3")
        self.assertEqual(game.calculatedAt, now)
        for _, parameters in fake_client.calls[1:]:
            self.assertEqual(parameters["event_ids"], ["event-1"])

    def test_market_price_query_is_filtered_and_marks_best_price(self) -> None:
        now = datetime.now(UTC)

        class FakeClient:
            def __init__(self):
                self.query_text = ""
                self.parameters = {}

            def query(self, query, parameters=None):
                self.query_text = query
                self.parameters = parameters or {}
                return SimpleNamespace(
                    result_rows=[
                        [
                            "event-1", "book-a", "Book A", "h2h", "Moneyline",
                            "Home ML", 2.10, 0.4762, now,
                        ],
                        [
                            "event-1", "book-b", "Book B", "h2h", "Moneyline",
                            "Home ML", 2.04, 0.4902, now,
                        ],
                    ]
                )

        repository = AnalyticsRepository(self.make_settings())
        fake_client = FakeClient()
        repository._client = fake_client

        prices = repository.get_market_prices(
            "event-1",
            market_key="h2h",
            outcome="Home ML",
        )

        self.assertIsNotNone(prices)
        assert prices is not None
        self.assertEqual(prices.bestBookmakerKey, "book-a")
        self.assertEqual(prices.quoteCount, 2)
        self.assertTrue(prices.quotes[0].isBestPrice)
        self.assertIn("market_key = {market_key:String}", fake_client.query_text)
        self.assertIn("outcome = {outcome:String}", fake_client.query_text)
        self.assertEqual(fake_client.parameters["event_ids"], ["event-1"])
        self.assertEqual(fake_client.parameters["market_key"], "h2h")
        self.assertEqual(fake_client.parameters["outcome"], "Home ML")


if __name__ == "__main__":
    unittest.main()
