from __future__ import annotations

import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

import app.main as main_module
from app.auth.claims import OAuthVerificationError
from app.auth.service import AuthService
from app.config import Settings
from app.state import StateStore


class AuthApiDisabledContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(main_module.app)

    def test_provider_endpoints_are_safely_disabled_by_default(self) -> None:
        payload = {"idToken": "x" * 64, "nonce": "nonce-123"}
        self.assertEqual(self.client.post("/api/v1/auth/google", json=payload).status_code, 503)
        self.assertEqual(self.client.post("/api/v1/auth/apple", json=payload).status_code, 503)
        self.assertEqual(self.client.get("/api/v1/auth/me").status_code, 503)
        self.assertEqual(self.client.delete("/api/v1/auth/me").status_code, 503)

    def test_invalid_apple_webhook_signature_is_logged_and_acknowledged(self) -> None:
        class RejectingService:
            def process_apple_notification(self, _: str) -> dict[str, str]:
                raise OAuthVerificationError("invalid signature")

        with patch.object(main_module, "auth_service", RejectingService()):
            response = self.client.post(
                "/api/v1/auth/apple/webhook",
                json={"payload": "x" * 64},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ignored"})


class AuthenticatedAccountDeletionContractTest(unittest.TestCase):
    def test_delete_me_removes_user_and_revokes_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            settings = Settings(
                auth_enabled=True,
                session_secret="s" * 64,
                sqlite_path=root / "state.db",
                fixture_path=root / "missing.json",
            )
            store = StateStore(settings.sqlite_path, settings.fixture_path)
            service = AuthService(settings, store)
            try:
                user = store.create_user(email="delete@example.com")
                store.link_identity_to_user(
                    user_id=user.id,
                    provider="google",
                    provider_subject="delete-api-sub",
                    provider_email="delete@example.com",
                    email_verified=True,
                )
                identity = store.find_identity("google", "delete-api-sub")
                assert identity is not None
                session_id = store.create_auth_session(
                    user.id,
                    "delete-api-refresh-hash",
                    datetime.now(UTC) + timedelta(hours=1),
                    identity_id=str(identity["identity_id"]),
                )
                access_token = service.sessions.create_access_token(user, session_id)

                with (
                    patch.object(main_module, "settings", settings),
                    patch.object(main_module, "auth_service", service),
                ):
                    response = TestClient(main_module.app).delete(
                        "/api/v1/auth/me",
                        headers={"Authorization": f"Bearer {access_token}"},
                    )

                self.assertEqual(response.status_code, 204)
                self.assertIsNone(store.get_user_by_id(user.id))
            finally:
                service.close()


if __name__ == "__main__":
    unittest.main()
