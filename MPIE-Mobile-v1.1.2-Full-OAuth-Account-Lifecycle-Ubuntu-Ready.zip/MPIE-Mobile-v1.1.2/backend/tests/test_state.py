from __future__ import annotations

import sqlite3
from contextlib import closing
import tempfile
import unittest
from pathlib import Path

from app.models import PositionCreate
from app.state import StateStore


class StateStoreMigrationTest(unittest.TestCase):
    def test_legacy_notes_are_migrated_to_playbook(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            database = Path(temp_dir) / "state.db"
            with closing(sqlite3.connect(database)) as connection:
                connection.executescript(
                    """
                    CREATE TABLE notes (
                        note_id TEXT PRIMARY KEY,
                        user_id TEXT NOT NULL,
                        title TEXT NOT NULL,
                        body_markdown TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    );
                    INSERT INTO notes(
                        note_id, user_id, title, body_markdown, created_at, updated_at
                    ) VALUES (
                        'legacy-1',
                        '123e4567-e89b-12d3-a456-426614174000',
                        'Legacy idea',
                        '# Preserve me',
                        '2026-07-10T20:00:00+00:00',
                        '2026-07-10T20:05:00+00:00'
                    );
                    """
                )

            store = StateStore(database, Path(temp_dir) / "missing-fixture.json")
            entries = store.list_playbook_entries(
                "123e4567-e89b-12d3-a456-426614174000"
            )

            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0].id, "legacy-1")
            self.assertEqual(entries[0].title, "Legacy idea")
            self.assertEqual(entries[0].bodyMarkdown, "# Preserve me")

            # Re-initialization is idempotent and does not duplicate migrated rows.
            store = StateStore(database, Path(temp_dir) / "missing-fixture.json")
            self.assertEqual(
                len(
                    store.list_playbook_entries(
                        "123e4567-e89b-12d3-a456-426614174000"
                    )
                ),
                1,
            )

    def test_portfolio_bookmaker_columns_migrate_and_persist(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            database = Path(temp_dir) / "state.db"
            with closing(sqlite3.connect(database)) as connection:
                connection.executescript(
                    """
                    CREATE TABLE portfolio_positions (
                        position_id TEXT PRIMARY KEY,
                        user_id TEXT NOT NULL,
                        event_id TEXT NOT NULL,
                        market_key TEXT NOT NULL,
                        outcome TEXT NOT NULL,
                        label TEXT NOT NULL,
                        game_label TEXT NOT NULL,
                        entry_price REAL NOT NULL,
                        size_units REAL NOT NULL,
                        status TEXT NOT NULL,
                        pnl REAL NOT NULL DEFAULT 0,
                        opened_at TEXT NOT NULL
                    );
                    """
                )

            store = StateStore(database, Path(temp_dir) / "missing-fixture.json")
            with closing(sqlite3.connect(database)) as connection:
                columns = {
                    row[1]
                    for row in connection.execute(
                        "PRAGMA table_info(portfolio_positions)"
                    ).fetchall()
                }
            self.assertIn("bookmaker_key", columns)
            self.assertIn("bookmaker_title", columns)

            user_id = "123e4567-e89b-12d3-a456-426614174000"
            created = store.create_position(
                user_id,
                PositionCreate(
                    eventId="event-1",
                    marketKey="h2h",
                    outcome="Home ML",
                    entryPrice=2.10,
                    sizeUnits=20,
                    bookmakerKey="book-a",
                    bookmakerTitle="Book A",
                ),
            )
            self.assertEqual(created.bookmakerKey, "book-a")
            self.assertEqual(created.bookmakerTitle, "Book A")

            stored = store.list_positions(user_id)
            self.assertEqual(len(stored), 1)
            self.assertEqual(stored[0].bookmakerKey, "book-a")
            self.assertEqual(stored[0].bookmakerTitle, "Book A")


if __name__ == "__main__":
    unittest.main()
