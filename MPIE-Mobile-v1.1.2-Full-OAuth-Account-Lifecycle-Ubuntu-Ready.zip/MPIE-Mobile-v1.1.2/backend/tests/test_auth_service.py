from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app.auth.claims import ProviderClaims
from app.auth.service import AuthService
from app.auth.sessions import SessionTokenError
from app.config import Settings
from app.state import StateStore


class _GoogleVerifier:
    def verify(self, _: str, *, expected_nonce: str | None = None) -> ProviderClaims:
        if expected_nonce != "nonce":
            raise AssertionError("expected nonce was not forwarded")
        return ProviderClaims(
            provider="google",
            subject="google-sub",
            email="user@example.com",
            email_verified=True,
            display_name="MPIE User",
        )


class AuthServiceIntegrationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.store = StateStore(
            Path(self.temp_dir.name) / "state.db",
            Path(self.temp_dir.name) / "missing.json",
        )
        self.settings = Settings(
            auth_enabled=True,
            session_secret="s" * 64,
            session_ttl_seconds=3600,
            refresh_ttl_seconds=7200,
            google_client_ids=("google-client",),
            apple_client_ids=("apple-client",),
            sqlite_path=Path(self.temp_dir.name) / "state.db",
            fixture_path=Path(self.temp_dir.name) / "missing.json",
        )
        self.service = AuthService(self.settings, self.store)
        self.service.google = _GoogleVerifier()

    def tearDown(self) -> None:
        self.service.close()
        self.temp_dir.cleanup()

    def test_login_access_refresh_and_logout(self) -> None:
        issued = self.service.login_google("token", "nonce")
        self.assertEqual(issued.user.email, "user@example.com")
        authenticated = self.service.authenticate_access_token(issued.accessToken)
        self.assertEqual(authenticated.user_id, issued.user.id)

        refreshed = self.service.refresh(issued.refreshToken)
        self.assertEqual(refreshed.user.id, issued.user.id)
        with self.assertRaises(SessionTokenError):
            self.service.refresh(issued.refreshToken)

        self.service.logout(refreshed.refreshToken)
        with self.assertRaises(SessionTokenError):
            self.service.authenticate_access_token(refreshed.accessToken)


if __name__ == "__main__":
    unittest.main()
