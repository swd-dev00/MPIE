from __future__ import annotations

import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path

from app.auth.sessions import SessionManager
from app.models import PlaybookEntryCreate
from app.state import StateStore


class AuthStateStoreTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.store = StateStore(
            Path(self.temp_dir.name) / "state.db",
            Path(self.temp_dir.name) / "missing-fixture.json",
        )

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_create_find_update_and_disable_user(self) -> None:
        user = self.store.create_user(email="USER@EXAMPLE.COM", display_name="Sierra")
        self.assertEqual(user.email, "user@example.com")
        self.assertEqual(self.store.get_user_by_id(user.id).displayName, "Sierra")

        updated = self.store.update_user_profile(user.id, display_name="Sierra Warren")
        self.assertIsNotNone(updated)
        self.assertEqual(updated.displayName, "Sierra Warren")
        self.assertTrue(self.store.disable_user(user.id))
        self.assertEqual(self.store.get_user_by_id(user.id).status, "disabled")

    def test_get_or_create_oauth_user_is_provider_subject_idempotent(self) -> None:
        first = self.store.get_or_create_oauth_user(
            provider="google",
            provider_subject="google-sub-1",
            email="user@example.com",
            email_verified=True,
            display_name="Sierra",
        )
        again = self.store.get_or_create_oauth_user(
            provider="google",
            provider_subject="google-sub-1",
            email="new@example.com",
            email_verified=True,
            display_name="Sierra Warren",
        )
        self.assertEqual(first.id, again.id)
        self.assertEqual(again.email, "new@example.com")
        self.assertEqual(self.store.find_user_by_provider("google", "google-sub-1").id, first.id)

        # A returning provider token with no email does not erase previously
        # verified identity metadata.
        self.store.get_or_create_oauth_user(
            provider="google",
            provider_subject="google-sub-1",
            email=None,
            email_verified=False,
            display_name=None,
        )
        identity = self.store.find_identity("google", "google-sub-1")
        self.assertEqual(identity["provider_email"], "new@example.com")
        self.assertEqual(identity["email_verified"], 1)

        # Same email from a different provider is not silently linked.
        apple = self.store.get_or_create_oauth_user(
            provider="apple",
            provider_subject="apple-sub-1",
            email="new@example.com",
            email_verified=True,
            display_name=None,
        )
        self.assertNotEqual(apple.id, first.id)

    def test_identity_crud_helpers(self) -> None:
        user = self.store.create_user()
        self.store.create_auth_identity(
            user_id=user.id,
            provider="google",
            provider_subject="crud-sub",
            provider_email="FIRST@EXAMPLE.COM",
            email_verified=False,
        )
        identity = self.store.find_identity("google", "crud-sub")
        self.assertEqual(identity["user_id"], user.id)
        self.assertEqual(identity["provider_email"], "first@example.com")

        self.assertTrue(
            self.store.update_identity_claims(
                provider="google",
                provider_subject="crud-sub",
                provider_email="verified@example.com",
                email_verified=True,
            )
        )
        identity = self.store.find_identity("google", "crud-sub")
        self.assertEqual(identity["provider_email"], "verified@example.com")
        self.assertEqual(identity["email_verified"], 1)
        self.assertTrue(
            self.store.delete_auth_identity(
                user_id=user.id,
                provider="google",
                provider_subject="crud-sub",
            )
        )
        self.assertIsNone(self.store.find_identity("google", "crud-sub"))

    def test_identity_cannot_be_linked_to_two_users(self) -> None:
        first = self.store.create_user()
        second = self.store.create_user()
        self.store.link_identity_to_user(
            user_id=first.id,
            provider="google",
            provider_subject="sub",
            provider_email=None,
            email_verified=False,
        )
        with self.assertRaisesRegex(ValueError, "another MPIE user"):
            self.store.link_identity_to_user(
                user_id=second.id,
                provider="google",
                provider_subject="sub",
                provider_email=None,
                email_verified=False,
            )

    def test_refresh_session_rotation_and_revocation(self) -> None:
        user = self.store.create_user()
        manager = SessionManager(
            secret="s" * 64,
            access_ttl_seconds=3600,
            refresh_ttl_seconds=7200,
            issuer="mpie-api",
            audience="mpie-mobile",
        )
        old_token = manager.new_refresh_token()
        session_id = self.store.create_auth_session(
            user.id,
            manager.hash_refresh_token(old_token),
            datetime.now(UTC) + timedelta(hours=2),
        )
        self.assertTrue(self.store.is_auth_session_active(session_id, user.id))

        new_token = manager.new_refresh_token()
        rotated = self.store.rotate_auth_session(
            manager.hash_refresh_token(old_token),
            manager.hash_refresh_token(new_token),
            datetime.now(UTC) + timedelta(hours=2),
        )
        self.assertIsNotNone(rotated)
        self.assertEqual(rotated[0].id, user.id)
        self.assertEqual(rotated[1], session_id)
        self.assertIsNone(
            self.store.rotate_auth_session(
                manager.hash_refresh_token(old_token),
                manager.hash_refresh_token(manager.new_refresh_token()),
                datetime.now(UTC) + timedelta(hours=2),
            )
        )
        self.assertTrue(self.store.revoke_auth_session(manager.hash_refresh_token(new_token)))
        self.assertFalse(self.store.is_auth_session_active(session_id, user.id))

    def test_auth_migration_preserves_existing_user_state(self) -> None:
        user_id = "123e4567-e89b-12d3-a456-426614174000"
        self.store.add_watchlist(user_id, "event-1")
        entry = self.store.create_playbook_entry(
            user_id,
            PlaybookEntryCreate(title="Preserved", bodyMarkdown="# Keep"),
        )
        self.store.create_user(user_id=user_id, display_name="Existing User")
        self.assertEqual(self.store.get_watchlist(user_id), ["event-1"])
        self.assertEqual(self.store.get_playbook_entry(user_id, entry.id).title, "Preserved")


    def test_identity_scoped_session_revocation(self) -> None:
        user = self.store.create_user()
        self.store.link_identity_to_user(
            user_id=user.id,
            provider="apple",
            provider_subject="apple-session",
            provider_email=None,
            email_verified=False,
        )
        identity = self.store.find_identity("apple", "apple-session")
        self.assertIsNotNone(identity)
        session_id = self.store.create_auth_session(
            user.id,
            "identity-refresh-hash",
            datetime.now(UTC) + timedelta(hours=1),
            identity_id=str(identity["identity_id"]),
        )
        self.assertEqual(
            self.store.revoke_all_sessions_for_identity(str(identity["identity_id"])),
            1,
        )
        self.assertFalse(self.store.is_auth_session_active(session_id, user.id))

    def test_delete_user_and_cascade_removes_owned_state(self) -> None:
        user = self.store.create_user()
        self.store.add_watchlist(user.id, "event-delete")
        self.store.create_playbook_entry(
            user.id,
            PlaybookEntryCreate(title="Delete", bodyMarkdown="# Remove"),
        )
        self.store.link_identity_to_user(
            user_id=user.id,
            provider="google",
            provider_subject="delete-sub",
            provider_email=None,
            email_verified=False,
        )
        self.assertTrue(self.store.delete_user_and_cascade(user.id))
        self.assertIsNone(self.store.get_user_by_id(user.id))
        self.assertEqual(self.store.get_watchlist(user.id), [])
        self.assertEqual(self.store.list_playbook_entries(user.id), [])
        self.assertIsNone(self.store.find_identity("google", "delete-sub"))



if __name__ == "__main__":
    unittest.main()
