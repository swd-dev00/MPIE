from __future__ import annotations

import base64
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
from cryptography.hazmat.primitives.asymmetric import rsa


def _b64url_int(value: int) -> str:
    size = max(1, (value.bit_length() + 7) // 8)
    return base64.urlsafe_b64encode(value.to_bytes(size, "big")).rstrip(b"=").decode("ascii")


def make_rsa_identity(kid: str) -> tuple[rsa.RSAPrivateKey, dict[str, str]]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    numbers = private_key.public_key().public_numbers()
    jwk = {
        "kty": "RSA",
        "kid": kid,
        "use": "sig",
        "alg": "RS256",
        "n": _b64url_int(numbers.n),
        "e": _b64url_int(numbers.e),
    }
    return private_key, jwk


def signed_token(
    private_key: rsa.RSAPrivateKey,
    kid: str,
    *,
    issuer: str,
    audience: str,
    subject: str = "provider-user-123",
    nonce: str | None = "nonce-123",
    expires_delta: timedelta = timedelta(minutes=10),
    issued_delta: timedelta = timedelta(0),
    extra: dict[str, Any] | None = None,
) -> str:
    now = datetime.now(UTC)
    payload: dict[str, Any] = {
        "iss": issuer,
        "aud": audience,
        "sub": subject,
        "iat": now + issued_delta,
        "exp": now + expires_delta,
    }
    if nonce is not None:
        payload["nonce"] = nonce
    if extra:
        payload.update(extra)
    return jwt.encode(payload, private_key, algorithm="RS256", headers={"kid": kid})
