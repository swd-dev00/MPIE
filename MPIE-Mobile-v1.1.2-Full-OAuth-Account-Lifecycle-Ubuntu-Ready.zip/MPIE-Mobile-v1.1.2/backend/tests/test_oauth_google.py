from __future__ import annotations

import unittest
from datetime import timedelta

import httpx

from app.auth.claims import OAuthVerificationError
from app.auth.google import GoogleTokenVerifier
from app.auth.jwks import JwkSetCache
from tests.oauth_test_utils import make_rsa_identity, signed_token


class GoogleOAuthVerificationTest(unittest.TestCase):
    def _verifier(self, responses: list[dict]) -> tuple[GoogleTokenVerifier, list[int]]:
        calls: list[int] = []

        def handler(_: httpx.Request) -> httpx.Response:
            index = min(len(calls), len(responses) - 1)
            calls.append(index)
            return httpx.Response(
                200,
                json=responses[index],
                headers={"Cache-Control": "public, max-age=3600"},
            )

        client = httpx.Client(transport=httpx.MockTransport(handler))
        cache = JwkSetCache("https://google.test/certs", client=client)
        return GoogleTokenVerifier(["google-client-id"], cache), calls

    def test_valid_token_returns_provider_claims(self) -> None:
        private_key, jwk = make_rsa_identity("google-1")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        token = signed_token(
            private_key,
            "google-1",
            issuer="https://accounts.google.com",
            audience="google-client-id",
            extra={"email": "USER@EXAMPLE.COM", "email_verified": True, "name": "Sierra"},
        )

        claims = verifier.verify(token, expected_nonce="nonce-123")

        self.assertEqual(claims.provider, "google")
        self.assertEqual(claims.subject, "provider-user-123")
        self.assertEqual(claims.email, "USER@EXAMPLE.COM")
        self.assertTrue(claims.email_verified)
        self.assertEqual(claims.display_name, "Sierra")

    def test_rejects_wrong_audience_issuer_expiration_and_nonce(self) -> None:
        private_key, jwk = make_rsa_identity("google-1")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        cases = [
            signed_token(private_key, "google-1", issuer="https://accounts.google.com", audience="wrong"),
            signed_token(private_key, "google-1", issuer="https://issuer.invalid", audience="google-client-id"),
            signed_token(
                private_key,
                "google-1",
                issuer="https://accounts.google.com",
                audience="google-client-id",
                expires_delta=timedelta(seconds=-1),
            ),
        ]
        for token in cases:
            with self.subTest(token=token[:20]):
                with self.assertRaises(OAuthVerificationError):
                    verifier.verify(token, expected_nonce="nonce-123")

        valid = signed_token(
            private_key,
            "google-1",
            issuer="https://accounts.google.com",
            audience="google-client-id",
        )
        with self.assertRaisesRegex(OAuthVerificationError, "nonce"):
            verifier.verify(valid, expected_nonce="different")

    def test_unknown_kid_forces_one_rotation_refresh(self) -> None:
        _, old_jwk = make_rsa_identity("old")
        new_private, new_jwk = make_rsa_identity("new")
        verifier, calls = self._verifier([{"keys": [old_jwk]}, {"keys": [new_jwk]}])
        token = signed_token(
            new_private,
            "new",
            issuer="accounts.google.com",
            audience="google-client-id",
        )

        claims = verifier.verify(token, expected_nonce="nonce-123")

        self.assertEqual(claims.subject, "provider-user-123")
        self.assertEqual(len(calls), 2)

    def test_rejects_unknown_key_after_refresh(self) -> None:
        private_key, _ = make_rsa_identity("missing")
        _, known_jwk = make_rsa_identity("known")
        verifier, calls = self._verifier([{"keys": [known_jwk]}])
        token = signed_token(
            private_key,
            "missing",
            issuer="https://accounts.google.com",
            audience="google-client-id",
        )
        with self.assertRaisesRegex(OAuthVerificationError, "unknown signing key"):
            verifier.verify(token, expected_nonce="nonce-123")
        self.assertEqual(len(calls), 2)


if __name__ == "__main__":
    unittest.main()
