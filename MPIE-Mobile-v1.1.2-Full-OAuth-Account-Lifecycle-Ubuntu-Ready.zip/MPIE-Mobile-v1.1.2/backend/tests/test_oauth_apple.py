from __future__ import annotations

import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx

from app.auth.apple import AppleTokenVerifier
from app.auth.service import AuthService
from app.config import Settings
from app.models import PlaybookEntryCreate
from app.state import StateStore
from app.auth.claims import OAuthVerificationError
from app.auth.jwks import JwkSetCache
from tests.oauth_test_utils import make_rsa_identity, signed_token


class AppleOAuthVerificationTest(unittest.TestCase):
    def _verifier(self, responses: list[dict]) -> tuple[AppleTokenVerifier, list[int]]:
        calls: list[int] = []

        def handler(_: httpx.Request) -> httpx.Response:
            index = min(len(calls), len(responses) - 1)
            calls.append(index)
            return httpx.Response(200, json=responses[index], headers={"Cache-Control": "max-age=3600"})

        client = httpx.Client(transport=httpx.MockTransport(handler))
        cache = JwkSetCache("https://apple.test/auth/keys", client=client)
        return AppleTokenVerifier(["com.sierrawarrendevelopments.mpie"], cache), calls

    def test_valid_first_login_token_returns_claims(self) -> None:
        private_key, jwk = make_rsa_identity("apple-1")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        token = signed_token(
            private_key,
            "apple-1",
            issuer="https://appleid.apple.com",
            audience="com.sierrawarrendevelopments.mpie",
            extra={"email": "private@privaterelay.appleid.com", "email_verified": "true"},
        )

        claims = verifier.verify(token, expected_nonce="nonce-123", display_name="Sierra Warren")

        self.assertEqual(claims.provider, "apple")
        self.assertEqual(claims.email, "private@privaterelay.appleid.com")
        self.assertTrue(claims.email_verified)
        self.assertEqual(claims.display_name, "Sierra Warren")

    def test_returning_user_token_does_not_require_email_or_name(self) -> None:
        private_key, jwk = make_rsa_identity("apple-1")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        token = signed_token(
            private_key,
            "apple-1",
            issuer="https://appleid.apple.com",
            audience="com.sierrawarrendevelopments.mpie",
        )
        claims = verifier.verify(token, expected_nonce="nonce-123")
        self.assertIsNone(claims.email)
        self.assertIsNone(claims.display_name)

    def test_rejects_wrong_audience_issuer_expiration_and_nonce(self) -> None:
        private_key, jwk = make_rsa_identity("apple-1")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        cases = [
            signed_token(private_key, "apple-1", issuer="https://appleid.apple.com", audience="wrong"),
            signed_token(private_key, "apple-1", issuer="https://issuer.invalid", audience="com.sierrawarrendevelopments.mpie"),
            signed_token(
                private_key,
                "apple-1",
                issuer="https://appleid.apple.com",
                audience="com.sierrawarrendevelopments.mpie",
                expires_delta=timedelta(seconds=-1),
            ),
        ]
        for token in cases:
            with self.subTest(token=token[:20]):
                with self.assertRaises(OAuthVerificationError):
                    verifier.verify(token, expected_nonce="nonce-123")

        valid = signed_token(
            private_key,
            "apple-1",
            issuer="https://appleid.apple.com",
            audience="com.sierrawarrendevelopments.mpie",
        )
        with self.assertRaisesRegex(OAuthVerificationError, "nonce"):
            verifier.verify(valid, expected_nonce="different")

    def test_valid_server_notification_returns_events_claim(self) -> None:
        private_key, jwk = make_rsa_identity("apple-notification")
        verifier, _ = self._verifier([{"keys": [jwk]}])
        token = signed_token(
            private_key,
            "apple-notification",
            issuer="https://appleid.apple.com",
            audience="com.sierrawarrendevelopments.mpie",
            nonce=None,
            extra={"events": '{"type":"account-delete","sub":"apple-sub"}'},
        )
        claims = verifier.verify_notification(token)
        self.assertIn("account-delete", str(claims["events"]))

    def test_unknown_kid_forces_rotation_refresh(self) -> None:
        _, old_jwk = make_rsa_identity("old")
        new_private, new_jwk = make_rsa_identity("new")
        verifier, calls = self._verifier([{"keys": [old_jwk]}, {"keys": [new_jwk]}])
        token = signed_token(
            new_private,
            "new",
            issuer="https://appleid.apple.com",
            audience="com.sierrawarrendevelopments.mpie",
        )
        claims = verifier.verify(token, expected_nonce="nonce-123")
        self.assertEqual(claims.subject, "provider-user-123")
        self.assertEqual(len(calls), 2)


class _AppleNotificationVerifier:
    def __init__(self, events: dict[str, str]) -> None:
        self.events = events

    def verify_notification(self, _: str) -> dict[str, str]:
        import json

        return {"events": json.dumps(self.events)}


class AppleWebhookBehaviorTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.store = StateStore(root / "state.db", root / "missing.json")
        self.settings = Settings(
            auth_enabled=True,
            session_secret="s" * 64,
            apple_client_ids=("com.sierrawarrendevelopments.mpie",),
            google_client_ids=("google-client",),
            sqlite_path=root / "state.db",
            fixture_path=root / "missing.json",
        )
        self.service = AuthService(self.settings, self.store)

    def tearDown(self) -> None:
        self.service.close()
        self.temp_dir.cleanup()

    def _identity_session(self, *, user_id: str, subject: str) -> tuple[str, str]:
        self.store.link_identity_to_user(
            user_id=user_id,
            provider="apple",
            provider_subject=subject,
            provider_email="relay@privaterelay.appleid.com",
            email_verified=True,
        )
        identity = self.store.find_identity("apple", subject)
        assert identity is not None
        session_id = self.store.create_auth_session(
            user_id,
            f"hash-{subject}",
            datetime.now(UTC) + timedelta(hours=1),
            identity_id=str(identity["identity_id"]),
        )
        return str(identity["identity_id"]), session_id

    def _send(self, event_type: str, subject: str) -> dict[str, str]:
        self.service.apple = _AppleNotificationVerifier(
            {"type": event_type, "sub": subject}
        )
        return self.service.process_apple_notification("signed-payload")

    def test_webhook_consent_revoked_detaches_only(self) -> None:
        user = self.store.create_user(email="user@example.com")
        _, session_id = self._identity_session(user_id=user.id, subject="apple-consent")

        result = self._send("consent-revoked", "apple-consent")

        self.assertEqual(result, {"status": "ok", "event": "consent-revoked"})
        self.assertIsNone(self.store.find_identity("apple", "apple-consent"))
        self.assertIsNotNone(self.store.get_user_by_id(user.id))
        self.assertFalse(self.store.is_auth_session_active(session_id, user.id))

    def test_webhook_account_delete_removes_user_if_sole_identity(self) -> None:
        user = self.store.create_user(email="user@example.com")
        self._identity_session(user_id=user.id, subject="apple-only")
        self.store.add_watchlist(user.id, "event-1")
        self.store.create_playbook_entry(
            user.id,
            PlaybookEntryCreate(title="Private", bodyMarkdown="# Delete"),
        )

        result = self._send("account-delete", "apple-only")

        self.assertEqual(result, {"status": "ok", "event": "account-delete"})
        self.assertIsNone(self.store.get_user_by_id(user.id))
        self.assertEqual(self.store.get_watchlist(user.id), [])
        self.assertEqual(self.store.list_playbook_entries(user.id), [])

    def test_webhook_account_delete_keeps_user_if_other_identity_exists(self) -> None:
        user = self.store.create_user(email="user@example.com")
        self._identity_session(user_id=user.id, subject="apple-linked")
        self.store.link_identity_to_user(
            user_id=user.id,
            provider="google",
            provider_subject="google-linked",
            provider_email="user@example.com",
            email_verified=True,
        )

        result = self._send("account-delete", "apple-linked")

        self.assertEqual(result, {"status": "ok", "event": "account-delete"})
        self.assertIsNotNone(self.store.get_user_by_id(user.id))
        self.assertIsNone(self.store.find_identity("apple", "apple-linked"))
        self.assertIsNotNone(self.store.find_identity("google", "google-linked"))

    def test_webhook_repeated_notification_idempotent(self) -> None:
        user = self.store.create_user()
        self._identity_session(user_id=user.id, subject="apple-repeat")

        first = self._send("consent-revoked", "apple-repeat")
        second = self._send("consent-revoked", "apple-repeat")

        self.assertEqual(first["status"], "ok")
        self.assertEqual(second, {"status": "unknown_identity", "event": "consent-revoked"})

    def test_webhook_unknown_subject_returns_200_semantics(self) -> None:
        result = self._send("account-delete", "missing-subject")
        self.assertEqual(result, {"status": "unknown_identity", "event": "account-delete"})




if __name__ == "__main__":
    unittest.main()
