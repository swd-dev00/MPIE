from __future__ import annotations

import os
import tempfile
import uuid
import unittest
from pathlib import Path

os.environ["MPIE_DEMO_MODE"] = "true"
os.environ["MPIE_STATE_DB"] = str(Path(tempfile.gettempdir()) / f"mpie-contract-test-{uuid.uuid4()}.db")

from fastapi.testclient import TestClient

from app.main import app


class ApiContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(app)

    def test_health_and_market_contract(self) -> None:
        health = self.client.get("/health")
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.json()["version"], "1.1.2")
        response = self.client.get("/api/v1/markets")
        self.assertEqual(response.status_code, 200)
        games = response.json()
        self.assertGreaterEqual(len(games), 5)
        game = games[0]
        for key in (
            "id", "league", "status", "startAt", "home", "away", "pick", "market",
            "marketKey", "outcome", "decimalOdds", "bestBookmakerTitle",
            "bookmakerCount", "modelVersion", "calculatedAt", "modelProbability", "edge", "confidence", "factors",
        ):
            self.assertIn(key, game)
        self.assertEqual(self.client.get(f"/api/v1/markets/{game['id']}").status_code, 200)
        prices = self.client.get(
            f"/api/v1/markets/{game['id']}/prices",
            params={"market_key": game["marketKey"], "outcome": game["outcome"]},
        )
        self.assertEqual(prices.status_code, 200)
        price_board = prices.json()
        self.assertGreaterEqual(price_board["quoteCount"], 3)
        self.assertTrue(any(quote["isBestPrice"] for quote in price_board["quotes"]))
        self.assertTrue(any(quote["status"] == "ACTIVE" for quote in price_board["quotes"]))
        predictions = self.client.get(f"/api/v1/predictions/{game['id']}")
        self.assertEqual(predictions.status_code, 200)
        self.assertIn("modelVersion", predictions.json()[0])
        self.assertIn("calculatedAt", predictions.json()[0])
        self.assertEqual(self.client.get(f"/api/v1/pressure/{game['id']}").status_code, 200)

    def test_user_state_contract(self) -> None:
        event_id = "kc-det-0711"
        self.assertEqual(self.client.post(f"/api/v1/watchlist/{event_id}").status_code, 201)
        self.assertIn(event_id, self.client.get("/api/v1/watchlist").json()["eventIds"])
        self.assertEqual(self.client.delete(f"/api/v1/watchlist/{event_id}").status_code, 204)

        payload = {
            "eventId": "bos-ny-0710",
            "marketKey": "h2h",
            "outcome": "Boston ML",
            "label": "Boston ML",
            "game": "BOS @ NYY",
            "entryPrice": 2.08,
            "sizeUnits": 25,
            "bookmakerKey": "draftkings",
            "bookmakerTitle": "DraftKings",
            "status": "Open",
        }
        response = self.client.post("/api/v1/portfolio/positions", json=payload)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["stake"], 25)
        self.assertEqual(response.json()["bookmakerKey"], "draftkings")
        self.assertEqual(response.json()["bookmakerTitle"], "DraftKings")


    def test_playbook_crud_and_user_isolation(self) -> None:
        user_a = str(uuid.uuid4())
        user_b = str(uuid.uuid4())
        headers_a = {"X-MPIE-User-ID": user_a}
        headers_b = {"X-MPIE-User-ID": user_b}
        payload = {
            "title": "Line movement idea",
            "bodyMarkdown": "# Observation\n\n- [ ] Compare sharp-book movement.",
        }

        created = self.client.post("/api/v1/playbook", json=payload, headers=headers_a)
        self.assertEqual(created.status_code, 201)
        entry = created.json()
        self.assertEqual(entry["title"], payload["title"])
        self.assertEqual(entry["bodyMarkdown"], payload["bodyMarkdown"])
        self.assertIn("createdAt", entry)
        self.assertIn("updatedAt", entry)

        entry_id = entry["id"]
        fetched = self.client.get(f"/api/v1/playbook/{entry_id}", headers=headers_a)
        self.assertEqual(fetched.status_code, 200)
        self.assertEqual(fetched.json()["id"], entry_id)

        isolated_list = self.client.get("/api/v1/playbook", headers=headers_b)
        self.assertEqual(isolated_list.status_code, 200)
        self.assertEqual(isolated_list.json(), [])
        self.assertEqual(
            self.client.get(f"/api/v1/playbook/{entry_id}", headers=headers_b).status_code,
            404,
        )

        updated = self.client.patch(
            f"/api/v1/playbook/{entry_id}",
            json={"bodyMarkdown": "# Revised\n\n**Keep** the change log."},
            headers=headers_a,
        )
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.json()["title"], payload["title"])
        self.assertIn("# Revised", updated.json()["bodyMarkdown"])

        entries = self.client.get("/api/v1/playbook", headers=headers_a)
        self.assertEqual(entries.status_code, 200)
        self.assertEqual([item["id"] for item in entries.json()], [entry_id])

        self.assertEqual(
            self.client.delete(f"/api/v1/playbook/{entry_id}", headers=headers_a).status_code,
            204,
        )
        self.assertEqual(
            self.client.get(f"/api/v1/playbook/{entry_id}", headers=headers_a).status_code,
            404,
        )

    def test_playbook_validation_contract(self) -> None:
        user_id = str(uuid.uuid4())
        headers = {"X-MPIE-User-ID": user_id}

        blank_title = self.client.post(
            "/api/v1/playbook",
            json={"title": "   ", "bodyMarkdown": "# Invalid"},
            headers=headers,
        )
        self.assertEqual(blank_title.status_code, 422)

        created = self.client.post(
            "/api/v1/playbook",
            json={"title": "Valid", "bodyMarkdown": "plain text is valid Markdown"},
            headers=headers,
        )
        self.assertEqual(created.status_code, 201)
        entry_id = created.json()["id"]

        empty_patch = self.client.patch(
            f"/api/v1/playbook/{entry_id}",
            json={},
            headers=headers,
        )
        self.assertEqual(empty_patch.status_code, 422)

    def test_error_contracts(self) -> None:
        self.assertEqual(self.client.get("/api/v1/markets/not-a-real-event").status_code, 404)
        response = self.client.get(
            "/api/v1/watchlist",
            headers={"X-MPIE-User-ID": "not-a-uuid"},
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("valid UUID", response.json()["detail"])


if __name__ == "__main__":
    unittest.main()
