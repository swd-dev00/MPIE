from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from uuid import uuid4

from .models import (
    PlaybookEntry,
    PlaybookEntryCreate,
    PlaybookEntryUpdate,
    PortfolioPosition,
    PositionCreate,
    UserRecord,
)


class StateStore:
    """Transactional per-user state for the mobile app.

    SQLite keeps local and single-node deployments self-contained. Set
    MPIE_STATE_DB to a durable volume in deployment, or replace this adapter with
    PostgreSQL without changing the HTTP contract.
    """

    def __init__(self, path: Path, fixture_path: Path) -> None:
        self.path = path
        self.fixture_path = fixture_path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._lock, self._connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS watchlist (
                    user_id TEXT NOT NULL,
                    event_id TEXT NOT NULL,
                    added_at TEXT NOT NULL,
                    PRIMARY KEY (user_id, event_id)
                );

                CREATE TABLE IF NOT EXISTS portfolio_positions (
                    position_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    event_id TEXT NOT NULL,
                    market_key TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    label TEXT NOT NULL,
                    game_label TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    bookmaker_key TEXT,
                    bookmaker_title TEXT,
                    size_units REAL NOT NULL,
                    status TEXT NOT NULL,
                    pnl REAL NOT NULL DEFAULT 0,
                    opened_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS playbook_entries (
                    entry_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    body_markdown TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_playbook_user_updated
                    ON playbook_entries(user_id, updated_at DESC);

                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    email TEXT,
                    display_name TEXT,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_login_at TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_users_email_normalized
                    ON users(lower(email))
                    WHERE email IS NOT NULL;

                CREATE TABLE IF NOT EXISTS auth_identities (
                    identity_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    provider_subject TEXT NOT NULL,
                    provider_email TEXT,
                    email_verified INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_login_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                    UNIQUE(provider, provider_subject)
                );

                CREATE INDEX IF NOT EXISTS idx_auth_identities_user
                    ON auth_identities(user_id);

                CREATE TABLE IF NOT EXISTS auth_sessions (
                    session_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    identity_id TEXT,
                    refresh_token_hash TEXT NOT NULL UNIQUE,
                    expires_at TEXT NOT NULL,
                    revoked_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                    FOREIGN KEY(identity_id) REFERENCES auth_identities(identity_id) ON DELETE SET NULL
                );

                CREATE INDEX IF NOT EXISTS idx_auth_sessions_user
                    ON auth_sessions(user_id, expires_at DESC);

                CREATE INDEX IF NOT EXISTS idx_auth_sessions_identity
                    ON auth_sessions(identity_id, expires_at DESC);

                CREATE TABLE IF NOT EXISTS stake_suggestion_audit (
                    audit_id TEXT PRIMARY KEY,
                    user_id TEXT,
                    anonymized_user_id TEXT,
                    event_id TEXT NOT NULL,
                    market_key TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    recommended_size_pct REAL,
                    model_version TEXT,
                    calculated_at TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_stake_audit_user
                    ON stake_suggestion_audit(user_id, created_at DESC);
                """
            )

            session_columns = {
                str(row["name"])
                for row in connection.execute("PRAGMA table_info(auth_sessions)").fetchall()
            }
            if "identity_id" not in session_columns:
                connection.execute("ALTER TABLE auth_sessions ADD COLUMN identity_id TEXT")
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_auth_sessions_identity ON auth_sessions(identity_id, expires_at DESC)"
            )

            portfolio_columns = {
                str(row["name"])
                for row in connection.execute(
                    "PRAGMA table_info(portfolio_positions)"
                ).fetchall()
            }
            if "bookmaker_key" not in portfolio_columns:
                connection.execute(
                    "ALTER TABLE portfolio_positions ADD COLUMN bookmaker_key TEXT"
                )
            if "bookmaker_title" not in portfolio_columns:
                connection.execute(
                    "ALTER TABLE portfolio_positions ADD COLUMN bookmaker_title TEXT"
                )

            legacy_notes = connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'notes'"
            ).fetchone()
            if legacy_notes:
                connection.execute(
                    """
                    INSERT OR IGNORE INTO playbook_entries(
                        entry_id, user_id, title, body_markdown, created_at, updated_at
                    )
                    SELECT note_id, user_id, title, body_markdown, created_at, updated_at
                    FROM notes
                    """
                )

    def seed_demo_state(self, user_id: str) -> None:
        if not self.fixture_path.exists():
            return
        payload = json.loads(self.fixture_path.read_text(encoding="utf-8"))
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            watchlist_count = connection.execute(
                "SELECT COUNT(*) FROM watchlist WHERE user_id = ?", (user_id,)
            ).fetchone()[0]
            if watchlist_count == 0:
                connection.executemany(
                    "INSERT OR IGNORE INTO watchlist(user_id, event_id, added_at) VALUES (?, ?, ?)",
                    [(user_id, event_id, now) for event_id in payload.get("watchlist", [])],
                )

            position_count = connection.execute(
                "SELECT COUNT(*) FROM portfolio_positions WHERE user_id = ?", (user_id,)
            ).fetchone()[0]
            if position_count == 0:
                event_by_label = {
                    "Boston ML": ("bos-ny-0710", "h2h", "Boston"),
                    "Las Vegas -2.5": ("lv-sea-0710", "spreads", "Las Vegas"),
                    "Under 8.0": ("atl-phi-demo", "totals", "Under 8.0"),
                }
                rows = []
                for item in payload.get("portfolio", []):
                    event_id, market_key, outcome = event_by_label.get(
                        item["label"], (f"demo-{item['id']}", "unknown", item["label"])
                    )
                    rows.append(
                        (
                            item["id"], user_id, event_id, market_key, outcome,
                            item["label"], item["game"], float(item["odds"]),
                            item.get("bookmakerKey"), item.get("bookmakerTitle"),
                            float(item["stake"]), item["status"],
                            float(item.get("pnl", 0)), now,
                        )
                    )
                connection.executemany(
                    """
                    INSERT OR IGNORE INTO portfolio_positions(
                        position_id, user_id, event_id, market_key, outcome,
                        label, game_label, entry_price, bookmaker_key, bookmaker_title,
                        size_units, status, pnl, opened_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    rows,
                )


    @staticmethod
    def _user_from_row(row: sqlite3.Row) -> UserRecord:
        return UserRecord(
            id=row["user_id"],
            email=row["email"],
            displayName=row["display_name"],
            status=row["status"],
            createdAt=row["created_at"],
            updatedAt=row["updated_at"],
            lastLoginAt=row["last_login_at"],
        )

    def create_user(
        self,
        *,
        email: str | None = None,
        display_name: str | None = None,
        user_id: str | None = None,
    ) -> UserRecord:
        now = datetime.now(UTC).isoformat()
        resolved_id = user_id or str(uuid4())
        normalized_email = email.strip().lower() if email else None
        normalized_name = display_name.strip() if display_name else None
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO users(
                    user_id, email, display_name, status, created_at, updated_at, last_login_at
                ) VALUES (?, ?, ?, 'active', ?, ?, ?)
                """,
                (resolved_id, normalized_email, normalized_name, now, now, now),
            )
            row = connection.execute(
                """
                SELECT user_id, email, display_name, status, created_at, updated_at, last_login_at
                FROM users WHERE user_id = ?
                """,
                (resolved_id,),
            ).fetchone()
        if row is None:
            raise RuntimeError("Created user could not be reloaded.")
        return self._user_from_row(row)

    def get_user_by_id(self, user_id: str) -> UserRecord | None:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT user_id, email, display_name, status, created_at, updated_at, last_login_at
                FROM users WHERE user_id = ?
                """,
                (user_id,),
            ).fetchone()
        return self._user_from_row(row) if row else None

    def update_user_profile(
        self,
        user_id: str,
        *,
        email: str | None = None,
        display_name: str | None = None,
    ) -> UserRecord | None:
        updated_at = datetime.now(UTC).isoformat()
        normalized_email = email.strip().lower() if email else None
        normalized_name = display_name.strip() if display_name else None
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                """
                UPDATE users
                SET email = COALESCE(?, email),
                    display_name = COALESCE(?, display_name),
                    updated_at = ?
                WHERE user_id = ?
                """,
                (normalized_email, normalized_name, updated_at, user_id),
            )
            if cursor.rowcount == 0:
                return None
            row = connection.execute(
                """
                SELECT user_id, email, display_name, status, created_at, updated_at, last_login_at
                FROM users WHERE user_id = ?
                """,
                (user_id,),
            ).fetchone()
        return self._user_from_row(row) if row else None

    def touch_user_login(self, user_id: str) -> UserRecord | None:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                "UPDATE users SET last_login_at = ?, updated_at = ? WHERE user_id = ?",
                (now, now, user_id),
            )
            if cursor.rowcount == 0:
                return None
            row = connection.execute(
                """
                SELECT user_id, email, display_name, status, created_at, updated_at, last_login_at
                FROM users WHERE user_id = ?
                """,
                (user_id,),
            ).fetchone()
        return self._user_from_row(row) if row else None

    def disable_user(self, user_id: str) -> bool:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                "UPDATE users SET status = 'disabled', updated_at = ? WHERE user_id = ?",
                (now, user_id),
            )
            connection.execute(
                "UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE user_id = ? AND revoked_at IS NULL",
                (now, now, user_id),
            )
        return cursor.rowcount > 0

    def find_user_by_provider(self, provider: str, provider_subject: str) -> UserRecord | None:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT u.user_id, u.email, u.display_name, u.status,
                       u.created_at, u.updated_at, u.last_login_at
                FROM auth_identities AS i
                JOIN users AS u ON u.user_id = i.user_id
                WHERE i.provider = ? AND i.provider_subject = ?
                """,
                (provider, provider_subject),
            ).fetchone()
        return self._user_from_row(row) if row else None

    def find_identity(self, provider: str, provider_subject: str) -> dict[str, object] | None:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT identity_id, user_id, provider, provider_subject, provider_email,
                       email_verified, created_at, updated_at, last_login_at
                FROM auth_identities
                WHERE provider = ? AND provider_subject = ?
                """,
                (provider, provider_subject),
            ).fetchone()
        if row is None:
            return None
        identity = dict(row)
        identity["id"] = identity["identity_id"]
        return identity

    def create_auth_identity(
        self,
        *,
        user_id: str,
        provider: str,
        provider_subject: str,
        provider_email: str | None = None,
        email_verified: bool = False,
    ) -> None:
        self.link_identity_to_user(
            user_id=user_id,
            provider=provider,
            provider_subject=provider_subject,
            provider_email=provider_email,
            email_verified=email_verified,
        )

    def update_identity_claims(
        self,
        identity_id: str | None = None,
        *,
        provider: str | None = None,
        provider_subject: str | None = None,
        provider_email: str | None,
        email_verified: bool,
    ) -> bool:
        now = datetime.now(UTC).isoformat()
        normalized_email = provider_email.strip().lower() if provider_email else None
        with self._lock, self._connection() as connection:
            if identity_id is not None:
                cursor = connection.execute(
                    """
                    UPDATE auth_identities
                    SET provider_email = ?, email_verified = ?, updated_at = ?, last_login_at = ?
                    WHERE identity_id = ?
                    """,
                    (normalized_email, 1 if email_verified else 0, now, now, identity_id),
                )
            else:
                if not provider or not provider_subject:
                    raise ValueError("provider and provider_subject are required when identity_id is omitted.")
                cursor = connection.execute(
                    """
                    UPDATE auth_identities
                    SET provider_email = ?, email_verified = ?, updated_at = ?, last_login_at = ?
                    WHERE provider = ? AND provider_subject = ?
                    """,
                    (
                        normalized_email,
                        1 if email_verified else 0,
                        now,
                        now,
                        provider,
                        provider_subject,
                    ),
                )
        return cursor.rowcount > 0

    def delete_auth_identity(
        self,
        identity_id: str | None = None,
        *,
        user_id: str | None = None,
        provider: str | None = None,
        provider_subject: str | None = None,
    ) -> bool:
        with self._lock, self._connection() as connection:
            if identity_id is not None:
                cursor = connection.execute(
                    "DELETE FROM auth_identities WHERE identity_id = ?",
                    (identity_id,),
                )
            else:
                if not user_id or not provider or not provider_subject:
                    raise ValueError(
                        "user_id, provider, and provider_subject are required when identity_id is omitted."
                    )
                cursor = connection.execute(
                    """
                    DELETE FROM auth_identities
                    WHERE user_id = ? AND provider = ? AND provider_subject = ?
                    """,
                    (user_id, provider, provider_subject),
                )
        return cursor.rowcount > 0

    def user_has_other_identities(self, user_id: str) -> bool:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM auth_identities WHERE user_id = ? LIMIT 1",
                (user_id,),
            ).fetchone()
        return row is not None

    def revoke_all_sessions_for_identity(self, identity_id: str) -> int:
        """Revoke sessions issued through one identity.

        Sessions created before the identity_id migration cannot be attributed to
        a provider. For those legacy rows, revoke every unscoped session belonging
        to the identity's user as the safer fallback.
        """
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            identity = connection.execute(
                "SELECT user_id FROM auth_identities WHERE identity_id = ?",
                (identity_id,),
            ).fetchone()
            if identity is None:
                return 0
            cursor = connection.execute(
                """
                UPDATE auth_sessions
                SET revoked_at = ?, updated_at = ?
                WHERE revoked_at IS NULL
                  AND (
                    identity_id = ?
                    OR (identity_id IS NULL AND user_id = ?)
                  )
                """,
                (now, now, identity_id, identity["user_id"]),
            )
        return cursor.rowcount

    def revoke_all_sessions_for_user(self, user_id: str) -> int:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                """
                UPDATE auth_sessions
                SET revoked_at = ?, updated_at = ?
                WHERE user_id = ? AND revoked_at IS NULL
                """,
                (now, now, user_id),
            )
        return cursor.rowcount

    def anonymize_stake_audit(self, user_id: str) -> int:
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                """
                UPDATE stake_suggestion_audit
                SET user_id = NULL,
                    anonymized_user_id = COALESCE(anonymized_user_id, lower(hex(randomblob(16))))
                WHERE user_id = ?
                """,
                (user_id,),
            )
        return cursor.rowcount

    def delete_user_and_cascade(self, user_id: str) -> bool:
        with self._lock, self._connection() as connection:
            existing = connection.execute(
                "SELECT 1 FROM users WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            if existing is None:
                return False

            connection.execute("DELETE FROM watchlist WHERE user_id = ?", (user_id,))
            connection.execute("DELETE FROM portfolio_positions WHERE user_id = ?", (user_id,))
            connection.execute("DELETE FROM playbook_entries WHERE user_id = ?", (user_id,))
            connection.execute("DELETE FROM auth_sessions WHERE user_id = ?", (user_id,))
            connection.execute("DELETE FROM auth_identities WHERE user_id = ?", (user_id,))
            connection.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
        return True

    def link_identity_to_user(
        self,
        *,
        user_id: str,
        provider: str,
        provider_subject: str,
        provider_email: str | None,
        email_verified: bool,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            existing = connection.execute(
                """
                SELECT user_id FROM auth_identities
                WHERE provider = ? AND provider_subject = ?
                """,
                (provider, provider_subject),
            ).fetchone()
            if existing and existing["user_id"] != user_id:
                raise ValueError("OAuth identity is already linked to another MPIE user.")
            connection.execute(
                """
                INSERT INTO auth_identities(
                    identity_id, user_id, provider, provider_subject, provider_email,
                    email_verified, created_at, updated_at, last_login_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(provider, provider_subject) DO UPDATE SET
                    provider_email = COALESCE(excluded.provider_email, auth_identities.provider_email),
                    email_verified = MAX(auth_identities.email_verified, excluded.email_verified),
                    updated_at = excluded.updated_at,
                    last_login_at = excluded.last_login_at
                """,
                (
                    str(uuid4()), user_id, provider, provider_subject,
                    provider_email.strip().lower() if provider_email else None,
                    1 if email_verified else 0, now, now, now,
                ),
            )

    def get_or_create_oauth_user(
        self,
        *,
        provider: str,
        provider_subject: str,
        email: str | None,
        email_verified: bool,
        display_name: str | None,
    ) -> UserRecord:
        # Keep the lookup/create/link sequence atomic inside this process. The
        # UNIQUE(provider, provider_subject) constraint remains the final guard.
        with self._lock:
            existing = self.find_user_by_provider(provider, provider_subject)
            if existing is not None:
                if existing.status != "active":
                    return existing
                self.link_identity_to_user(
                    user_id=existing.id,
                    provider=provider,
                    provider_subject=provider_subject,
                    provider_email=email,
                    email_verified=email_verified,
                )
                updated = self.update_user_profile(
                    existing.id,
                    email=email if email_verified else None,
                    display_name=display_name,
                )
                return self.touch_user_login(existing.id) or updated or existing

            # Email is deliberately not used for automatic account linking. Provider
            # subject is the durable identity; explicit linking must be user-authorized.
            user = self.create_user(
                email=email if email_verified else None,
                display_name=display_name,
            )
            self.link_identity_to_user(
                user_id=user.id,
                provider=provider,
                provider_subject=provider_subject,
                provider_email=email,
                email_verified=email_verified,
            )
            return user

    def create_auth_session(
        self,
        user_id: str,
        refresh_token_hash: str,
        expires_at: datetime,
        identity_id: str | None = None,
    ) -> str:
        session_id = str(uuid4())
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO auth_sessions(
                    session_id, user_id, identity_id, refresh_token_hash,
                    expires_at, revoked_at, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?)
                """,
                (
                    session_id,
                    user_id,
                    identity_id,
                    refresh_token_hash,
                    expires_at.isoformat(),
                    now,
                    now,
                ),
            )
        return session_id

    def rotate_auth_session(
        self,
        old_refresh_token_hash: str,
        new_refresh_token_hash: str,
        expires_at: datetime,
    ) -> tuple[UserRecord, str] | None:
        now = datetime.now(UTC)
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT session_id, user_id, expires_at, revoked_at
                FROM auth_sessions WHERE refresh_token_hash = ?
                """,
                (old_refresh_token_hash,),
            ).fetchone()
            if row is None or row["revoked_at"] is not None:
                return None
            if datetime.fromisoformat(row["expires_at"]) <= now:
                return None
            connection.execute(
                """
                UPDATE auth_sessions
                SET refresh_token_hash = ?, expires_at = ?, updated_at = ?
                WHERE session_id = ?
                """,
                (new_refresh_token_hash, expires_at.isoformat(), now.isoformat(), row["session_id"]),
            )
            user_row = connection.execute(
                """
                SELECT user_id, email, display_name, status, created_at, updated_at, last_login_at
                FROM users WHERE user_id = ?
                """,
                (row["user_id"],),
            ).fetchone()
        if user_row is None:
            return None
        return self._user_from_row(user_row), str(row["session_id"])

    def revoke_auth_session(self, refresh_token_hash: str) -> bool:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                """
                UPDATE auth_sessions SET revoked_at = ?, updated_at = ?
                WHERE refresh_token_hash = ? AND revoked_at IS NULL
                """,
                (now, now, refresh_token_hash),
            )
        return cursor.rowcount > 0

    def is_auth_session_active(self, session_id: str, user_id: str) -> bool:
        now = datetime.now(UTC)
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT expires_at, revoked_at FROM auth_sessions
                WHERE session_id = ? AND user_id = ?
                """,
                (session_id, user_id),
            ).fetchone()
        return bool(
            row
            and row["revoked_at"] is None
            and datetime.fromisoformat(row["expires_at"]) > now
        )

    def get_watchlist(self, user_id: str) -> list[str]:
        with self._lock, self._connection() as connection:
            rows = connection.execute(
                "SELECT event_id FROM watchlist WHERE user_id = ? ORDER BY added_at DESC",
                (user_id,),
            ).fetchall()
        return [str(row["event_id"]) for row in rows]

    def add_watchlist(self, user_id: str, event_id: str) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO watchlist(user_id, event_id, added_at)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id, event_id) DO UPDATE SET added_at = excluded.added_at
                """,
                (user_id, event_id, datetime.now(UTC).isoformat()),
            )

    def remove_watchlist(self, user_id: str, event_id: str) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                "DELETE FROM watchlist WHERE user_id = ? AND event_id = ?",
                (user_id, event_id),
            )

    def list_positions(self, user_id: str) -> list[PortfolioPosition]:
        with self._lock, self._connection() as connection:
            rows = connection.execute(
                """
                SELECT position_id, event_id, market_key, outcome, label, game_label,
                       entry_price, bookmaker_key, bookmaker_title,
                       size_units, status, pnl, opened_at
                FROM portfolio_positions
                WHERE user_id = ?
                ORDER BY opened_at DESC
                """,
                (user_id,),
            ).fetchall()
        return [
            PortfolioPosition(
                id=row["position_id"], eventId=row["event_id"], marketKey=row["market_key"],
                outcome=row["outcome"], label=row["label"], game=row["game_label"],
                stake=row["size_units"], odds=row["entry_price"],
                bookmakerKey=row["bookmaker_key"], bookmakerTitle=row["bookmaker_title"],
                status=row["status"],
                pnl=row["pnl"], openedAt=row["opened_at"],
            )
            for row in rows
        ]

    def create_position(self, user_id: str, position: PositionCreate) -> PortfolioPosition:
        position_id = str(uuid4())
        opened_at = datetime.now(UTC)
        label = position.label or position.outcome
        game_label = position.game or position.eventId
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO portfolio_positions(
                    position_id, user_id, event_id, market_key, outcome, label,
                    game_label, entry_price, bookmaker_key, bookmaker_title,
                    size_units, status, pnl, opened_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                """,
                (
                    position_id, user_id, position.eventId, position.marketKey,
                    position.outcome, label, game_label, position.entryPrice,
                    position.bookmakerKey, position.bookmakerTitle,
                    position.sizeUnits, position.status, opened_at.isoformat(),
                ),
            )
        return PortfolioPosition(
            id=position_id, eventId=position.eventId, marketKey=position.marketKey,
            outcome=position.outcome, label=label, game=game_label,
            stake=position.sizeUnits, odds=position.entryPrice,
            bookmakerKey=position.bookmakerKey, bookmakerTitle=position.bookmakerTitle,
            status=position.status,
            pnl=0, openedAt=opened_at,
        )

    @staticmethod
    def _playbook_entry_from_row(row: sqlite3.Row) -> PlaybookEntry:
        return PlaybookEntry(
            id=row["entry_id"],
            title=row["title"],
            bodyMarkdown=row["body_markdown"],
            createdAt=row["created_at"],
            updatedAt=row["updated_at"],
        )

    def list_playbook_entries(self, user_id: str) -> list[PlaybookEntry]:
        with self._lock, self._connection() as connection:
            rows = connection.execute(
                """
                SELECT entry_id, title, body_markdown, created_at, updated_at
                FROM playbook_entries
                WHERE user_id = ?
                ORDER BY updated_at DESC, created_at DESC
                LIMIT 500
                """,
                (user_id,),
            ).fetchall()
        return [self._playbook_entry_from_row(row) for row in rows]

    def get_playbook_entry(self, user_id: str, entry_id: str) -> PlaybookEntry | None:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                """
                SELECT entry_id, title, body_markdown, created_at, updated_at
                FROM playbook_entries
                WHERE user_id = ? AND entry_id = ?
                """,
                (user_id, entry_id),
            ).fetchone()
        return self._playbook_entry_from_row(row) if row else None

    def create_playbook_entry(
        self,
        user_id: str,
        entry: PlaybookEntryCreate,
    ) -> PlaybookEntry:
        entry_id = str(uuid4())
        now = datetime.now(UTC)
        timestamp = now.isoformat()
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO playbook_entries(
                    entry_id, user_id, title, body_markdown, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (entry_id, user_id, entry.title, entry.bodyMarkdown, timestamp, timestamp),
            )
        return PlaybookEntry(
            id=entry_id,
            title=entry.title,
            bodyMarkdown=entry.bodyMarkdown,
            createdAt=now,
            updatedAt=now,
        )

    def update_playbook_entry(
        self,
        user_id: str,
        entry_id: str,
        update: PlaybookEntryUpdate,
    ) -> PlaybookEntry | None:
        updated_at = datetime.now(UTC).isoformat()
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                """
                UPDATE playbook_entries
                SET
                    title = COALESCE(?, title),
                    body_markdown = COALESCE(?, body_markdown),
                    updated_at = ?
                WHERE user_id = ? AND entry_id = ?
                """,
                (update.title, update.bodyMarkdown, updated_at, user_id, entry_id),
            )
            if cursor.rowcount == 0:
                return None
            row = connection.execute(
                """
                SELECT entry_id, title, body_markdown, created_at, updated_at
                FROM playbook_entries
                WHERE user_id = ? AND entry_id = ?
                """,
                (user_id, entry_id),
            ).fetchone()
        return self._playbook_entry_from_row(row) if row else None

    def delete_playbook_entry(self, user_id: str, entry_id: str) -> bool:
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                "DELETE FROM playbook_entries WHERE user_id = ? AND entry_id = ?",
                (user_id, entry_id),
            )
        return cursor.rowcount > 0

