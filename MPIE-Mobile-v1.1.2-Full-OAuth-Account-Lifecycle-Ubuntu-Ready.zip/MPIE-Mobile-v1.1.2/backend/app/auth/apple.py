from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

import jwt

from .claims import OAuthVerificationError, ProviderClaims
from .jwks import JwkSetCache


APPLE_ISSUER = "https://appleid.apple.com"
APPLE_NOTIFICATION_ISSUER = APPLE_ISSUER


class AppleTokenVerifier:
    def __init__(self, client_ids: Sequence[str], jwks: JwkSetCache) -> None:
        self.client_ids = tuple(item for item in client_ids if item)
        self.jwks = jwks

    def verify(
        self,
        id_token: str,
        *,
        expected_nonce: str | None = None,
        display_name: str | None = None,
    ) -> ProviderClaims:
        if not self.client_ids:
            raise OAuthVerificationError("Apple OAuth client IDs are not configured.")
        try:
            header = jwt.get_unverified_header(id_token)
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Apple identity token header is invalid.") from exc
        if header.get("alg") != "RS256":
            raise OAuthVerificationError("Apple identity token must use RS256.")

        jwk = self.jwks.get(str(header.get("kid", "")))
        key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(dict(jwk)))
        try:
            claims: dict[str, Any] = jwt.decode(
                id_token,
                key=key,
                algorithms=["RS256"],
                audience=list(self.client_ids),
                issuer=APPLE_ISSUER,
                options={"require": ["exp", "iat", "iss", "aud", "sub"]},
            )
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Apple identity token verification failed.") from exc

        if expected_nonce is not None and claims.get("nonce") != expected_nonce:
            raise OAuthVerificationError("Apple identity token nonce does not match.")

        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject:
            raise OAuthVerificationError("Apple identity token is missing a subject.")

        email = claims.get("email") if isinstance(claims.get("email"), str) else None
        raw_verified = claims.get("email_verified")
        email_verified = raw_verified is True or raw_verified == "true"
        return ProviderClaims(
            provider="apple",
            subject=subject,
            email=email,
            email_verified=email_verified,
            display_name=display_name,
        )

    def verify_notification(self, payload: str) -> dict[str, Any]:
        """Verify an Apple server-to-server notification JWT.

        Notification tokens use the same Apple JWK set as identity tokens but
        carry an ``events`` claim instead of a login nonce.
        """
        if not self.client_ids:
            raise OAuthVerificationError("Apple OAuth client IDs are not configured.")
        try:
            header = jwt.get_unverified_header(payload)
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Apple notification header is invalid.") from exc
        if header.get("alg") != "RS256":
            raise OAuthVerificationError("Apple notification must use RS256.")

        jwk = self.jwks.get(str(header.get("kid", "")))
        key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(dict(jwk)))
        try:
            claims: dict[str, Any] = jwt.decode(
                payload,
                key=key,
                algorithms=["RS256"],
                audience=list(self.client_ids),
                issuer=APPLE_NOTIFICATION_ISSUER,
                options={"require": ["iat", "iss", "aud", "events"]},
            )
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Apple notification verification failed.") from exc

        events = claims.get("events")
        if not isinstance(events, (str, dict)):
            raise OAuthVerificationError("Apple notification is missing an events payload.")
        return claims
