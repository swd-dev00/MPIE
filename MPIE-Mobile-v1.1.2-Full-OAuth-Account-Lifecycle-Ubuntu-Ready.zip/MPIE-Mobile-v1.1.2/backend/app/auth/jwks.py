from __future__ import annotations

import re
import time
from collections.abc import Mapping
from threading import RLock
from typing import Any

import httpx

from .claims import OAuthVerificationError


_MAX_AGE_PATTERN = re.compile(r"(?:^|,)\s*max-age=(\d+)", re.IGNORECASE)


class JwkSetCache:
    """Small thread-safe JWK cache that honors Cache-Control max-age.

    A missing ``kid`` forces one refresh so provider key rotation is handled
    without turning every verification into a network request.
    """

    def __init__(
        self,
        url: str,
        *,
        client: httpx.Client | None = None,
        default_ttl_seconds: int = 3600,
        minimum_ttl_seconds: int = 60,
        maximum_ttl_seconds: int = 86_400,
    ) -> None:
        self.url = url
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=httpx.Timeout(10.0))
        self.default_ttl_seconds = default_ttl_seconds
        self.minimum_ttl_seconds = minimum_ttl_seconds
        self.maximum_ttl_seconds = maximum_ttl_seconds
        self._keys: dict[str, Mapping[str, Any]] = {}
        self._expires_at = 0.0
        self._lock = RLock()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def _ttl_from_headers(self, headers: httpx.Headers) -> int:
        cache_control = headers.get("cache-control", "")
        match = _MAX_AGE_PATTERN.search(cache_control)
        ttl = int(match.group(1)) if match else self.default_ttl_seconds
        return max(self.minimum_ttl_seconds, min(ttl, self.maximum_ttl_seconds))

    def _refresh(self) -> None:
        try:
            response = self._client.get(self.url)
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise OAuthVerificationError("Unable to retrieve provider signing keys.") from exc

        raw_keys = payload.get("keys") if isinstance(payload, dict) else None
        if not isinstance(raw_keys, list):
            raise OAuthVerificationError("Provider JWK response did not contain a keys array.")

        keys: dict[str, Mapping[str, Any]] = {}
        for item in raw_keys:
            if not isinstance(item, dict):
                continue
            kid = item.get("kid")
            if isinstance(kid, str) and kid:
                keys[kid] = item

        if not keys:
            raise OAuthVerificationError("Provider JWK response contained no usable keys.")

        self._keys = keys
        self._expires_at = time.monotonic() + self._ttl_from_headers(response.headers)

    def get(self, kid: str) -> Mapping[str, Any]:
        if not kid:
            raise OAuthVerificationError("Identity token is missing a key identifier.")

        with self._lock:
            if time.monotonic() >= self._expires_at or not self._keys:
                self._refresh()

            key = self._keys.get(kid)
            if key is not None:
                return key

            # One forced refresh supports normal provider key rotation.
            self._refresh()
            key = self._keys.get(kid)
            if key is None:
                raise OAuthVerificationError("Identity token references an unknown signing key.")
            return key
