from __future__ import annotations

import json
from dataclasses import dataclass

from ..config import Settings
from ..models import AuthSessionResponse, UserRecord
from ..state import StateStore
from .apple import AppleTokenVerifier
from .claims import OAuthVerificationError, ProviderClaims
from .google import GoogleTokenVerifier
from .jwks import JwkSetCache
from .sessions import SessionManager, SessionTokenError


class AuthConfigurationError(RuntimeError):
    pass


@dataclass(frozen=True)
class AuthenticatedSession:
    user_id: str
    session_id: str


class AuthService:
    def __init__(self, settings: Settings, state_store: StateStore) -> None:
        self.settings = settings
        self.state_store = state_store
        self.google_jwks = JwkSetCache(settings.google_jwks_url)
        self.apple_jwks = JwkSetCache(settings.apple_jwks_url)
        self.google = GoogleTokenVerifier(settings.google_client_ids, self.google_jwks)
        self.apple = AppleTokenVerifier(settings.apple_client_ids, self.apple_jwks)
        self.sessions = SessionManager(
            secret=settings.session_secret,
            access_ttl_seconds=settings.session_ttl_seconds,
            refresh_ttl_seconds=settings.refresh_ttl_seconds,
            issuer=settings.session_issuer,
            audience=settings.session_audience,
        )

    def close(self) -> None:
        self.google_jwks.close()
        self.apple_jwks.close()

    def ensure_enabled(self) -> None:
        if not self.settings.auth_enabled:
            raise AuthConfigurationError("OAuth authentication is disabled.")
        try:
            self.sessions.ensure_configured()
        except SessionTokenError as exc:
            raise AuthConfigurationError(str(exc)) from exc

    def _session_response(self, user: UserRecord, session_id: str, refresh_token: str) -> AuthSessionResponse:
        return AuthSessionResponse(
            accessToken=self.sessions.create_access_token(user, session_id),
            refreshToken=refresh_token,
            expiresIn=self.settings.session_ttl_seconds,
            user=user,
        )

    def _issue_session(self, claims: ProviderClaims) -> AuthSessionResponse:
        user = self.state_store.get_or_create_oauth_user(
            provider=claims.provider,
            provider_subject=claims.subject,
            email=claims.email,
            email_verified=claims.email_verified,
            display_name=claims.display_name,
        )
        if user.status != "active":
            raise OAuthVerificationError("MPIE account is disabled.")
        identity = self.state_store.find_identity(claims.provider, claims.subject)
        if identity is None:
            raise OAuthVerificationError("OAuth identity was not persisted.")
        refresh_token = self.sessions.new_refresh_token()
        session_id = self.state_store.create_auth_session(
            user.id,
            self.sessions.hash_refresh_token(refresh_token),
            self.sessions.refresh_expiry(),
            identity_id=str(identity["identity_id"]),
        )
        return self._session_response(user, session_id, refresh_token)

    def login_google(self, id_token: str, nonce: str | None) -> AuthSessionResponse:
        self.ensure_enabled()
        if not self.settings.google_client_ids:
            raise AuthConfigurationError("Google OAuth client IDs are not configured.")
        claims = self.google.verify(id_token, expected_nonce=nonce)
        return self._issue_session(claims)

    def login_apple(
        self,
        id_token: str,
        nonce: str | None,
        display_name: str | None,
    ) -> AuthSessionResponse:
        self.ensure_enabled()
        if not self.settings.apple_client_ids:
            raise AuthConfigurationError("Apple OAuth client IDs are not configured.")
        claims = self.apple.verify(
            id_token,
            expected_nonce=nonce,
            display_name=display_name,
        )
        return self._issue_session(claims)

    def refresh(self, refresh_token: str) -> AuthSessionResponse:
        self.ensure_enabled()
        old_hash = self.sessions.hash_refresh_token(refresh_token)
        new_refresh_token = self.sessions.new_refresh_token()
        rotated = self.state_store.rotate_auth_session(
            old_hash,
            self.sessions.hash_refresh_token(new_refresh_token),
            self.sessions.refresh_expiry(),
        )
        if rotated is None:
            raise SessionTokenError("Refresh token is invalid, expired, or revoked.")
        user, session_id = rotated
        if user.status != "active":
            self.state_store.revoke_auth_session(
                self.sessions.hash_refresh_token(new_refresh_token)
            )
            raise SessionTokenError("MPIE account is disabled.")
        return self._session_response(user, session_id, new_refresh_token)

    def logout(self, refresh_token: str) -> None:
        self.ensure_enabled()
        self.state_store.revoke_auth_session(self.sessions.hash_refresh_token(refresh_token))

    def authenticate_access_token(self, token: str) -> AuthenticatedSession:
        self.ensure_enabled()
        user_id, session_id = self.sessions.verify_access_token(token)
        if not self.state_store.is_auth_session_active(session_id, user_id):
            raise SessionTokenError("MPIE session is revoked or expired.")
        user = self.state_store.get_user_by_id(user_id)
        if user is None or user.status != "active":
            raise SessionTokenError("MPIE user is unavailable.")
        return AuthenticatedSession(user_id=user_id, session_id=session_id)

    def delete_account(self, user_id: str) -> bool:
        self.ensure_enabled()
        if self.state_store.get_user_by_id(user_id) is None:
            return False
        self.state_store.revoke_all_sessions_for_user(user_id)
        self.state_store.anonymize_stake_audit(user_id)
        return self.state_store.delete_user_and_cascade(user_id)

    def process_apple_notification(self, payload: str) -> dict[str, str]:
        if not self.settings.apple_client_ids:
            raise AuthConfigurationError("Apple OAuth client IDs are not configured.")

        claims = self.apple.verify_notification(payload)
        raw_events = claims.get("events", {})
        try:
            events = json.loads(raw_events) if isinstance(raw_events, str) else raw_events
        except json.JSONDecodeError as exc:
            raise OAuthVerificationError("Apple notification events payload is invalid JSON.") from exc
        if not isinstance(events, dict):
            raise OAuthVerificationError("Apple notification events payload is invalid.")

        event_type = events.get("type")
        subject = events.get("sub")
        if not isinstance(event_type, str) or not isinstance(subject, str) or not subject:
            return {"status": "invalid_payload"}

        identity = self.state_store.find_identity("apple", subject)
        if identity is None:
            return {"status": "unknown_identity", "event": event_type}

        identity_id = str(identity["identity_id"])
        user_id = str(identity["user_id"])
        if event_type in {"consent-revoked", "account-delete"}:
            self.state_store.revoke_all_sessions_for_identity(identity_id)

        if event_type == "consent-revoked":
            self.state_store.delete_auth_identity(identity_id)
        elif event_type == "account-delete":
            self.state_store.delete_auth_identity(identity_id)
            if not self.state_store.user_has_other_identities(user_id):
                self.state_store.anonymize_stake_audit(user_id)
                self.state_store.delete_user_and_cascade(user_id)
        elif event_type == "email-disabled":
            self.state_store.update_identity_claims(
                identity_id,
                provider_email=None,
                email_verified=bool(identity.get("email_verified", False)),
            )
        elif event_type == "email-enabled":
            pass

        return {"status": "ok", "event": event_type}

    def get_user(self, user_id: str) -> UserRecord | None:
        return self.state_store.get_user_by_id(user_id)


__all__ = [
    "AuthConfigurationError",
    "AuthService",
    "OAuthVerificationError",
    "SessionTokenError",
]
