from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


AuthProvider = Literal["google", "apple"]


class OAuthVerificationError(ValueError):
    """Raised when an external identity token fails verification."""


@dataclass(frozen=True)
class ProviderClaims:
    provider: AuthProvider
    subject: str
    email: str | None
    email_verified: bool
    display_name: str | None = None
