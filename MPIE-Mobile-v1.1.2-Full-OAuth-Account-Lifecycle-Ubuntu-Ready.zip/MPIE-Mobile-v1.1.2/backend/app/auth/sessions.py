from __future__ import annotations

import hashlib
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt

from ..models import UserRecord


class SessionTokenError(ValueError):
    pass


class SessionManager:
    def __init__(
        self,
        *,
        secret: str,
        access_ttl_seconds: int,
        refresh_ttl_seconds: int,
        issuer: str,
        audience: str,
    ) -> None:
        self.secret = secret
        self.access_ttl_seconds = access_ttl_seconds
        self.refresh_ttl_seconds = refresh_ttl_seconds
        self.issuer = issuer
        self.audience = audience

    def ensure_configured(self) -> None:
        if len(self.secret) < 32:
            raise SessionTokenError("MPIE_SESSION_SECRET must contain at least 32 characters.")

    @staticmethod
    def hash_refresh_token(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def new_refresh_token(self) -> str:
        return secrets.token_urlsafe(48)

    def refresh_expiry(self) -> datetime:
        return datetime.now(UTC) + timedelta(seconds=self.refresh_ttl_seconds)

    def create_access_token(self, user: UserRecord, session_id: str) -> str:
        self.ensure_configured()
        now = datetime.now(UTC)
        payload: dict[str, Any] = {
            "sub": user.id,
            "sid": session_id,
            "iss": self.issuer,
            "aud": self.audience,
            "iat": now,
            "nbf": now,
            "exp": now + timedelta(seconds=self.access_ttl_seconds),
            "type": "access",
        }
        return jwt.encode(payload, self.secret, algorithm="HS256")

    def verify_access_token(self, token: str) -> tuple[str, str]:
        self.ensure_configured()
        try:
            claims = jwt.decode(
                token,
                self.secret,
                algorithms=["HS256"],
                issuer=self.issuer,
                audience=self.audience,
                options={"require": ["sub", "sid", "exp", "iat", "iss", "aud"]},
            )
        except jwt.PyJWTError as exc:
            raise SessionTokenError("MPIE access token is invalid or expired.") from exc
        if claims.get("type") != "access":
            raise SessionTokenError("MPIE token is not an access token.")
        user_id = claims.get("sub")
        session_id = claims.get("sid")
        if not isinstance(user_id, str) or not isinstance(session_id, str):
            raise SessionTokenError("MPIE access token is missing session identity.")
        return user_id, session_id
