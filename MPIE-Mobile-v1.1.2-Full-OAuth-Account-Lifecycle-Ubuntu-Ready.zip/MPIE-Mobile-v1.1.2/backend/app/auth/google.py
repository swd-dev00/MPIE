from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

import jwt

from .claims import OAuthVerificationError, ProviderClaims
from .jwks import JwkSetCache


GOOGLE_ISSUERS = ("accounts.google.com", "https://accounts.google.com")


class GoogleTokenVerifier:
    def __init__(self, client_ids: Sequence[str], jwks: JwkSetCache) -> None:
        self.client_ids = tuple(item for item in client_ids if item)
        self.jwks = jwks

    def verify(self, id_token: str, *, expected_nonce: str | None = None) -> ProviderClaims:
        if not self.client_ids:
            raise OAuthVerificationError("Google OAuth client IDs are not configured.")
        try:
            header = jwt.get_unverified_header(id_token)
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Google identity token header is invalid.") from exc
        if header.get("alg") != "RS256":
            raise OAuthVerificationError("Google identity token must use RS256.")

        jwk = self.jwks.get(str(header.get("kid", "")))
        key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(dict(jwk)))
        try:
            claims: dict[str, Any] = jwt.decode(
                id_token,
                key=key,
                algorithms=["RS256"],
                audience=list(self.client_ids),
                issuer=list(GOOGLE_ISSUERS),
                options={"require": ["exp", "iat", "iss", "aud", "sub"]},
            )
        except jwt.PyJWTError as exc:
            raise OAuthVerificationError("Google identity token verification failed.") from exc

        if expected_nonce is not None and claims.get("nonce") != expected_nonce:
            raise OAuthVerificationError("Google identity token nonce does not match.")

        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject:
            raise OAuthVerificationError("Google identity token is missing a subject.")

        email = claims.get("email") if isinstance(claims.get("email"), str) else None
        email_verified = claims.get("email_verified") is True
        display_name = claims.get("name") if isinstance(claims.get("name"), str) else None
        return ProviderClaims(
            provider="google",
            subject=subject,
            email=email,
            email_verified=email_verified,
            display_name=display_name,
        )
