from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable

from .config import Settings
from .models import (
    BookmakerQuote,
    Game,
    MarketPriceResponse,
    PredictionResponse,
    PressureFactor,
    PressureResponse,
    Signal,
    Team,
)

logger = logging.getLogger(__name__)


class AnalyticsRepository:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._client: Any | None = None
        self._fixture = self._load_fixture(settings.fixture_path)

    @staticmethod
    def _load_fixture(path: Path) -> dict[str, Any]:
        if not path.exists():
            return {"games": [], "signals": [], "marketPrices": {}}
        return json.loads(path.read_text(encoding="utf-8"))

    def _get_client(self) -> Any:
        if self._client is None:
            import clickhouse_connect

            # FastAPI can execute synchronous handlers concurrently. A shared
            # ClickHouse Connect client therefore must not reuse one generated
            # server session across concurrent requests.
            self._client = clickhouse_connect.get_client(
                host=self.settings.clickhouse_host,
                port=self.settings.clickhouse_port,
                username=self.settings.clickhouse_user,
                password=self.settings.clickhouse_password,
                database=self.settings.clickhouse_database,
                secure=self.settings.clickhouse_secure,
                autogenerate_session_id=False,
            )
        return self._client

    def close(self) -> None:
        if self._client is not None:
            close = getattr(self._client, "close", None)
            if callable(close):
                close()
            self._client = None

    def get_games(self) -> list[Game]:
        if self.settings.demo_mode:
            return [Game.model_validate(item) for item in self._fixture.get("games", [])]
        return self._get_clickhouse_games(limit=self.settings.market_limit)

    def get_game(self, event_id: str) -> Game | None:
        if self.settings.demo_mode:
            return next((game for game in self.get_games() if game.id == event_id), None)

        # Avoid loading the entire market board for a single-event request or
        # watchlist validation.
        games = self._get_clickhouse_games(event_id=event_id, limit=1)
        return games[0] if games else None

    def get_market_prices(
        self,
        event_id: str,
        *,
        market_key: str | None = None,
        outcome: str | None = None,
    ) -> MarketPriceResponse | None:
        if self.settings.demo_mode:
            game = self.get_game(event_id)
            if game is None:
                return None
            selected_market_key = market_key or game.marketKey
            selected_outcome = outcome or game.outcome or game.pick
            raw_quotes = self._fixture.get("marketPrices", {}).get(event_id, [])
            quotes = [
                BookmakerQuote.model_validate(item)
                for item in raw_quotes
                if item.get("marketKey") == selected_market_key
                and item.get("outcome") == selected_outcome
            ]
            if not quotes:
                return None
            return self._build_market_price_response(
                event_id=event_id,
                market_key=selected_market_key,
                market_name=quotes[0].marketName or game.market,
                outcome=selected_outcome,
                quotes=quotes,
            )

        selected_market_key = market_key
        selected_outcome = outcome
        if not selected_market_key or not selected_outcome:
            game = self.get_game(event_id)
            if game is None:
                return None
            selected_market_key = selected_market_key or game.marketKey
            selected_outcome = selected_outcome or game.outcome

        rows = self._query_latest_odds_rows(
            [event_id],
            market_key=selected_market_key,
            outcome=selected_outcome,
        )
        boards = self._market_price_map_from_rows(rows)
        return boards.get((event_id, selected_market_key, selected_outcome))

    @staticmethod
    def _normalized_status(value: Any, event_id: str) -> str:
        status = str(value).upper()
        if status in {"LIVE", "UPCOMING", "FINAL"}:
            return status
        logger.error("Invalid event status for %s: %r; using UPCOMING.", event_id, value)
        return "UPCOMING"

    @staticmethod
    def _normalized_pick_side(value: Any, event_id: str) -> str:
        side = str(value).lower()
        if side in {"home", "away"}:
            return side
        logger.error("Invalid pick side for %s: %r; using home.", event_id, value)
        return "home"

    @staticmethod
    def _normalized_probability(value: Any, fallback: Any, *, label: str, event_id: str) -> float:
        try:
            probability = float(value)
        except (TypeError, ValueError):
            probability = float(fallback)
        if 0.0 <= probability <= 1.0:
            return probability
        logger.error("Invalid %s probability for %s: %r; using prediction fallback.", label, event_id, value)
        fallback_probability = float(fallback)
        return min(1.0, max(0.0, fallback_probability))

    @staticmethod
    def _as_utc(value: datetime) -> datetime:
        return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)

    def _quote_status(
        self,
        *,
        decimal_odds: float,
        implied_probability: float,
        last_updated_at: datetime,
    ) -> str:
        if decimal_odds <= 1.0 or not 0.0 < implied_probability <= 1.0:
            return "SUSPENDED"
        age_seconds = (datetime.now(UTC) - self._as_utc(last_updated_at)).total_seconds()
        if age_seconds > self.settings.odds_stale_seconds:
            return "STALE"
        return "ACTIVE"

    @staticmethod
    def _build_market_price_response(
        *,
        event_id: str,
        market_key: str,
        market_name: str,
        outcome: str,
        quotes: list[BookmakerQuote],
    ) -> MarketPriceResponse:
        active_quotes = [quote for quote in quotes if quote.status == "ACTIVE"]
        usable_quotes = active_quotes or [quote for quote in quotes if quote.status != "SUSPENDED"]

        consensus_decimal_odds: float | None = None
        if usable_quotes:
            average_implied = sum(quote.impliedProbability for quote in usable_quotes) / len(usable_quotes)
            if average_implied > 0:
                consensus_decimal_odds = 1.0 / average_implied

        best_quote = max(
            usable_quotes,
            key=lambda quote: (
                quote.decimalOdds,
                quote.lastUpdatedAt.timestamp(),
                quote.bookmakerKey,
            ),
            default=None,
        )

        enriched_quotes: list[BookmakerQuote] = []
        for quote in quotes:
            difference = (
                (quote.decimalOdds / consensus_decimal_odds - 1.0) * 100.0
                if consensus_decimal_odds
                else 0.0
            )
            enriched_quotes.append(
                quote.model_copy(
                    update={
                        "isBestPrice": best_quote is not None
                        and quote.bookmakerKey == best_quote.bookmakerKey,
                        "differenceFromConsensusPct": difference,
                    }
                )
            )

        status_rank = {"ACTIVE": 0, "STALE": 1, "SUSPENDED": 2}
        enriched_quotes.sort(
            key=lambda quote: (
                status_rank[quote.status],
                -quote.decimalOdds,
                quote.bookmakerTitle.lower(),
            )
        )

        return MarketPriceResponse(
            eventId=event_id,
            marketKey=market_key,
            marketName=market_name,
            outcome=outcome,
            bestBookmakerKey=best_quote.bookmakerKey if best_quote else None,
            bestBookmakerTitle=best_quote.bookmakerTitle if best_quote else None,
            bestDecimalOdds=best_quote.decimalOdds if best_quote else None,
            consensusDecimalOdds=consensus_decimal_odds,
            quoteCount=len(enriched_quotes),
            quotes=enriched_quotes,
        )

    def get_signals(self) -> list[Signal]:
        if self.settings.demo_mode:
            return [Signal.model_validate(item) for item in self._fixture.get("signals", [])]

        query = """
            SELECT
                toString(signal_id), event_id, title, subtitle, value, strength,
                direction, description, severity, triggered_at
            FROM mpie.signal_history
            ORDER BY triggered_at DESC
            LIMIT {limit:UInt16}
        """
        rows = self._get_client().query(
            query,
            parameters={"limit": self.settings.signal_limit},
        ).result_rows
        signals: list[Signal] = []
        for row in rows:
            direction = str(row[6]).lower()
            if direction not in {"positive", "negative"}:
                direction = "positive" if float(row[4]) >= 0 else "negative"
                logger.error("Invalid signal direction for %s; inferred %s.", row[0], direction)
            severity = str(row[8]).upper()
            if severity not in {"INFO", "WARNING", "CRITICAL"}:
                logger.error("Invalid signal severity for %s: %r; using INFO.", row[0], row[8])
                severity = "INFO"
            strength = min(1.0, max(0.0, float(row[5])))
            signals.append(
                Signal(
                    id=row[0],
                    eventId=row[1],
                    title=row[2],
                    subtitle=row[3],
                    value=f"{float(row[4]) * 100:+.1f}%",
                    strength=strength,
                    direction=direction,
                    detail=row[7],
                    severity=severity,
                    triggeredAt=row[9],
                )
            )
        return signals

    def get_predictions(self, event_id: str) -> list[PredictionResponse]:
        if self.settings.demo_mode:
            game = self.get_game(event_id)
            if game is None:
                return []
            return [
                PredictionResponse(
                    eventId=game.id,
                    marketKey=game.marketKey,
                    outcome=game.outcome or game.pick,
                    modelProbability=game.modelProbability,
                    baselineProbability=game.baselineProbability,
                    marketImpliedProbability=game.impliedProbability,
                    edge=game.edge,
                    confidence=game.confidence,
                    recommendedSizePct=max(0.0, game.edge * game.confidence),
                    modelVersion=game.modelVersion,
                    calculatedAt=game.calculatedAt or datetime.now(UTC),
                )
            ]

        # Use one tuple-valued argMax so every returned metric comes from the
        # same prediction row. prediction_id provides a deterministic tiebreaker
        # when two records share the same millisecond timestamp.
        query = """
            SELECT
                event_id,
                market_key,
                outcome,
                latest.1 AS model_prob,
                latest.2 AS baseline_prob,
                latest.3 AS market_implied_prob,
                latest.4 AS edge,
                latest.5 AS confidence,
                latest.6 AS recommended_size_pct,
                latest.7 AS model_version,
                latest.8 AS calculated_at
            FROM
            (
                SELECT
                    event_id,
                    market_key,
                    outcome,
                    argMax(
                        tuple(
                            model_prob,
                            baseline_prob,
                            market_implied_prob,
                            edge,
                            confidence,
                            recommended_size_pct,
                            model_version,
                            calculated_at
                        ),
                        tuple(calculated_at, prediction_id)
                    ) AS latest
                FROM mpie.predictions
                WHERE event_id = {event_id:String}
                GROUP BY event_id, market_key, outcome
            )
            ORDER BY edge DESC, confidence DESC
        """
        rows = self._get_client().query(query, parameters={"event_id": event_id}).result_rows
        return [
            PredictionResponse(
                eventId=row[0],
                marketKey=row[1],
                outcome=row[2],
                modelProbability=row[3],
                baselineProbability=row[4],
                marketImpliedProbability=row[5],
                edge=row[6],
                confidence=row[7],
                recommendedSizePct=row[8],
                modelVersion=row[9],
                calculatedAt=row[10],
            )
            for row in rows
        ]

    def get_pressure(self, event_id: str) -> list[PressureResponse]:
        if self.settings.demo_mode:
            game = self.get_game(event_id)
            if game is None:
                return []
            return [
                PressureResponse(
                    eventId=game.id,
                    marketKey=game.marketKey,
                    outcome=game.outcome or game.pick,
                    pressureLoadIndex=game.pressureIndex,
                    pressureDiffScore=game.modelProbability - game.baselineProbability,
                    factors=game.factors,
                    attribution=game.insight,
                    updatedAt=datetime.now(UTC),
                )
            ]

        query = self._pressure_query("event_id = {event_id:String}")
        rows = self._get_client().query(query, parameters={"event_id": event_id}).result_rows
        return self._pressure_rows_to_responses(rows)

    @staticmethod
    def _pressure_query(where_clause: str) -> str:
        # A tuple-valued argMax keeps the pressure metrics, arrays, attribution,
        # and timestamp from one physical record instead of mixing tied rows.
        return f"""
            SELECT
                event_id,
                market_key,
                outcome,
                latest.1 AS pressure_load_index,
                latest.2 AS pressure_diff_score,
                latest.3 AS labels,
                latest.4 AS short_labels,
                latest.5 AS impacts,
                latest.6 AS details,
                latest.7 AS attribution,
                latest.8 AS updated_at
            FROM
            (
                SELECT
                    event_id,
                    market_key,
                    outcome,
                    argMax(
                        tuple(
                            pressure_load_index,
                            pressure_diff_score,
                            pressure_factor_labels,
                            pressure_factor_short_labels,
                            pressure_factor_impacts,
                            pressure_factor_details,
                            attribution,
                            updated_at
                        ),
                        updated_at
                    ) AS latest
                FROM mpie.market_pressure
                WHERE {where_clause}
                GROUP BY event_id, market_key, outcome
            )
        """

    @staticmethod
    def _pressure_factors(row: tuple[Any, ...] | list[Any]) -> list[PressureFactor]:
        labels, short_labels, impacts, details = row[5], row[6], row[7], row[8]
        lengths = (len(labels), len(short_labels), len(impacts), len(details))
        if len(set(lengths)) != 1:
            # Preserve API availability while making the corruption observable.
            # zip truncation is deliberate here and is no longer silent.
            logger.error(
                "Pressure factor array length mismatch for event=%s market=%s outcome=%s: %s",
                row[0],
                row[1],
                row[2],
                lengths,
            )

        return [
            PressureFactor(label=label, shortLabel=short, impact=impact, detail=detail)
            for label, short, impact, detail in zip(
                labels,
                short_labels,
                impacts,
                details,
                strict=False,
            )
        ]

    def _pressure_rows_to_responses(
        self,
        rows: Iterable[tuple[Any, ...] | list[Any]],
    ) -> list[PressureResponse]:
        return [
            PressureResponse(
                eventId=row[0],
                marketKey=row[1],
                outcome=row[2],
                pressureLoadIndex=row[3],
                pressureDiffScore=row[4],
                factors=self._pressure_factors(row),
                attribution=row[9],
                updatedAt=row[10],
            )
            for row in rows
        ]

    def _get_clickhouse_games(
        self,
        *,
        event_id: str | None = None,
        limit: int,
    ) -> list[Game]:
        prediction_filters = [
            "calculated_at >= now() - toIntervalDay({lookback_days:UInt16})",
        ]
        parameters: dict[str, Any] = {
            "lookback_days": self.settings.market_lookback_days,
            "limit": limit,
        }
        if event_id is not None:
            prediction_filters.append("event_id = {event_id:String}")
            parameters["event_id"] = event_id

        predictions = self._get_client().query(
            f"""
            SELECT *
            FROM
            (
                SELECT
                    event_id,
                    market_key,
                    outcome,
                    latest.1 AS sport_key,
                    latest.2 AS market_name,
                    latest.3 AS pick_label,
                    latest.4 AS pick_side,
                    latest.5 AS model_prob,
                    latest.6 AS baseline_prob,
                    latest.7 AS market_implied_prob,
                    latest.8 AS edge,
                    latest.9 AS confidence,
                    latest.10 AS model_version,
                    latest.11 AS calculated_at,
                    row_number() OVER
                    (
                        PARTITION BY event_id
                        ORDER BY latest.8 DESC, latest.9 DESC, latest.11 DESC
                    ) AS event_rank
                FROM
                (
                    SELECT
                        event_id,
                        market_key,
                        outcome,
                        argMax(
                            tuple(
                                sport_key,
                                market_name,
                                pick_label,
                                pick_side,
                                model_prob,
                                baseline_prob,
                                market_implied_prob,
                                edge,
                                confidence,
                                model_version,
                                calculated_at
                            ),
                            tuple(calculated_at, prediction_id)
                        ) AS latest
                    FROM mpie.predictions
                    WHERE {' AND '.join(prediction_filters)}
                    GROUP BY event_id, market_key, outcome
                )
            )
            WHERE event_rank = 1
            ORDER BY edge DESC, confidence DESC
            LIMIT {{limit:UInt16}}
            """,
            parameters=parameters,
        ).result_rows
        if not predictions:
            return []

        event_ids = list(dict.fromkeys(row[0] for row in predictions))
        events = self._get_events(event_ids)
        pressure_by_key = {
            (response.eventId, response.marketKey, response.outcome): response
            for response in self.get_pressure_for_events(event_ids)
        }
        price_boards = self._get_market_price_map(event_ids)

        games: list[Game] = []
        for row in predictions:
            current_event_id, market_key, outcome = row[0], row[1], row[2]
            event = events.get(current_event_id)
            if event is None:
                logger.warning("Prediction references missing event_catalog row: %s", current_event_id)
                continue

            pressure = pressure_by_key.get((current_event_id, market_key, outcome))
            price_board = price_boards.get((current_event_id, market_key, outcome))
            best_quote = (
                next((quote for quote in price_board.quotes if quote.isBestPrice), None)
                if price_board
                else None
            )
            implied = self._normalized_probability(
                best_quote.impliedProbability if best_quote else row[9],
                row[9],
                label="market implied",
                event_id=current_event_id,
            )
            decimal_odds = (
                float(best_quote.decimalOdds)
                if best_quote
                else (1.0 / implied if implied > 0 else 2.0)
            )

            # Protect the response model from malformed upstream odds while
            # retaining a usable fallback derived from implied probability.
            if decimal_odds <= 1.0:
                decimal_odds = 1.0 / implied if 0 < implied < 1 else 2.0

            consensus_odds = price_board.consensusDecimalOdds if price_board else None
            difference_from_consensus = (
                (decimal_odds / consensus_odds - 1.0) * 100.0 if consensus_odds else 0.0
            )

            games.append(
                Game(
                    id=current_event_id,
                    league=event[1] or row[3],
                    status=self._normalized_status(event[2], current_event_id),
                    startAt=event[3],
                    venue=event[4],
                    home=Team(
                        name=event[5],
                        city=event[6],
                        abbreviation=event[7],
                        record=event[8],
                        score=event[9],
                    ),
                    away=Team(
                        name=event[10],
                        city=event[11],
                        abbreviation=event[12],
                        record=event[13],
                        score=event[14],
                    ),
                    pick=row[5] or outcome,
                    pickSide=self._normalized_pick_side(row[6], current_event_id),
                    market=row[4],
                    marketKey=market_key,
                    outcome=outcome,
                    decimalOdds=decimal_odds,
                    impliedProbability=implied,
                    bestBookmakerKey=best_quote.bookmakerKey if best_quote else None,
                    bestBookmakerTitle=best_quote.bookmakerTitle if best_quote else None,
                    oddsUpdatedAt=best_quote.lastUpdatedAt if best_quote else None,
                    oddsStatus=best_quote.status if best_quote else "SUSPENDED",
                    consensusDecimalOdds=consensus_odds,
                    bookmakerCount=price_board.quoteCount if price_board else 0,
                    differenceFromConsensusPct=difference_from_consensus,
                    modelVersion=row[12],
                    calculatedAt=row[13],
                    modelProbability=row[7],
                    baselineProbability=row[8],
                    edge=row[10],
                    confidence=row[11],
                    pressureIndex=pressure.pressureLoadIndex if pressure else 0,
                    projectedReturn=(decimal_odds - 1.0) * 100.0,
                    factors=pressure.factors if pressure else [],
                    insight=pressure.attribution if pressure else "Pressure attribution pending.",
                )
            )
        return games

    def _get_events(self, event_ids: list[str]) -> dict[str, tuple[Any, ...]]:
        query = """
            SELECT
                event_id,
                latest.1 AS league,
                latest.2 AS status,
                latest.3 AS commence_time,
                latest.4 AS venue,
                latest.5 AS home_name,
                latest.6 AS home_city,
                latest.7 AS home_abbreviation,
                latest.8 AS home_record,
                latest.9 AS home_score,
                latest.10 AS away_name,
                latest.11 AS away_city,
                latest.12 AS away_abbreviation,
                latest.13 AS away_record,
                latest.14 AS away_score
            FROM
            (
                SELECT
                    event_id,
                    argMax(
                        tuple(
                            league,
                            status,
                            commence_time,
                            venue,
                            home_name,
                            home_city,
                            home_abbreviation,
                            home_record,
                            home_score,
                            away_name,
                            away_city,
                            away_abbreviation,
                            away_record,
                            away_score
                        ),
                        updated_at
                    ) AS latest
                FROM mpie.event_catalog
                WHERE event_id IN {event_ids:Array(String)}
                GROUP BY event_id
            )
        """
        rows = self._get_client().query(query, parameters={"event_ids": event_ids}).result_rows
        return {row[0]: row for row in rows}

    def _query_latest_odds_rows(
        self,
        event_ids: list[str],
        *,
        market_key: str | None = None,
        outcome: str | None = None,
    ) -> list[tuple[Any, ...]]:
        filters = ["event_id IN {event_ids:Array(String)}"]
        parameters: dict[str, Any] = {"event_ids": event_ids}
        if market_key is not None:
            filters.append("market_key = {market_key:String}")
            parameters["market_key"] = market_key
        if outcome is not None:
            filters.append("outcome = {outcome:String}")
            parameters["outcome"] = outcome

        query = f"""
            SELECT
                event_id,
                bookmaker_key,
                latest.1 AS bookmaker_title,
                market_key,
                latest.2 AS market_name,
                outcome,
                latest.3 AS last_price,
                latest.4 AS last_implied_prob,
                latest.5 AS last_update
            FROM
            (
                SELECT
                    event_id,
                    bookmaker_key,
                    market_key,
                    outcome,
                    argMax(
                        tuple(
                            bookmaker_title,
                            market_name,
                            last_price,
                            last_implied_prob,
                            last_update
                        ),
                        last_update
                    ) AS latest
                FROM mpie.odds_snapshot
                WHERE {' AND '.join(filters)}
                GROUP BY event_id, bookmaker_key, market_key, outcome
            )
            ORDER BY event_id, market_key, outcome, bookmaker_key
        """
        return self._get_client().query(query, parameters=parameters).result_rows

    def _market_price_map_from_rows(
        self,
        rows: Iterable[tuple[Any, ...] | list[Any]],
    ) -> dict[tuple[str, str, str], MarketPriceResponse]:
        grouped: dict[tuple[str, str, str], list[BookmakerQuote]] = defaultdict(list)
        market_names: dict[tuple[str, str, str], str] = {}

        for row in rows:
            event_id, bookmaker_key, bookmaker_title, market_key, market_name, outcome = row[:6]
            decimal_odds = float(row[6])
            implied_probability = float(row[7])
            last_updated_at = row[8]
            key = (str(event_id), str(market_key), str(outcome))
            market_names[key] = str(market_name)

            # Invalid quotes remain visible as SUSPENDED rather than becoming
            # eligible for best-price or consensus calculations.
            safe_odds = decimal_odds if decimal_odds > 1.0 else 1.000001
            safe_implied = min(1.0, max(0.0, implied_probability))
            status = self._quote_status(
                decimal_odds=decimal_odds,
                implied_probability=implied_probability,
                last_updated_at=last_updated_at,
            )
            grouped[key].append(
                BookmakerQuote(
                    bookmakerKey=str(bookmaker_key),
                    bookmakerTitle=str(bookmaker_title),
                    marketKey=str(market_key),
                    marketName=str(market_name),
                    outcome=str(outcome),
                    decimalOdds=safe_odds,
                    impliedProbability=safe_implied,
                    lastUpdatedAt=last_updated_at,
                    status=status,
                )
            )

        return {
            key: self._build_market_price_response(
                event_id=key[0],
                market_key=key[1],
                market_name=market_names[key],
                outcome=key[2],
                quotes=quotes,
            )
            for key, quotes in grouped.items()
        }

    def _get_market_price_map(
        self,
        event_ids: list[str],
    ) -> dict[tuple[str, str, str], MarketPriceResponse]:
        if not event_ids:
            return {}
        return self._market_price_map_from_rows(self._query_latest_odds_rows(event_ids))

    def get_pressure_for_events(self, event_ids: list[str]) -> list[PressureResponse]:
        if not event_ids:
            return []
        query = self._pressure_query("event_id IN {event_ids:Array(String)}")
        rows = self._get_client().query(query, parameters={"event_ids": event_ids}).result_rows
        return self._pressure_rows_to_responses(rows)
