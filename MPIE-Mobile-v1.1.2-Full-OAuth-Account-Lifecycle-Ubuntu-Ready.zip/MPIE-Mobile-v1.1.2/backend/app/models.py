from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class Team(BaseModel):
    name: str
    city: str = ""
    abbreviation: str
    record: str = "—"
    score: int | None = None


class PressureFactor(BaseModel):
    label: str
    shortLabel: str
    impact: float
    detail: str


class Game(BaseModel):
    id: str
    league: str
    status: Literal["LIVE", "UPCOMING", "FINAL"] = "UPCOMING"
    startAt: datetime
    venue: str = "Venue pending"
    home: Team
    away: Team
    pick: str
    pickSide: Literal["home", "away"] = "home"
    market: str
    marketKey: str = ""
    outcome: str = ""
    decimalOdds: float = Field(gt=1.0)
    impliedProbability: float = Field(ge=0.0, le=1.0)
    bestBookmakerKey: str | None = None
    bestBookmakerTitle: str | None = None
    oddsUpdatedAt: datetime | None = None
    oddsStatus: Literal["ACTIVE", "STALE", "SUSPENDED"] = "ACTIVE"
    consensusDecimalOdds: float | None = Field(default=None, gt=1.0)
    bookmakerCount: int = Field(default=0, ge=0)
    differenceFromConsensusPct: float = 0.0
    modelVersion: str = "unversioned"
    calculatedAt: datetime | None = None
    modelProbability: float = Field(ge=0.0, le=1.0)
    baselineProbability: float = Field(ge=0.0, le=1.0)
    edge: float
    confidence: float = Field(ge=0.0, le=1.0)
    pressureIndex: float
    projectedReturn: float
    factors: list[PressureFactor]
    insight: str


class Signal(BaseModel):
    id: str
    eventId: str | None = None
    title: str
    subtitle: str
    value: str
    strength: float = Field(ge=0.0, le=1.0)
    direction: Literal["positive", "negative"]
    detail: str
    severity: Literal["INFO", "WARNING", "CRITICAL"] = "INFO"
    triggeredAt: datetime | None = None


class PredictionResponse(BaseModel):
    eventId: str
    marketKey: str
    outcome: str
    modelProbability: float = Field(ge=0.0, le=1.0)
    baselineProbability: float = Field(ge=0.0, le=1.0)
    marketImpliedProbability: float = Field(ge=0.0, le=1.0)
    edge: float
    confidence: float = Field(ge=0.0, le=1.0)
    recommendedSizePct: float = Field(ge=0.0)
    modelVersion: str
    calculatedAt: datetime


class PressureResponse(BaseModel):
    eventId: str
    marketKey: str
    outcome: str
    pressureLoadIndex: float
    pressureDiffScore: float
    factors: list[PressureFactor]
    attribution: str
    updatedAt: datetime


class BookmakerQuote(BaseModel):
    bookmakerKey: str
    bookmakerTitle: str
    marketKey: str
    marketName: str
    outcome: str
    decimalOdds: float = Field(gt=1.0)
    impliedProbability: float = Field(ge=0.0, le=1.0)
    lastUpdatedAt: datetime
    status: Literal["ACTIVE", "STALE", "SUSPENDED"] = "ACTIVE"
    isBestPrice: bool = False
    differenceFromConsensusPct: float = 0.0


class MarketPriceResponse(BaseModel):
    eventId: str
    marketKey: str
    marketName: str
    outcome: str
    bestBookmakerKey: str | None = None
    bestBookmakerTitle: str | None = None
    bestDecimalOdds: float | None = Field(default=None, gt=1.0)
    consensusDecimalOdds: float | None = Field(default=None, gt=1.0)
    quoteCount: int = Field(default=0, ge=0)
    quotes: list[BookmakerQuote]


class PortfolioPosition(BaseModel):
    id: str
    eventId: str
    marketKey: str
    outcome: str
    label: str
    game: str
    stake: float = Field(ge=0.0)
    odds: float = Field(gt=1.0)
    bookmakerKey: str | None = None
    bookmakerTitle: str | None = None
    status: str
    pnl: float = 0.0
    openedAt: datetime | None = None


class PositionCreate(BaseModel):
    eventId: str
    marketKey: str
    outcome: str
    label: str | None = None
    game: str | None = None
    entryPrice: float = Field(gt=1.0)
    sizeUnits: float = Field(gt=0.0)
    bookmakerKey: str | None = Field(default=None, max_length=120)
    bookmakerTitle: str | None = Field(default=None, max_length=160)
    status: str = "Open"


class WatchlistResponse(BaseModel):
    eventIds: list[str]


class PlaybookEntry(BaseModel):
    id: str
    title: str
    bodyMarkdown: str
    createdAt: datetime
    updatedAt: datetime


class PlaybookEntryCreate(BaseModel):
    title: str = Field(default="Untitled entry", min_length=1, max_length=160)
    bodyMarkdown: str = Field(default="", max_length=100_000)

    @field_validator("title")
    @classmethod
    def normalize_title(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Playbook entry title cannot be blank.")
        return normalized


class PlaybookEntryUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=160)
    bodyMarkdown: str | None = Field(default=None, max_length=100_000)

    @field_validator("title")
    @classmethod
    def normalize_title(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("Playbook entry title cannot be blank.")
        return normalized

    @model_validator(mode="after")
    def require_change(self) -> "PlaybookEntryUpdate":
        if self.title is None and self.bodyMarkdown is None:
            raise ValueError("At least one Playbook entry field must be provided.")
        return self


class MutationResponse(BaseModel):
    status: Literal["success"] = "success"
    eventId: str | None = None


class UserRecord(BaseModel):
    id: str
    email: str | None = None
    displayName: str | None = None
    status: Literal["active", "disabled"] = "active"
    createdAt: datetime
    updatedAt: datetime
    lastLoginAt: datetime | None = None


class OAuthLoginRequest(BaseModel):
    idToken: str = Field(min_length=32, max_length=20_000)
    nonce: str = Field(min_length=8, max_length=512)
    displayName: str | None = Field(default=None, max_length=160)


class AppleWebhookPayload(BaseModel):
    payload: str = Field(min_length=32, max_length=50_000)


class RefreshTokenRequest(BaseModel):
    refreshToken: str = Field(min_length=32, max_length=1_024)


class LogoutRequest(BaseModel):
    refreshToken: str = Field(min_length=32, max_length=1_024)


class AuthSessionResponse(BaseModel):
    accessToken: str
    refreshToken: str
    tokenType: Literal["Bearer"] = "Bearer"
    expiresIn: int = Field(gt=0)
    user: UserRecord


class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    mode: Literal["demo", "clickhouse"]
    version: str
