from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from uuid import UUID

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Response, status
from fastapi.middleware.cors import CORSMiddleware

from .auth import AuthConfigurationError, AuthService, OAuthVerificationError
from .auth.sessions import SessionTokenError
from .config import settings
from .models import (
    Game,
    AuthSessionResponse,
    AppleWebhookPayload,
    HealthResponse,
    LogoutRequest,
    MarketPriceResponse,
    MutationResponse,
    OAuthLoginRequest,
    PlaybookEntry,
    PlaybookEntryCreate,
    PlaybookEntryUpdate,
    PortfolioPosition,
    PositionCreate,
    PredictionResponse,
    PressureResponse,
    RefreshTokenRequest,
    Signal,
    UserRecord,
    WatchlistResponse,
)
from .repository import AnalyticsRepository
from .state import StateStore


analytics = AnalyticsRepository(settings)
state_store = StateStore(settings.sqlite_path, settings.fixture_path)
state_store.seed_demo_state(settings.default_user_id)
auth_service = AuthService(settings, state_store)
auth_logger = logging.getLogger("mpie.auth.apple")


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    analytics.close()
    auth_service.close()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="API boundary between MPIE analytics and the Expo mobile client.",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-MPIE-User-ID"],
)

def current_user_id(
    authorization: str | None = Header(default=None),
    x_mpie_user_id: str | None = Header(default=None),
) -> str:
    if settings.auth_enabled:
        scheme, _, token = (authorization or "").partition(" ")
        if scheme.lower() != "bearer" or not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="A Bearer access token is required.",
                headers={"WWW-Authenticate": "Bearer"},
            )
        try:
            return auth_service.authenticate_access_token(token).user_id
        except AuthConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=str(exc),
            ) from exc
        except SessionTokenError as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=str(exc),
                headers={"WWW-Authenticate": "Bearer"},
            ) from exc

    candidate = x_mpie_user_id or settings.default_user_id
    try:
        return str(UUID(candidate))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="X-MPIE-User-ID must be a valid UUID.") from exc


def _auth_unavailable(exc: AuthConfigurationError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))


def _auth_rejected(exc: Exception) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=str(exc),
        headers={"WWW-Authenticate": "Bearer"},
    )


@app.get("/health", response_model=HealthResponse, tags=["System"])
def health() -> HealthResponse:
    return HealthResponse(
        mode="demo" if settings.demo_mode else "clickhouse",
        version=settings.app_version,
    )


@app.post(
    "/api/v1/auth/google",
    response_model=AuthSessionResponse,
    tags=["Authentication"],
)
def login_google(payload: OAuthLoginRequest) -> AuthSessionResponse:
    try:
        return auth_service.login_google(payload.idToken, payload.nonce)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    except OAuthVerificationError as exc:
        raise _auth_rejected(exc) from exc


@app.post(
    "/api/v1/auth/apple",
    response_model=AuthSessionResponse,
    tags=["Authentication"],
)
def login_apple(payload: OAuthLoginRequest) -> AuthSessionResponse:
    try:
        return auth_service.login_apple(payload.idToken, payload.nonce, payload.displayName)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    except OAuthVerificationError as exc:
        raise _auth_rejected(exc) from exc


@app.post(
    "/api/v1/auth/apple/webhook",
    status_code=status.HTTP_200_OK,
    tags=["Authentication"],
)
def apple_webhook(body: AppleWebhookPayload) -> dict[str, str]:
    """Process idempotent Sign in with Apple account-change notifications."""
    try:
        return auth_service.process_apple_notification(body.payload)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    except OAuthVerificationError as exc:
        auth_logger.warning("apple_webhook_verify_failed", extra={"error": str(exc)})
        return {"status": "ignored"}


@app.post(
    "/api/v1/auth/refresh",
    response_model=AuthSessionResponse,
    tags=["Authentication"],
)
def refresh_auth_session(payload: RefreshTokenRequest) -> AuthSessionResponse:
    try:
        return auth_service.refresh(payload.refreshToken)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    except SessionTokenError as exc:
        raise _auth_rejected(exc) from exc


@app.post(
    "/api/v1/auth/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Authentication"],
)
def logout_auth_session(payload: LogoutRequest) -> Response:
    try:
        auth_service.logout(payload.refreshToken)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/api/v1/auth/me", response_model=UserRecord, tags=["Authentication"])
def get_current_user(user_id: str = Depends(current_user_id)) -> UserRecord:
    if not settings.auth_enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="OAuth authentication is disabled.",
        )
    user = auth_service.get_user(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="MPIE user not found.")
    return user


@app.delete(
    "/api/v1/auth/me",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Authentication"],
)
def delete_current_user(user_id: str = Depends(current_user_id)) -> Response:
    try:
        deleted = auth_service.delete_account(user_id)
    except AuthConfigurationError as exc:
        raise _auth_unavailable(exc) from exc
    if not deleted:
        raise HTTPException(status_code=404, detail="MPIE user not found.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/api/v1/markets", response_model=list[Game], tags=["Markets"])
def get_markets() -> list[Game]:
    return analytics.get_games()


@app.get("/api/v1/markets/{event_id}", response_model=Game, tags=["Markets"])
def get_market(event_id: str) -> Game:
    game = analytics.get_game(event_id)
    if game is None:
        raise HTTPException(status_code=404, detail="Market event not found.")
    return game


@app.get(
    "/api/v1/markets/{event_id}/prices",
    response_model=MarketPriceResponse,
    tags=["Markets"],
)
def get_market_prices(
    event_id: str,
    market_key: str | None = Query(default=None, min_length=1, max_length=120),
    outcome: str | None = Query(default=None, min_length=1, max_length=240),
) -> MarketPriceResponse:
    prices = analytics.get_market_prices(
        event_id,
        market_key=market_key,
        outcome=outcome,
    )
    if prices is None:
        raise HTTPException(status_code=404, detail="Bookmaker prices not found for this market.")
    return prices


@app.get("/api/v1/signals", response_model=list[Signal], tags=["Signals"])
def get_signals() -> list[Signal]:
    return analytics.get_signals()


@app.get(
    "/api/v1/predictions/{event_id}",
    response_model=list[PredictionResponse],
    tags=["Predictions"],
)
def get_predictions(event_id: str) -> list[PredictionResponse]:
    predictions = analytics.get_predictions(event_id)
    if not predictions:
        raise HTTPException(status_code=404, detail="Prediction not generated for this event.")
    return predictions


@app.get(
    "/api/v1/pressure/{event_id}",
    response_model=list[PressureResponse],
    tags=["Pressure"],
)
def get_pressure(event_id: str) -> list[PressureResponse]:
    pressure = analytics.get_pressure(event_id)
    if not pressure:
        raise HTTPException(status_code=404, detail="Pressure profile not generated for this event.")
    return pressure


@app.get("/api/v1/portfolio", response_model=list[PortfolioPosition], tags=["Portfolio"])
def get_portfolio(user_id: str = Depends(current_user_id)) -> list[PortfolioPosition]:
    return state_store.list_positions(user_id)


@app.post(
    "/api/v1/portfolio/positions",
    response_model=PortfolioPosition,
    status_code=status.HTTP_201_CREATED,
    tags=["Portfolio"],
)
def create_portfolio_position(
    position: PositionCreate,
    user_id: str = Depends(current_user_id),
) -> PortfolioPosition:
    return state_store.create_position(user_id, position)


@app.get("/api/v1/watchlist", response_model=WatchlistResponse, tags=["Watchlist"])
def get_watchlist(user_id: str = Depends(current_user_id)) -> WatchlistResponse:
    return WatchlistResponse(eventIds=state_store.get_watchlist(user_id))


@app.post(
    "/api/v1/watchlist/{event_id}",
    response_model=MutationResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Watchlist"],
)
def add_to_watchlist(event_id: str, user_id: str = Depends(current_user_id)) -> MutationResponse:
    if analytics.get_game(event_id) is None:
        raise HTTPException(status_code=404, detail="Market event not found.")
    state_store.add_watchlist(user_id, event_id)
    return MutationResponse(eventId=event_id)


@app.delete(
    "/api/v1/watchlist/{event_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Watchlist"],
)
def remove_from_watchlist(event_id: str, user_id: str = Depends(current_user_id)) -> Response:
    state_store.remove_watchlist(user_id, event_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/api/v1/playbook", response_model=list[PlaybookEntry], tags=["Playbook"])
def list_playbook_entries(user_id: str = Depends(current_user_id)) -> list[PlaybookEntry]:
    return state_store.list_playbook_entries(user_id)


@app.post(
    "/api/v1/playbook",
    response_model=PlaybookEntry,
    status_code=status.HTTP_201_CREATED,
    tags=["Playbook"],
)
def create_playbook_entry(
    entry: PlaybookEntryCreate,
    user_id: str = Depends(current_user_id),
) -> PlaybookEntry:
    return state_store.create_playbook_entry(user_id, entry)


@app.get(
    "/api/v1/playbook/{entry_id}",
    response_model=PlaybookEntry,
    tags=["Playbook"],
)
def get_playbook_entry(
    entry_id: str,
    user_id: str = Depends(current_user_id),
) -> PlaybookEntry:
    entry = state_store.get_playbook_entry(user_id, entry_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="Playbook entry not found.")
    return entry


@app.patch(
    "/api/v1/playbook/{entry_id}",
    response_model=PlaybookEntry,
    tags=["Playbook"],
)
def update_playbook_entry(
    entry_id: str,
    update: PlaybookEntryUpdate,
    user_id: str = Depends(current_user_id),
) -> PlaybookEntry:
    entry = state_store.update_playbook_entry(user_id, entry_id, update)
    if entry is None:
        raise HTTPException(status_code=404, detail="Playbook entry not found.")
    return entry


@app.delete(
    "/api/v1/playbook/{entry_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Playbook"],
)
def delete_playbook_entry(
    entry_id: str,
    user_id: str = Depends(current_user_id),
) -> Response:
    if not state_store.delete_playbook_entry(user_id, entry_id):
        raise HTTPException(status_code=404, detail="Playbook entry not found.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
