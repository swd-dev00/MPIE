from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _as_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _csv(name: str, *fallback_names: str) -> tuple[str, ...]:
    raw_values = [os.getenv(name, "")]
    raw_values.extend(os.getenv(item, "") for item in fallback_names)
    return tuple(
        value.strip()
        for raw in raw_values
        for value in raw.split(",")
        if value.strip()
    )


def _bounded_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer; received {raw!r}.") from exc
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} must be between {minimum} and {maximum}; received {value}.")
    return value


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("MPIE_APP_NAME", "MPIE Mobile API")
    app_version: str = os.getenv("MPIE_APP_VERSION", "1.1.2")
    demo_mode: bool = _as_bool(os.getenv("MPIE_DEMO_MODE"), True)
    clickhouse_host: str = os.getenv("CLICKHOUSE_HOST", "localhost")
    clickhouse_port: int = int(os.getenv("CLICKHOUSE_PORT", "8123"))
    clickhouse_user: str = os.getenv("CLICKHOUSE_USER", "default")
    clickhouse_password: str = os.getenv("CLICKHOUSE_PASSWORD", "")
    clickhouse_database: str = os.getenv("CLICKHOUSE_DATABASE", "mpie")
    clickhouse_secure: bool = _as_bool(os.getenv("CLICKHOUSE_SECURE"), False)
    sqlite_path: Path = Path(os.getenv("MPIE_STATE_DB", str(ROOT / "data" / "mpie_state.db")))
    fixture_path: Path = Path(os.getenv("MPIE_FIXTURE_PATH", str(ROOT / "fixtures" / "demo.json")))
    cors_origins: tuple[str, ...] = tuple(
        item.strip()
        for item in os.getenv(
            "MPIE_CORS_ORIGINS",
            "http://localhost:8081,http://localhost:19006",
        ).split(",")
        if item.strip()
    )
    default_user_id: str = os.getenv(
        "MPIE_DEFAULT_USER_ID",
        "123e4567-e89b-12d3-a456-426614174000",
    )
    market_limit: int = _bounded_int("MPIE_MARKET_LIMIT", 100, minimum=1, maximum=500)
    market_lookback_days: int = _bounded_int(
        "MPIE_MARKET_LOOKBACK_DAYS",
        30,
        minimum=1,
        maximum=365,
    )
    signal_limit: int = _bounded_int("MPIE_SIGNAL_LIMIT", 50, minimum=1, maximum=500)
    odds_stale_seconds: int = _bounded_int(
        "MPIE_ODDS_STALE_SECONDS",
        300,
        minimum=30,
        maximum=86_400,
    )
    auth_enabled: bool = _as_bool(os.getenv("MPIE_AUTH_ENABLED"), False)
    session_secret: str = os.getenv("MPIE_SESSION_SECRET", "")
    session_ttl_seconds: int = _bounded_int(
        "MPIE_SESSION_TTL_SECONDS", 3600, minimum=300, maximum=86_400
    )
    refresh_ttl_seconds: int = _bounded_int(
        "MPIE_REFRESH_TTL_SECONDS", 2_592_000, minimum=3_600, maximum=31_536_000
    )
    session_issuer: str = os.getenv("MPIE_SESSION_ISSUER", "mpie-api")
    session_audience: str = os.getenv("MPIE_SESSION_AUDIENCE", "mpie-mobile")
    google_client_ids: tuple[str, ...] = _csv(
        "GOOGLE_CLIENT_IDS",
        "GOOGLE_WEB_CLIENT_ID",
        "GOOGLE_IOS_CLIENT_ID",
        "GOOGLE_ANDROID_CLIENT_ID",
    )
    apple_client_ids: tuple[str, ...] = _csv("APPLE_CLIENT_IDS", "APPLE_CLIENT_ID")
    google_jwks_url: str = os.getenv(
        "GOOGLE_JWKS_URL", "https://www.googleapis.com/oauth2/v3/certs"
    )
    apple_jwks_url: str = os.getenv(
        "APPLE_JWKS_URL", "https://appleid.apple.com/auth/keys"
    )


settings = Settings()
