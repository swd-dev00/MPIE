#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BACKEND_DIR"
export PATH="$HOME/.local/bin:$PATH"

if ! command -v uv >/dev/null 2>&1; then
  if ! command -v curl >/dev/null 2>&1; then
    echo "ERROR: curl is required to install uv." >&2
    exit 1
  fi
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

python_selector="3.12"
if ! uv python find 3.12 >/dev/null 2>&1; then
  if ! uv python install 3.12; then
    if command -v python3.12 >/dev/null 2>&1; then
      python_selector="$(command -v python3.12)"
      echo "Using system Python 3.12 because the managed Python download was unavailable."
    elif command -v python3 >/dev/null 2>&1 && python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)'; then
      python_selector="$(command -v python3)"
      echo "WARNING: Python 3.12 download was unavailable; using $(python3 --version)." >&2
    else
      echo "ERROR: Python 3.12+ is unavailable and uv could not download Python 3.12." >&2
      exit 1
    fi
  fi
fi

if [[ "$python_selector" == "3.12" ]]; then
  target_version="3.12"
else
  target_version="$($python_selector -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
fi

if [[ -x .venv/bin/python ]]; then
  current_version="$(.venv/bin/python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  if [[ "$current_version" != "$target_version" ]]; then
    backup=".venv.backup.$(date +%Y%m%d%H%M%S)"
    echo "Existing virtual environment uses Python $current_version; preserving it as $backup."
    mv .venv "$backup"
  fi
fi

if [[ ! -x .venv/bin/python ]]; then
  uv venv --python "$python_selector" .venv
fi

stamp_file=".venv/.mpie-requirements.sha256"
current_hash="$(sha256sum requirements.txt | awk '{print $1}')"
saved_hash=""
[[ -f "$stamp_file" ]] && saved_hash="$(cat "$stamp_file")"

if [[ "$current_hash" != "$saved_hash" || "${MPIE_FORCE_INSTALL:-false}" == "true" ]]; then
  uv pip install --python .venv/bin/python -r requirements.txt
  printf '%s' "$current_hash" > "$stamp_file"
else
  echo "Backend dependencies already match requirements.txt."
fi

mkdir -p data
.venv/bin/python -m compileall -q app scripts tests

echo "Backend environment ready: $BACKEND_DIR/.venv"
