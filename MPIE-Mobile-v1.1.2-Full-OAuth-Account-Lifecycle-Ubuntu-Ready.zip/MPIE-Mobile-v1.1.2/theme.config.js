/** @type {const} */
const themeColors = {
  primary: { light: '#0A9CC0', dark: '#4DE3FF' },
  background: { light: '#F3F7FA', dark: '#071019' },
  surface: { light: '#FFFFFF', dark: '#0D1925' },
  foreground: { light: '#0B1723', dark: '#F3F8FC' },
  muted: { light: '#607180', dark: '#8EA1B4' },
  border: { light: '#DCE5EC', dark: '#1D3142' },
  success: { light: '#119C69', dark: '#9DFF4F' },
  warning: { light: '#C47A00', dark: '#FFBC57' },
  error: { light: '#D94B55', dark: '#FF6B78' },
};

module.exports = { themeColors };
