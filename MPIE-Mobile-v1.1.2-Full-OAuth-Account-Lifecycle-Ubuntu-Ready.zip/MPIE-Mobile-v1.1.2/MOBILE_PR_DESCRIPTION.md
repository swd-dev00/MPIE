# PR: Complete OAuth account lifecycle prebuild for MPIE Mobile v1.1.2

## Purpose

Prepare the complete MPIE Mobile v1.1.2 project for Google and Apple sign-in,
account deletion, and Apple server-to-server account-change notifications while
provider-console credentials are being created. Existing Playbook, markets,
Settings, watchlist, portfolio, ClickHouse, and Ubuntu behavior remains intact.

## Added

- Provider-neutral SQLite `users` table
- `auth_identities` mapping provider `sub` values to internal MPIE UUIDs
- Identity-bound, hashed, rotating, revocable refresh sessions
- Google ID-token verification with mocked-JWK tests
- Apple ID-token and server-notification verification with mocked-JWK tests
- JWK caching with `Cache-Control` support and forced refresh on unknown `kid`
- MPIE HS256 access tokens with issuer, audience, expiry, and session ID
- `/auth/google`, `/auth/apple`, `/auth/refresh`, `/auth/logout`, and `/auth/me`
- `DELETE /api/v1/auth/me` permanent account deletion
- `POST /api/v1/auth/apple/webhook` account-change handling
- Cross-platform typed `DELETE` confirmation UI
- SecureStore/localStorage auth-token helpers and a valid post-deletion login route
- Environment placeholders, setup documentation, and a file-by-file reconciliation

## Apple lifecycle behavior

- `consent-revoked`: revoke identity-attributed sessions and detach Apple only.
- `account-delete`: revoke Apple sessions, detach Apple, and delete the internal
  MPIE user only when no other provider identity remains.
- `email-disabled`: clear the Apple identity email metadata.
- `email-enabled`: acknowledge without guessing a replacement address.
- Unknown or already-deleted identities: idempotent HTTP 200 no-op.
- Invalid signatures: log the verification failure and acknowledge as ignored.

## User-initiated deletion

The Settings flow requires an exact typed `DELETE` phrase. The authenticated
backend operation removes active sessions, provider identities, watchlist rows,
portfolio positions, Playbook entries, and the internal MPIE user. Audit rows,
when present, are de-identified before owned state is removed.

## Compatibility

`MPIE_AUTH_ENABLED=false` remains the default. Existing v1.1.2 development clients
continue to use `X-MPIE-User-ID`. When enabled, protected state endpoints require
a Bearer token. The ClickHouse analytical schema is unchanged.

The SQLite migration is additive:

- Adds `identity_id` to `auth_sessions`
- Adds identity-session indexing
- Adds an optional stake-suggestion audit table for de-identification support
- Preserves existing watchlist, portfolio, Playbook, and auth rows

## Security decisions

- Provider subject, not email, is the durable external identity.
- Equal email addresses do not silently merge Google and Apple accounts.
- Provider signing algorithms are restricted to RS256.
- Issuer, audience, expiry when present, issued-at, subject, and nonce are verified.
- Refresh tokens are stored only as SHA-256 hashes and rotate on use.
- Raw provider tokens, authorization codes, session secrets, and Apple keys are
  excluded from source control and should never be logged.
- Legacy sessions without provider attribution are revoked conservatively during
  identity-disconnect events.

## Test matrix

- Existing API, market, Playbook, watchlist, portfolio, repository, and migration tests
- User and identity CRUD
- Provider-subject idempotency and link-conflict checks
- Existing state preservation
- Google token success/failure and JWK rotation
- Apple first/returning user behavior and JWK rotation
- Apple signed notification verification
- Apple consent-revoked detach-only behavior
- Apple account-delete sole-identity full deletion
- Apple account-delete multi-identity preservation
- Repeated Apple notification idempotency
- Unknown Apple subject acknowledgement
- Identity-scoped and legacy-session revocation
- Authenticated `DELETE /auth/me`
- Invalid Apple webhook signature acknowledgement
- Typed `DELETE` Settings regression tokens

## Manual setup remaining

- Create Google web/iOS/Android OAuth clients
- Configure Apple Sign in with Apple capability and identifiers
- Register the public HTTPS Apple webhook URL
- Add provider credentials to local/deployment secrets
- Connect real Google and Apple sign-in controls to `storeAuthSession`
- Implement Apple authorization-code exchange after Team ID, Key ID, private key,
  client ID, and redirect URI are finalized
- Complete consent-screen, redirect-URI, privacy-policy, retention, and legal review

## Rollback

Set `MPIE_AUTH_ENABLED=false`. The account-lifecycle tables and columns are
additive. Restore the preserved SQLite backup if a complete data rollback is
required.
