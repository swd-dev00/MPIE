# MPIE Mobile v1.1.2 — Full Build Manifest

`scripts/validate-project.mjs` requires **65 deliverables** in this complete archive.

## Required deliverables

### Application routes

- `app/_layout.tsx`
- `app/(tabs)/_layout.tsx`
- `app/(tabs)/index.tsx`
- `app/(tabs)/markets.tsx`
- `app/(tabs)/signals.tsx`
- `app/(tabs)/portfolio.tsx`
- `app/(tabs)/settings.tsx`
- `app/(tabs)/playbook.tsx`
- `app/(auth)/_layout.tsx`
- `app/(auth)/login.tsx`
- `app/about.tsx`
- `app/methodology.tsx`
- `app/privacy.tsx`
- `app/data-provenance.tsx`
- `app/data-source.tsx`
- `app/watchlist-sync.tsx`
- `app/game/[id].tsx`

### Components and frontend logic

- `components/mpie/brand-mark.tsx`
- `components/mpie/ui.tsx`
- `components/mpie/markdown-preview.tsx`
- `components/mpie/info-page.tsx`
- `constants/mpie-data.ts`
- `lib/mpie-api.ts`
- `lib/mpie-data-provider.tsx`
- `lib/mpie-store.tsx`
- `lib/markdown.ts`
- `lib/playbook-draft.ts`
- `lib/mpie-auth.ts`
- `tests/market-pricing.test.ts`
- `tests/settings-navigation.test.ts`
- `eslint.config.mjs`

### Backend, OAuth, tests, and deployment

- `backend/app/main.py`
- `backend/app/state.py`
- `backend/app/models.py`
- `backend/app/config.py`
- `backend/app/auth/__init__.py`
- `backend/app/auth/claims.py`
- `backend/app/auth/jwks.py`
- `backend/app/auth/google.py`
- `backend/app/auth/apple.py`
- `backend/app/auth/sessions.py`
- `backend/app/auth/service.py`
- `backend/tests/test_auth_state.py`
- `backend/tests/test_auth_service.py`
- `backend/tests/test_auth_api_contract.py`
- `backend/tests/test_oauth_google.py`
- `backend/tests/test_oauth_apple.py`
- `backend/requirements.txt`
- `backend/.env.example`
- `backend/sql/001_clickhouse_schema.sql`
- `backend/scripts/validate_backend.py`
- `backend/install_backend.sh`
- `backend/start_api.sh`
- `scripts/ubuntu_update.sh`
- `scripts/ubuntu_smoke_test.sh`

### Documentation and assets

- `README.md`
- `UBUNTU_UPDATE.md`
- `TEST_REPORT.md`
- `API_VERIFICATION.md`
- `OAUTH_SETUP.md`
- `MOBILE_PR_DESCRIPTION.md`
- `FULL_BUILD_MANIFEST.md`
- `ACCOUNT_LIFECYCLE_RECONCILIATION.md`
- `assets/images/icon.png`
- `assets/images/splash-icon.png`

## OAuth and account-lifecycle status

- Authentication remains disabled by default.
- No provider secrets or Apple private keys are included.
- Google and Apple JWK tests use mocked endpoints.
- Sessions are associated with the provider identity that issued them.
- Typed account deletion and Apple account-change handling are prebuilt.
- ClickHouse analytical schema remains unchanged.
- Existing v1.1.2 state is preserved by the Ubuntu updater.

## Validation commands

```bash
pnpm validate
pnpm validate:backend
pnpm test:backend
pnpm check
pnpm lint
pnpm test
bash scripts/ubuntu_smoke_test.sh
```
