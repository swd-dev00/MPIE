import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function LoginScreen() {
  const router = useRouter();
  const colors = useColors();

  return (
    <ScreenContainer className="px-5 justify-center">
      <View className="bg-surface border border-border rounded-[24px] p-6">
        <View className="h-14 w-14 rounded-2xl bg-primary/10 items-center justify-center mb-5">
          <MaterialCommunityIcons name="shield-account-outline" size={28} color={colors.primary} />
        </View>
        <Text className="text-2xl font-black text-foreground">Sign in to MPIE</Text>
        <Text className="text-sm leading-6 text-muted mt-3">
          Google and Apple sign-in are prebuilt but remain disabled until the OAuth client IDs,
          redirect URIs, and server session secret are configured.
        </Text>
        <Pressable
          className="bg-primary rounded-2xl py-3.5 items-center mt-6"
          onPress={() => router.replace("/")}
        >
          <Text className="text-[#071019] font-black">Continue to app</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
