import { InfoPage } from "@/components/mpie/info-page";

export default function AboutScreen() {
  return (
    <InfoPage
      eyebrow="Product"
      title="About MPIE"
      icon="information-outline"
      intro="MPIE—Market Pressure Intelligence Engine—turns market movement, schedule stress, performance context, and model outputs into structured, reviewable decision intelligence."
      sections={[
        {
          title: "What MPIE is built to do",
          bullets: [
            "Compare model probability with market-implied probability.",
            "Decompose pressure adjustments into quantified contributing factors.",
            "Show bookmaker-level pricing instead of hiding the source behind one number.",
            "Preserve model version, calculation time, tracked positions, and user research notes.",
          ],
        },
        {
          title: "Product principle",
          body: [
            "MPIE is designed around rigor made legible: the user should be able to see what changed, which factors contributed, which sportsbook supplied a price, and when the model made its calculation.",
          ],
        },
        {
          title: "What MPIE does not do",
          body: [
            "MPIE does not execute wagers, guarantee outcomes, or replace independent judgment. The current application is an analytical and tracking environment.",
          ],
        },
        {
          title: "Publisher",
          body: ["Sierra Warren Developments, LLC · MPIE Mobile v1.1.2"],
        },
      ]}
    />
  );
}
