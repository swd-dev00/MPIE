import { InfoPage } from "@/components/mpie/info-page";
import { useMpieData } from "@/lib/mpie-data-provider";

export default function DataProvenanceScreen() {
  const { sourceLabel } = useMpieData();

  return (
    <InfoPage
      eyebrow="Trust layer"
      title="Data provenance"
      icon="database-outline"
      intro={`Current source status: ${sourceLabel}. MPIE distinguishes API connectivity from the analytical source behind that API.`}
      sections={[
        {
          title: "Source labels",
          bullets: [
            "API connected · ClickHouse live means the frontend reached FastAPI and the backend reported ClickHouse mode.",
            "API connected · Demo analytics means the frontend reached FastAPI, but the backend is serving the demonstration fixture.",
            "Demonstration fallback means one or more required frontend feeds could not be loaded from the configured API.",
          ],
        },
        {
          title: "Prediction provenance",
          body: [
            "The model version and calculated-at timestamp shown on game details identify the model release and decision time associated with the displayed recommendation.",
          ],
        },
        {
          title: "Market provenance",
          body: [
            "Each sportsbook quote includes a bookmaker key, display name, market, outcome, decimal odds, implied probability, update timestamp, and freshness status. A tracked portfolio position preserves the sportsbook selected by the user.",
          ],
        },
        {
          title: "Reproducibility boundary",
          body: [
            "Reproducing an historical recommendation requires the model version, calculation timestamp, source inputs, bookmaker quote timestamps, event status, and the methodology version used at that time.",
          ],
        },
      ]}
    />
  );
}
