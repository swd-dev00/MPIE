import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMpieStore } from "@/lib/mpie-store";

export default function WatchlistSyncScreen() {
  const router = useRouter();
  const colors = useColors();
  const {
    savedGameIds,
    watchlistPendingCount,
    watchlistSyncError,
    retryWatchlistSync,
  } = useMpieStore();
  const synchronized = watchlistPendingCount === 0 && !watchlistSyncError;

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View className="flex-row items-center pt-2 mb-5">
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({ opacity: pressed ? 0.65 : 1 })}
            className="h-11 w-11 rounded-2xl bg-surface border border-border items-center justify-center mr-4"
            accessibilityRole="button"
            accessibilityLabel="Go back to Settings"
          >
            <MaterialCommunityIcons name="arrow-left" size={22} color={colors.foreground} />
          </Pressable>
          <View className="flex-1">
            <Text className="text-[10px] uppercase tracking-[2px] font-bold text-primary">Account state</Text>
            <Text className="text-2xl font-black text-foreground mt-1">Watchlist sync</Text>
          </View>
        </View>

        <View className={`${synchronized ? "bg-success/10 border-success/25" : "bg-warning/10 border-warning/25"} border rounded-[24px] p-5 mb-4`}>
          <View className={`h-11 w-11 rounded-2xl ${synchronized ? "bg-success/15" : "bg-warning/15"} items-center justify-center mb-4`}>
            <MaterialCommunityIcons
              name={synchronized ? "cloud-check-outline" : "cloud-alert-outline"}
              size={23}
              color={synchronized ? colors.success : colors.warning}
            />
          </View>
          <Text className="text-base font-black text-foreground">
            {synchronized ? "Local and remote watchlists are synchronized" : "Watchlist synchronization needs attention"}
          </Text>
          <Text className="text-xs leading-5 text-muted mt-2">
            {watchlistPendingCount} pending change{watchlistPendingCount === 1 ? "" : "s"} · {savedGameIds.length} saved market{savedGameIds.length === 1 ? "" : "s"}
          </Text>
          {watchlistSyncError ? <Text className="text-xs leading-5 text-error mt-3">{watchlistSyncError}</Text> : null}
        </View>

        <View className="bg-surface border border-border rounded-[22px] p-4 mb-4">
          <Text className="text-base font-black text-foreground">How synchronization works</Text>
          <Text className="text-xs leading-5 text-muted mt-3">
            MPIE preserves local saves, records pending add or remove operations, and retries remote synchronization without replacing established local data with an empty remote response.
          </Text>
        </View>

        <Pressable
          onPress={retryWatchlistSync}
          style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
          className="bg-primary rounded-2xl py-4 px-5 flex-row items-center justify-center"
          accessibilityRole="button"
          accessibilityLabel="Retry watchlist synchronization"
        >
          <MaterialCommunityIcons name="sync" size={20} color="#071019" />
          <Text className="text-sm font-black text-[#071019] ml-2">Retry synchronization</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
