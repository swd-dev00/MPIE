import { InfoPage } from "@/components/mpie/info-page";

export default function MethodologyScreen() {
  return (
    <InfoPage
      eyebrow="Trust layer"
      title="Methodology"
      icon="file-document-outline"
      intro="MPIE separates baseline probability, pressure-adjusted model probability, market-implied probability, bookmaker pricing, and factor attribution so users can inspect the structure behind a recommendation."
      sections={[
        {
          title: "Probability stack",
          bullets: [
            "Baseline probability is the pre-adjustment reference estimate.",
            "Model probability reflects the current pressure-adjusted estimate.",
            "Market-implied probability is derived from the selected sportsbook price.",
            "Edge is the difference between the model estimate and the relevant market reference used by the prediction pipeline.",
          ],
        },
        {
          title: "Pressure decomposition",
          body: [
            "Pressure Load Index and Pressure Diff Score summarize modeled pressure. The contributing labels, impacts, details, and interpretation are stored as structured fields rather than generated as an untraceable paragraph after the fact.",
          ],
        },
        {
          title: "Bookmaker pricing",
          bullets: [
            "MPIE selects the latest stored quote for each sportsbook and market outcome.",
            "Best price is the highest valid active decimal price among the returned sportsbooks.",
            "Consensus decimal odds are calculated from the average implied probability of usable quotes, then converted back to decimal odds.",
            "Quotes exceeding the configured freshness threshold are marked stale; invalid or unavailable quotes are marked suspended.",
          ],
        },
        {
          title: "Model provenance",
          body: [
            "Every displayed recommendation can carry its model version and calculation timestamp. These fields distinguish one model release and decision point from another and support later auditing.",
          ],
        },
        {
          title: "Current limitations",
          bullets: [
            "Consensus pricing is not yet a no-vig fair-probability calculation.",
            "Closing-line value is not yet presented as a finalized production metric.",
            "Results depend on source coverage, timestamp quality, event status, and the freshness of bookmaker updates.",
            "A favorable model edge does not guarantee a favorable outcome.",
          ],
        },
      ]}
      notice="Methodology describes the current v1.1.2 implementation. Production releases should version methodology changes alongside model and schema changes."
    />
  );
}
