import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getMpieApiBaseUrl } from "@/lib/mpie-api";
import { useMpieData } from "@/lib/mpie-data-provider";

export default function DataSourceScreen() {
  const router = useRouter();
  const colors = useColors();
  const { sourceLabel, backendMode, errorMessage, isRefreshing, refresh } = useMpieData();
  const apiBaseUrl = getMpieApiBaseUrl() || "Not configured";

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View className="flex-row items-center pt-2 mb-5">
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({ opacity: pressed ? 0.65 : 1 })}
            className="h-11 w-11 rounded-2xl bg-surface border border-border items-center justify-center mr-4"
            accessibilityRole="button"
            accessibilityLabel="Go back to Settings"
          >
            <MaterialCommunityIcons name="arrow-left" size={22} color={colors.foreground} />
          </Pressable>
          <View className="flex-1">
            <Text className="text-[10px] uppercase tracking-[2px] font-bold text-primary">Diagnostics</Text>
            <Text className="text-2xl font-black text-foreground mt-1">Data source</Text>
          </View>
        </View>

        <View className="bg-primary/10 border border-primary/25 rounded-[24px] p-5 mb-4">
          <View className="h-11 w-11 rounded-2xl bg-primary/15 items-center justify-center mb-4">
            <MaterialCommunityIcons name="database-outline" size={23} color={colors.primary} />
          </View>
          <Text className="text-base font-black text-foreground">{sourceLabel}</Text>
          <Text className="text-xs leading-5 text-muted mt-2">
            This status distinguishes frontend API connectivity from the analytics source behind FastAPI.
          </Text>
        </View>

        <View className="bg-surface border border-border rounded-[22px] p-4 mb-4">
          <Text className="text-xs uppercase tracking-wider font-black text-muted">API endpoint</Text>
          <Text selectable className="text-sm leading-6 text-foreground mt-2">{apiBaseUrl}</Text>
        </View>

        <View className="bg-surface border border-border rounded-[22px] p-4 mb-4">
          <Text className="text-xs uppercase tracking-wider font-black text-muted">Backend mode</Text>
          <Text className="text-base font-black text-foreground mt-2">
            {backendMode === "clickhouse" ? "ClickHouse" : backendMode === "demo" ? "Demo fixture" : "Unavailable"}
          </Text>
          {errorMessage ? <Text className="text-xs leading-5 text-error mt-3">{errorMessage}</Text> : null}
        </View>

        <Pressable
          onPress={() => void refresh()}
          disabled={isRefreshing}
          style={({ pressed }) => ({ opacity: isRefreshing ? 0.5 : pressed ? 0.7 : 1 })}
          className="bg-primary rounded-2xl py-4 px-5 flex-row items-center justify-center"
          accessibilityRole="button"
          accessibilityLabel="Refresh MPIE data source status"
        >
          <MaterialCommunityIcons name={isRefreshing ? "loading" : "refresh"} size={20} color="#071019" />
          <Text className="text-sm font-black text-[#071019] ml-2">
            {isRefreshing ? "Refreshing…" : "Refresh connection"}
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
