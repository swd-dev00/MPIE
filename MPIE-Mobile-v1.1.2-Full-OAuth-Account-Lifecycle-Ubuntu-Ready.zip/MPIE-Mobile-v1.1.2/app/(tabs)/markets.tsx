import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, TextInput, View } from "react-native";

import { AppHeader, GameCard, IconButton } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import { type League } from "@/constants/mpie-data";
import { useColors } from "@/hooks/use-colors";
import { useMpieData } from "@/lib/mpie-data-provider";

const filters: ("All" | League)[] = ["All", "MLB", "WNBA", "NBA", "NFL"];

export default function MarketsScreen() {
  const colors = useColors();
  const { games, source, sourceLabel, isRefreshing, refresh } = useMpieData();
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const [query, setQuery] = useState("");

  const filteredGames = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return games.filter((game) => {
      const matchesLeague = filter === "All" || game.league === filter;
      const matchesQuery =
        !normalized ||
        [game.home.name, game.home.city, game.away.name, game.away.city, game.pick, game.league]
          .join(" ")
          .toLowerCase()
          .includes(normalized);
      return matchesLeague && matchesQuery;
    });
  }, [filter, games, query]);

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="pt-2">
          <AppHeader eyebrow="Live market board" title="Games & edges" right={<IconButton icon={isRefreshing ? "sync" : "refresh"} onPress={() => void refresh()} accessibilityLabel="Refresh markets" active={source === "api"} />} />
        </View>

        <View className="flex-row items-center bg-surface border border-border rounded-2xl px-4 mb-4">
          <MaterialCommunityIcons name="magnify" size={21} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search team, league, or position"
            placeholderTextColor={colors.muted}
            className="flex-1 py-3.5 px-3 text-foreground"
            autoCapitalize="none"
          />
          {query ? (
            <Pressable onPress={() => setQuery("")} hitSlop={8}>
              <MaterialCommunityIcons name="close-circle" size={19} color={colors.muted} />
            </Pressable>
          ) : null}
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingBottom: 16 }}>
          {filters.map((item) => {
            const active = item === filter;
            return (
              <Pressable
                key={item}
                onPress={() => setFilter(item)}
                className={`px-4 py-2.5 rounded-full border ${active ? "bg-primary border-primary" : "bg-surface border-border"}`}
              >
                <Text className={`text-xs font-black ${active ? "text-[#071019]" : "text-muted"}`}>{item}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View className="flex-row items-center justify-between mb-3">
          <Text className="text-sm font-bold text-muted">{filteredGames.length} model positions</Text>
          <View className="flex-row items-center">
            <View className="h-2 w-2 rounded-full bg-success mr-2" />
            <Text className="text-xs font-bold text-muted">{sourceLabel}</Text>
          </View>
        </View>

        {filteredGames.length ? (
          filteredGames.map((game) => <GameCard key={game.id} game={game} />)
        ) : (
          <View className="items-center bg-surface border border-border rounded-[24px] p-8 mt-3">
            <View className="h-14 w-14 rounded-2xl bg-primary/10 items-center justify-center mb-4">
              <MaterialCommunityIcons name="radar" size={28} color={colors.primary} />
            </View>
            <Text className="text-lg font-black text-foreground">No matching positions</Text>
            <Text className="text-sm text-muted text-center mt-2">Adjust the league filter or search another team.</Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
