import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { MarkdownPreview } from "@/components/mpie/markdown-preview";
import { AppHeader, IconButton } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import type { MpiePlaybookEntry } from "@/constants/mpie-data";
import { useColors } from "@/hooks/use-colors";
import {
  createPlaybookEntry,
  deletePlaybookEntry,
  getMpieUserId,
  isMpieApiConfigured,
  loadPlaybookEntries,
  updatePlaybookEntry,
} from "@/lib/mpie-api";
import { markdownExcerpt } from "@/lib/markdown";
import {
  clearPlaybookDraft,
  loadPlaybookDraft,
  savePlaybookDraft,
} from "@/lib/playbook-draft";

const PLAYBOOK_QUERY_KEY = ["mpie-playbook"] as const;
const NEW_ENTRY_MARKDOWN = "# Idea\n\n## Observation\n\n\n## Change to test\n\n- [ ] ";
const DRAFT_SAVE_DELAY_MS = 600;

type EditorMode = "write" | "preview";
type DraftStatus = "idle" | "saving" | "saved" | "restored" | "error";

type SavePayload = {
  id?: string;
  title: string;
  bodyMarkdown: string;
};

function formatUpdatedAt(value: string) {
  const date = new Date(value);
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  return sameDay
    ? date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    : date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function upsertEntry(
  entries: MpiePlaybookEntry[] | undefined,
  saved: MpiePlaybookEntry,
): MpiePlaybookEntry[] {
  const remaining = (entries ?? []).filter((entry) => entry.id !== saved.id);
  return [saved, ...remaining].sort(
    (left, right) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt),
  );
}

export default function PlaybookScreen() {
  const colors = useColors();
  const queryClient = useQueryClient();
  const apiConfigured = isMpieApiConfigured();
  const userId = getMpieUserId();
  const draftSequence = useRef(0);
  const [query, setQuery] = useState("");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | undefined>();
  const [title, setTitle] = useState("");
  const [bodyMarkdown, setBodyMarkdown] = useState("");
  const [editorMode, setEditorMode] = useState<EditorMode>("write");
  const [dirty, setDirty] = useState(false);
  const [draftStatus, setDraftStatus] = useState<DraftStatus>("idle");
  const [editorError, setEditorError] = useState<string | null>(null);

  const playbookQuery = useQuery({
    queryKey: PLAYBOOK_QUERY_KEY,
    queryFn: loadPlaybookEntries,
    enabled: apiConfigured,
    retry: 1,
  });

  const saveMutation = useMutation({
    mutationFn: ({ id, title: nextTitle, bodyMarkdown: nextBody }: SavePayload) =>
      id
        ? updatePlaybookEntry(id, { title: nextTitle, bodyMarkdown: nextBody })
        : createPlaybookEntry({ title: nextTitle, bodyMarkdown: nextBody }),
    onSuccess: async (saved, variables) => {
      draftSequence.current += 1;
      queryClient.setQueryData<MpiePlaybookEntry[]>(
        PLAYBOOK_QUERY_KEY,
        (current) => upsertEntry(current, saved),
      );
      await clearPlaybookDraft(userId, variables.id ?? null);
      setDirty(false);
      setDraftStatus("idle");
      setEditorOpen(false);
      setEditorError(null);
    },
    onError: (error) => {
      setEditorError(
        error instanceof Error
          ? `${error.message} Your work remains saved as a local draft.`
          : "Unable to save the Playbook entry. Your local draft was retained.",
      );
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deletePlaybookEntry,
    onSuccess: async (_, entryId) => {
      draftSequence.current += 1;
      queryClient.setQueryData<MpiePlaybookEntry[]>(PLAYBOOK_QUERY_KEY, (current) =>
        (current ?? []).filter((entry) => entry.id !== entryId),
      );
      await clearPlaybookDraft(userId, entryId);
      setDirty(false);
      setDraftStatus("idle");
      setEditorOpen(false);
      setEditorError(null);
    },
    onError: (error) => {
      setEditorError(
        error instanceof Error ? error.message : "Unable to delete the Playbook entry.",
      );
    },
  });

  useEffect(() => {
    if (!editorOpen || !dirty) return undefined;

    const sequence = draftSequence.current + 1;
    draftSequence.current = sequence;
    setDraftStatus("saving");

    const timer = setTimeout(() => {
      if (draftSequence.current !== sequence) return;
      void savePlaybookDraft(userId, {
        entryId: editingId ?? null,
        title,
        bodyMarkdown,
      })
        .then(() => {
          if (draftSequence.current === sequence) setDraftStatus("saved");
        })
        .catch(() => {
          if (draftSequence.current === sequence) setDraftStatus("error");
        });
    }, DRAFT_SAVE_DELAY_MS);

    return () => clearTimeout(timer);
  }, [bodyMarkdown, dirty, editingId, editorOpen, title, userId]);

  const filteredEntries = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    const entries = playbookQuery.data ?? [];
    if (!normalized) return entries;
    return entries.filter((entry) =>
      `${entry.title} ${markdownExcerpt(entry.bodyMarkdown, 500)}`
        .toLowerCase()
        .includes(normalized),
    );
  }, [playbookQuery.data, query]);

  const openNewEntry = async () => {
    const draft = await loadPlaybookDraft(userId, null).catch(() => null);
    setEditingId(undefined);
    setEditorMode("write");
    setEditorError(null);

    if (draft?.entryId === null) {
      setTitle(draft.title);
      setBodyMarkdown(draft.bodyMarkdown);
      setDirty(true);
      setDraftStatus("restored");
    } else {
      setTitle("Untitled entry");
      setBodyMarkdown(NEW_ENTRY_MARKDOWN);
      setDirty(false);
      setDraftStatus("idle");
    }
    setEditorOpen(true);
  };

  const openExistingEntry = async (entry: MpiePlaybookEntry) => {
    const draft = await loadPlaybookDraft(userId, entry.id).catch(() => null);
    const draftIsNewer = draft?.entryId === entry.id && Date.parse(draft.updatedAt) > Date.parse(entry.updatedAt);

    setEditingId(entry.id);
    setEditorMode("write");
    setEditorError(null);

    if (draftIsNewer && draft) {
      setTitle(draft.title);
      setBodyMarkdown(draft.bodyMarkdown);
      setDirty(true);
      setDraftStatus("restored");
    } else {
      setTitle(entry.title);
      setBodyMarkdown(entry.bodyMarkdown);
      setDirty(false);
      setDraftStatus("idle");
    }
    setEditorOpen(true);
  };

  const persistDraftAndClose = async () => {
    draftSequence.current += 1;
    setDraftStatus("saving");
    try {
      await savePlaybookDraft(userId, {
        entryId: editingId ?? null,
        title,
        bodyMarkdown,
      });
      setDraftStatus("saved");
      setEditorOpen(false);
    } catch {
      setDraftStatus("error");
      setEditorError("The local draft could not be saved. Keep the editor open and try again.");
    }
  };

  const discardAndClose = async () => {
    draftSequence.current += 1;
    await clearPlaybookDraft(userId, editingId ?? null).catch(() => undefined);
    setDirty(false);
    setDraftStatus("idle");
    setEditorOpen(false);
  };

  const closeEditor = () => {
    if (!dirty) {
      setEditorOpen(false);
      return;
    }

    Alert.alert(
      "Close Playbook editor?",
      "Unsaved changes are retained as a local draft until you press Save or discard them.",
      [
        { text: "Keep editing", style: "cancel" },
        { text: "Close with draft", onPress: () => void persistDraftAndClose() },
        { text: "Discard draft", style: "destructive", onPress: () => void discardAndClose() },
      ],
    );
  };

  const saveCurrentEntry = async () => {
    const normalizedTitle = title.trim();
    if (!normalizedTitle) {
      setEditorError("A Playbook entry title is required.");
      return;
    }

    setEditorError(null);
    draftSequence.current += 1;
    try {
      await savePlaybookDraft(userId, {
        entryId: editingId ?? null,
        title: normalizedTitle,
        bodyMarkdown,
      });
      setDraftStatus("saved");
    } catch {
      setDraftStatus("error");
      setEditorError("The local safety draft could not be written. The server save was not attempted.");
      return;
    }

    saveMutation.mutate({ id: editingId, title: normalizedTitle, bodyMarkdown });
  };

  const requestDelete = () => {
    if (!editingId) return;
    Alert.alert("Delete this Playbook entry?", "This action cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => deleteMutation.mutate(editingId),
      },
    ]);
  };

  const draftStatusText =
    draftStatus === "saving"
      ? "Saving local draft…"
      : draftStatus === "saved"
        ? "Draft saved locally · Press Save to sync"
        : draftStatus === "restored"
          ? "Local draft restored · Press Save to sync"
          : draftStatus === "error"
            ? "Local draft could not be saved"
            : "";

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="pt-2">
          <AppHeader
            eyebrow="Decision journal"
            title="Playbook"
            right={
              <IconButton
                icon="book-plus-outline"
                onPress={apiConfigured ? () => void openNewEntry() : undefined}
                accessibilityLabel="Create Playbook entry"
                active={apiConfigured}
              />
            }
          />
        </View>

        <View className="bg-primary/5 border border-primary/20 rounded-[22px] p-4 mb-4">
          <View className="flex-row items-start">
            <MaterialCommunityIcons name="language-markdown-outline" size={22} color={colors.primary} />
            <View className="flex-1 ml-3">
              <Text className="text-sm font-black text-foreground">Markdown-only entries</Text>
              <Text className="text-xs leading-5 text-muted mt-1">
                Track ideas, model changes, observations, and follow-up work using Markdown. Playbook does not provide font selectors or rich-text formatting controls.
              </Text>
            </View>
          </View>
        </View>

        {!apiConfigured ? (
          <View className="bg-warning/10 border border-warning/25 rounded-[22px] p-4">
            <Text className="text-sm font-black text-warning">Connect the MPIE API to use Playbook</Text>
            <Text className="text-xs leading-5 text-muted mt-2">
              Set EXPO_PUBLIC_MPIE_API_URL and start FastAPI. Saved entries are stored per user in the MPIE state database.
            </Text>
          </View>
        ) : (
          <>
            <View className="flex-row items-center bg-surface border border-border rounded-2xl px-4 mb-4">
              <MaterialCommunityIcons name="magnify" size={21} color={colors.muted} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder="Search Playbook"
                placeholderTextColor={colors.muted}
                className="flex-1 py-3.5 px-3 text-foreground"
                autoCapitalize="none"
              />
              {query ? (
                <Pressable onPress={() => setQuery("")} hitSlop={8} accessibilityLabel="Clear Playbook search">
                  <MaterialCommunityIcons name="close-circle" size={19} color={colors.muted} />
                </Pressable>
              ) : null}
            </View>

            {playbookQuery.isLoading ? (
              <View className="bg-surface border border-border rounded-[22px] p-5">
                <Text className="text-sm font-bold text-muted">Loading Playbook…</Text>
              </View>
            ) : playbookQuery.isError ? (
              <View className="bg-error/10 border border-error/25 rounded-[22px] p-4">
                <Text className="text-sm font-black text-error">Playbook could not be loaded</Text>
                <Text className="text-xs leading-5 text-muted mt-2">
                  {playbookQuery.error instanceof Error
                    ? playbookQuery.error.message
                    : "Unknown Playbook API error."}
                </Text>
                <Pressable
                  onPress={() => void playbookQuery.refetch()}
                  className="self-start bg-error/10 border border-error/30 rounded-xl px-4 py-2.5 mt-3"
                >
                  <Text className="text-xs font-black text-error">Retry</Text>
                </Pressable>
              </View>
            ) : filteredEntries.length ? (
              filteredEntries.map((entry) => (
                <Pressable
                  key={entry.id}
                  onPress={() => void openExistingEntry(entry)}
                  className="bg-surface border border-border rounded-[22px] p-4 mb-3 active:opacity-90"
                  accessibilityRole="button"
                  accessibilityLabel={`Open Playbook entry ${entry.title}`}
                >
                  <View className="flex-row items-start justify-between">
                    <View className="flex-1 pr-3">
                      <Text className="text-base font-black text-foreground" numberOfLines={1}>
                        {entry.title}
                      </Text>
                      <Text className="text-sm leading-5 text-muted mt-2" numberOfLines={3}>
                        {markdownExcerpt(entry.bodyMarkdown) || "Empty Markdown entry"}
                      </Text>
                    </View>
                    <MaterialCommunityIcons name="chevron-right" size={22} color={colors.muted} />
                  </View>
                  <View className="flex-row items-center mt-3 pt-3 border-t border-border">
                    <MaterialCommunityIcons name="clock-outline" size={14} color={colors.muted} />
                    <Text className="text-[11px] font-bold text-muted ml-1.5">
                      Updated {formatUpdatedAt(entry.updatedAt)}
                    </Text>
                  </View>
                </Pressable>
              ))
            ) : (
              <View className="bg-surface border border-border rounded-[24px] px-5 py-10 items-center">
                <View className="h-14 w-14 rounded-2xl bg-primary/10 items-center justify-center">
                  <MaterialCommunityIcons name="book-open-page-variant-outline" size={28} color={colors.primary} />
                </View>
                <Text className="text-base font-black text-foreground mt-4">
                  {query ? "No matching entries" : "Your Playbook is empty"}
                </Text>
                <Text className="text-xs leading-5 text-muted text-center mt-2 max-w-[300px]">
                  {query
                    ? "Try another search phrase."
                    : "Create a Markdown entry to record ideas, model changes, observations, and next actions."}
                </Text>
                {!query ? (
                  <Pressable onPress={() => void openNewEntry()} className="bg-primary rounded-xl px-5 py-3 mt-5">
                    <Text className="text-xs font-black text-[#071019]">Create entry</Text>
                  </Pressable>
                ) : null}
              </View>
            )}
          </>
        )}
      </ScrollView>

      <Modal visible={editorOpen} animationType="slide" onRequestClose={closeEditor}>
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
          <KeyboardAvoidingView
            style={{ flex: 1 }}
            behavior={Platform.OS === "ios" ? "padding" : undefined}
          >
            <View className="flex-row items-center px-4 py-3 border-b border-border bg-surface">
              <Pressable
                onPress={closeEditor}
                className="h-11 w-11 rounded-xl items-center justify-center"
                accessibilityLabel="Close Playbook editor"
              >
                <MaterialCommunityIcons name="close" size={24} color={colors.foreground} />
              </Pressable>
              <View className="flex-1 px-2">
                <Text className="text-base font-black text-foreground">
                  {editingId ? "Edit Playbook entry" : "New Playbook entry"}
                </Text>
                <Text className="text-[11px] font-bold text-primary uppercase tracking-wider">
                  Markdown only
                </Text>
              </View>
              <Pressable
                onPress={() => void saveCurrentEntry()}
                disabled={saveMutation.isPending || deleteMutation.isPending}
                className="bg-primary rounded-xl px-4 py-3 disabled:opacity-50"
                accessibilityLabel="Save Playbook entry"
              >
                <Text className="text-xs font-black text-[#071019]">
                  {saveMutation.isPending ? "Saving…" : "Save"}
                </Text>
              </Pressable>
            </View>

            <View className="px-4 pt-4 bg-background">
              <TextInput
                value={title}
                onChangeText={(value) => {
                  setTitle(value);
                  setDirty(true);
                }}
                placeholder="Entry title"
                placeholderTextColor={colors.muted}
                maxLength={160}
                className="bg-surface border border-border rounded-2xl px-4 py-3.5 text-base font-black text-foreground"
              />

              <View className="flex-row mt-3 bg-surface border border-border rounded-xl p-1">
                {(["write", "preview"] as const).map((mode) => {
                  const active = editorMode === mode;
                  return (
                    <Pressable
                      key={mode}
                      onPress={() => setEditorMode(mode)}
                      className={`flex-1 py-2.5 rounded-lg items-center ${active ? "bg-primary" : "bg-transparent"}`}
                    >
                      <Text className={`text-xs font-black ${active ? "text-[#071019]" : "text-muted"}`}>
                        {mode === "write" ? "Write" : "Preview"}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <Text className="text-[11px] leading-4 text-muted mt-2 mb-3">
                Markdown syntax: # heading · **bold** · *italic* · - list · - [ ] task · &gt; quote · ``` code
              </Text>
            </View>

            {editorMode === "write" ? (
              <TextInput
                value={bodyMarkdown}
                onChangeText={(value) => {
                  setBodyMarkdown(value);
                  setDirty(true);
                }}
                placeholder="# Start writing in Markdown"
                placeholderTextColor={colors.muted}
                multiline
                textAlignVertical="top"
                maxLength={100_000}
                autoCapitalize="sentences"
                autoCorrect
                style={{
                  flex: 1,
                  marginHorizontal: 16,
                  marginBottom: 12,
                  padding: 16,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 18,
                  backgroundColor: colors.surface,
                  color: colors.foreground,
                  fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
                  fontSize: 15,
                  lineHeight: 23,
                }}
              />
            ) : (
              <ScrollView
                className="flex-1 mx-4 mb-3 bg-surface border border-border rounded-[18px]"
                contentContainerStyle={{ padding: 16 }}
                keyboardShouldPersistTaps="handled"
              >
                <MarkdownPreview markdown={bodyMarkdown} />
              </ScrollView>
            )}

            <View className="px-4 pb-3">
              {draftStatusText ? (
                <Text className={`text-[11px] font-bold mb-2 ${draftStatus === "error" ? "text-error" : "text-muted"}`}>
                  {draftStatusText}
                </Text>
              ) : null}
              {editorError ? <Text className="text-xs font-bold text-error mb-2">{editorError}</Text> : null}
              <View className="flex-row items-center justify-between">
                <Text className="text-[11px] text-muted">
                  {bodyMarkdown.length.toLocaleString()} / 100,000 characters
                </Text>
                {editingId ? (
                  <Pressable
                    onPress={requestDelete}
                    disabled={deleteMutation.isPending || saveMutation.isPending}
                    className="flex-row items-center px-3 py-2"
                    accessibilityLabel="Delete Playbook entry"
                  >
                    <MaterialCommunityIcons name="trash-can-outline" size={17} color={colors.error} />
                    <Text className="text-xs font-black text-error ml-1.5">
                      {deleteMutation.isPending ? "Deleting…" : "Delete"}
                    </Text>
                  </Pressable>
                ) : null}
              </View>
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </ScreenContainer>
  );
}
