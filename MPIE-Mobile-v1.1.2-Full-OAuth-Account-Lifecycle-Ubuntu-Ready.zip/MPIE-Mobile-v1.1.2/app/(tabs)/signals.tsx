import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { ScrollView, Text, View } from "react-native";

import { AppHeader, IconButton, ProgressBar } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMpieData } from "@/lib/mpie-data-provider";

export default function SignalsScreen() {
  const colors = useColors();
  const { signals, source, isRefreshing, refresh } = useMpieData();
  const systemPressure = signals.length
    ? signals.reduce((sum, signal) => sum + signal.strength, 0) / signals.length * 100
    : 0;

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="pt-2">
          <AppHeader eyebrow="Explainable intelligence" title="Pressure signals" right={<IconButton icon={isRefreshing ? "sync" : "refresh"} onPress={() => void refresh()} accessibilityLabel="Refresh signals" active={source === "api"} />} />
        </View>

        <View className="bg-[#0B1723] border border-[#1D3A4D] rounded-[26px] p-5 mb-5">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-[11px] uppercase tracking-[2px] font-bold text-[#8EA1B4]">System pressure index</Text>
              <Text className="text-[36px] font-black text-white mt-1">{systemPressure.toFixed(1)}</Text>
            </View>
            <View className="h-16 w-16 rounded-full border-[6px] border-[#4DE3FF] items-center justify-center">
              <MaterialCommunityIcons name="waveform" size={24} color="#9DFF4F" />
            </View>
          </View>
          <Text className="text-xs leading-5 text-[#8EA1B4] mt-4">
            {source === "api" ? "Live pressure intelligence from the MPIE backend." : "Demonstration pressure intelligence is active until the API is configured."}
          </Text>
        </View>

        {signals.map((signal) => (
          <View key={signal.id} className="bg-surface border border-border rounded-[22px] p-4 mb-3">
            <View className="flex-row items-start justify-between mb-3">
              <View className="flex-row flex-1 pr-4">
                <View className={`h-11 w-11 rounded-2xl items-center justify-center mr-3 ${signal.direction === "positive" ? "bg-success/10" : "bg-error/10"}`}>
                  <MaterialCommunityIcons
                    name={signal.direction === "positive" ? "trending-up" : "trending-down"}
                    size={23}
                    color={signal.direction === "positive" ? colors.success : colors.error}
                  />
                </View>
                <View className="flex-1">
                  <Text className="text-[15px] font-black text-foreground">{signal.title}</Text>
                  <Text className="text-xs font-bold text-muted mt-1">{signal.subtitle}</Text>
                </View>
              </View>
              <Text className={`text-lg font-black ${signal.direction === "positive" ? "text-success" : "text-error"}`}>{signal.value}</Text>
            </View>
            <ProgressBar value={signal.strength} tone={signal.direction === "positive" ? "success" : "warning"} />
            <View className="flex-row justify-between mt-2">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-muted">Signal strength</Text>
              <Text className="text-[10px] font-black text-muted">{Math.round(signal.strength * 100)}%</Text>
            </View>
            <Text className="text-xs leading-5 text-muted mt-3">{signal.detail}</Text>
          </View>
        ))}

        <View className="bg-primary/10 border border-primary/25 rounded-[22px] p-4 mt-2">
          <View className="flex-row items-center mb-2">
            <MaterialCommunityIcons name="shield-check-outline" size={20} color={colors.primary} />
            <Text className="text-sm font-black text-foreground ml-2">Why MPIE shows its work</Text>
          </View>
          <Text className="text-xs leading-5 text-muted">
            Each recommendation separates baseline probability, pressure adjustment, market price, and model confidence so users can audit the decision path.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
