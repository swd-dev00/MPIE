import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";

import { AppHeader, SettingRow } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getStoredJwt, signOut } from "@/lib/mpie-auth";
import { useMpieData } from "@/lib/mpie-data-provider";
import { useMpieStore } from "@/lib/mpie-store";
import { useThemeContext } from "@/lib/theme-provider";

const riskProfiles = ["Conservative", "Balanced", "Aggressive"] as const;
const API_URL = process.env.EXPO_PUBLIC_MPIE_API_URL ?? "http://localhost:8000";

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function DeleteAccountModal({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [phrase, setPhrase] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canConfirm = phrase.trim() === "DELETE";

  const close = () => {
    if (busy) return;
    setPhrase("");
    setError(null);
    onClose();
  };

  const submit = async () => {
    if (!canConfirm || busy) return;
    setBusy(true);
    setError(null);

    try {
      const jwt = await getStoredJwt();
      if (!jwt) throw new Error("Sign in before deleting an MPIE account.");

      const response = await fetch(`${API_URL}/api/v1/auth/me`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${jwt}` },
      });

      if (response.status !== 204) {
        let detail = `Server returned ${response.status}.`;
        try {
          const payload = (await response.json()) as { detail?: string };
          if (payload.detail) detail = payload.detail;
        } catch {
          // The status code remains actionable when the response is not JSON.
        }
        throw new Error(detail);
      }

      await signOut({ notifyServer: false });
      setPhrase("");
      setBusy(false);
      onClose();
      router.replace("/(auth)/login");
    } catch (caught) {
      setError(errorMessage(caught));
      setBusy(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={close}
    >
      <View style={styles.modalScrim}>
        <View style={styles.modalCard} accessibilityViewIsModal>
          <Text style={styles.modalTitle}>Delete account</Text>
          <Text style={styles.modalBody}>
            This permanently removes your MPIE account, active sessions, Playbook entries,
            portfolio positions, and watchlist. Any retained audit records are de-identified
            according to the configured retention policy. This cannot be undone.
          </Text>
          <Text style={styles.modalPrompt}>
            Type <Text style={styles.modalPromptBold}>DELETE</Text> to confirm:
          </Text>
          <TextInput
            style={styles.input}
            value={phrase}
            onChangeText={setPhrase}
            autoCapitalize="characters"
            autoCorrect={false}
            spellCheck={false}
            editable={!busy}
            placeholder="DELETE"
            placeholderTextColor="#4A5568"
            accessibilityLabel="Type DELETE to confirm account deletion"
          />
          {error ? <Text style={styles.modalError}>{error}</Text> : null}
          <View style={styles.modalActions}>
            <Pressable style={styles.btnCancel} onPress={close} disabled={busy}>
              <Text style={styles.btnCancelText}>Cancel</Text>
            </Pressable>
            <Pressable
              style={[styles.btnDestructive, !canConfirm && styles.btnDisabled]}
              onPress={submit}
              disabled={!canConfirm || busy}
              accessibilityLabel="Confirm delete account"
            >
              {busy ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={styles.btnDestructiveText}>Delete permanently</Text>
              )}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { colorScheme, setColorScheme } = useThemeContext();
  const { source, sourceLabel, backendMode, errorMessage: dataError, refresh } = useMpieData();
  const {
    bankroll,
    setBankroll,
    riskProfile,
    setRiskProfile,
    notificationsEnabled,
    setNotificationsEnabled,
    watchlistPendingCount,
    watchlistSyncError,
    retryWatchlistSync,
  } = useMpieStore();
  const [bankrollDraft, setBankrollDraft] = useState(String(bankroll));
  const [deleteVisible, setDeleteVisible] = useState(false);

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="pt-2">
          <AppHeader eyebrow="Control center" title="Settings" />
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-5">
          <View className="flex-row items-center">
            <View className="h-14 w-14 rounded-2xl bg-primary/10 items-center justify-center">
              <Text className="text-xl font-black text-primary">SW</Text>
            </View>
            <View className="ml-4 flex-1">
              <Text className="text-base font-black text-foreground">Sierra Warren</Text>
              <Text className="text-xs text-muted mt-1">Founder workspace · {sourceLabel}</Text>
            </View>
            <MaterialCommunityIcons name="shield-check" size={22} color={colors.success} />
          </View>
        </View>

        <Text className="text-xs uppercase tracking-[1.6px] font-black text-muted mb-2">Portfolio controls</Text>
        <View className="bg-surface border border-border rounded-[22px] px-4 mb-5">
          <View className="py-4 border-b border-border">
            <Text className="text-sm font-black text-foreground">Tracked bankroll</Text>
            <Text className="text-xs text-muted mt-1">Used only for local demonstration calculations.</Text>
            <View className="flex-row items-center mt-3 bg-background border border-border rounded-2xl px-3">
              <Text className="text-base font-black text-foreground">$</Text>
              <TextInput
                value={bankrollDraft}
                onChangeText={setBankrollDraft}
                onEndEditing={() => {
                  const parsed = Number(bankrollDraft.replace(/[^0-9.]/g, ""));
                  if (Number.isFinite(parsed) && parsed > 0) setBankroll(parsed);
                  else setBankrollDraft(String(bankroll));
                }}
                keyboardType="decimal-pad"
                className="flex-1 py-3 px-2 text-foreground font-bold"
                placeholderTextColor={colors.muted}
              />
            </View>
          </View>

          <View className="py-4">
            <Text className="text-sm font-black text-foreground">Risk profile</Text>
            <View className="flex-row gap-2 mt-3">
              {riskProfiles.map((profile) => {
                const active = profile === riskProfile;
                return (
                  <Pressable
                    key={profile}
                    onPress={() => setRiskProfile(profile)}
                    className={`flex-1 py-2.5 rounded-xl border items-center ${active ? "bg-primary border-primary" : "bg-background border-border"}`}
                  >
                    <Text className={`text-[10px] font-black ${active ? "text-[#071019]" : "text-muted"}`}>{profile}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>

        <Text className="text-xs uppercase tracking-[1.6px] font-black text-muted mb-2">App preferences</Text>
        <View className="bg-surface border border-border rounded-[22px] px-4 mb-5">
          <SettingRow
            icon="bell-outline"
            title="Signal alerts"
            subtitle="Pressure and edge threshold updates"
            right={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colorScheme === "dark" ? colors.foreground : colors.surface}
              />
            }
          />
          <SettingRow
            icon="theme-light-dark"
            title="Appearance"
            subtitle={colorScheme === "dark" ? "Dark mode" : "Light mode"}
            right={
              <Switch
                value={colorScheme === "dark"}
                onValueChange={(value) => setColorScheme(value ? "dark" : "light")}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colorScheme === "dark" ? colors.foreground : colors.surface}
              />
            }
          />
          <SettingRow
            icon="database-outline"
            title="Data source"
            subtitle={dataError ? `${sourceLabel} · ${dataError}` : sourceLabel}
            onPress={() => router.push("/data-source")}
          />
          <SettingRow
            icon="cloud-sync-outline"
            title="Watchlist sync"
            subtitle={
              watchlistSyncError
                ? `${watchlistPendingCount} pending · ${watchlistSyncError}`
                : watchlistPendingCount
                  ? `${watchlistPendingCount} change${watchlistPendingCount === 1 ? "" : "s"} pending`
                  : "Local and remote watchlists synchronized"
            }
            onPress={() => router.push("/watchlist-sync")}
          />
        </View>

        <Text className="text-xs uppercase tracking-[1.6px] font-black text-muted mb-2">Product</Text>
        <View className="bg-surface border border-border rounded-[22px] px-4 mb-5">
          <SettingRow
            icon="information-outline"
            title="About MPIE"
            subtitle="Market Pressure Intelligence Engine"
            onPress={() => router.push("/about")}
          />
          <SettingRow
            icon="file-document-outline"
            title="Methodology"
            subtitle="Probability, pressure, and market-price calculations"
            onPress={() => router.push("/methodology")}
          />
          <SettingRow
            icon="database-search-outline"
            title="Data provenance"
            subtitle={backendMode === "clickhouse" ? "ClickHouse live · inspect sources" : backendMode === "demo" ? "API demo · inspect sources" : "Inspect source and model lineage"}
            onPress={() => router.push("/data-provenance")}
          />
          <SettingRow
            icon="lock-outline"
            title="Privacy"
            subtitle="Device, API, SQLite, and ClickHouse data handling"
            onPress={() => router.push("/privacy")}
          />
        </View>

        <Text className="text-xs uppercase tracking-[1.6px] font-black text-muted mb-2">Account</Text>
        <View className="bg-surface border border-border rounded-[22px] overflow-hidden mb-5">
          <Pressable style={styles.destructiveRow} onPress={() => setDeleteVisible(true)}>
            <MaterialCommunityIcons name="account-remove-outline" size={21} color="#FF6B6B" />
            <View style={styles.destructiveCopy}>
              <Text style={styles.destructiveText}>Delete account</Text>
              <Text style={styles.destructiveSubtitle}>Permanently remove the signed-in MPIE account</Text>
            </View>
          </Pressable>
        </View>

        <View className="bg-warning/10 border border-warning/25 rounded-[22px] p-4">
          <Text className="text-xs font-black text-warning uppercase tracking-wider">Demonstration disclaimer</Text>
          <Text className="text-xs leading-5 text-muted mt-2">
            {source === "api" ? `${sourceLabel}. No live wagering integration is included.` : "This frontend is using demonstration fallback data because the MPIE API is not configured or reachable."} MPIE analytics are informational and do not guarantee outcomes or financial returns.
          </Text>
        </View>

        <Text className="text-[11px] text-muted text-center mt-6">MPIE Mobile 1.1.2 · Sierra Warren Developments, LLC</Text>
      </ScrollView>
      <DeleteAccountModal visible={deleteVisible} onClose={() => setDeleteVisible(false)} />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  destructiveRow: {
    minHeight: 68,
    paddingVertical: 16,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  destructiveCopy: { flex: 1, marginLeft: 12 },
  destructiveText: { color: "#FF6B6B", fontSize: 16, fontWeight: "600" },
  destructiveSubtitle: { color: "#7E8997", fontSize: 12, marginTop: 3 },
  modalScrim: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.75)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    backgroundColor: "#111820",
    borderRadius: 12,
    padding: 24,
    width: "100%",
    maxWidth: 400,
  },
  modalTitle: { color: "white", fontSize: 20, fontWeight: "700", marginBottom: 12 },
  modalBody: { color: "#B8C1CC", fontSize: 14, lineHeight: 20, marginBottom: 16 },
  modalPrompt: { color: "#B8C1CC", fontSize: 14, marginBottom: 8 },
  modalPromptBold: { color: "white", fontWeight: "700", fontFamily: "monospace" },
  input: {
    backgroundColor: "#0B0F14",
    borderColor: "#2A2F36",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: "white",
    fontFamily: "monospace",
    fontSize: 16,
    letterSpacing: 2,
  },
  modalError: { color: "#FF6B6B", fontSize: 13, marginTop: 8 },
  modalActions: { flexDirection: "row", gap: 12, marginTop: 20, justifyContent: "flex-end" },
  btnCancel: { paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8 },
  btnCancelText: { color: "#B8C1CC", fontSize: 15 },
  btnDestructive: {
    backgroundColor: "#DC3545",
    minWidth: 154,
    minHeight: 42,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  btnDisabled: { backgroundColor: "#4A2A2A" },
  btnDestructiveText: { color: "white", fontSize: 15, fontWeight: "600" },
});
