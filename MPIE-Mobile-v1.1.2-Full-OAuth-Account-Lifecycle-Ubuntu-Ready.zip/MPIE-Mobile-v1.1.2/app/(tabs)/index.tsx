import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { BrandMark } from "@/components/mpie/brand-mark";
import { GameCard, IconButton, MetricTile, ProgressBar, SectionHeader } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import { formatPercent } from "@/constants/mpie-data";
import { useColors } from "@/hooks/use-colors";
import { useMpieData } from "@/lib/mpie-data-provider";
import { useMpieStore } from "@/lib/mpie-store";

export default function OverviewScreen() {
  const colors = useColors();
  const { bankroll } = useMpieStore();
  const { games, source, sourceLabel, backendMode, isRefreshing, errorMessage, refresh } = useMpieData();
  const featured = games[0];
  const liveGame = games.find((game) => game.status === "LIVE");
  const averageEdge = games.length
    ? games.slice(0, 5).reduce((sum, game) => sum + game.edge, 0) / Math.min(5, games.length)
    : 0;

  if (!featured) {
    return (
      <ScreenContainer className="px-5 items-center justify-center">
        <Text className="text-xl font-black text-foreground">No market data available</Text>
        <Pressable onPress={() => void refresh()} className="mt-4 bg-primary px-5 py-3 rounded-2xl">
          <Text className="text-[#071019] font-black">Retry feed</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="flex-row items-center justify-between pt-2 mb-6">
          <View className="flex-row items-center">
            <BrandMark size={43} />
            <View className="ml-3">
              <Text className="text-xl font-black tracking-[2px] text-foreground">MPIE</Text>
              <Text className="text-[10px] font-bold uppercase tracking-[1.4px] text-muted">Market Pressure Intelligence</Text>
            </View>
          </View>
          <IconButton icon={isRefreshing ? "sync" : "refresh"} onPress={() => void refresh()} accessibilityLabel="Refresh MPIE feed" active={source === "api"} />
        </View>

        <View className="mb-5">
          <Text className="text-[12px] uppercase tracking-[2px] font-bold text-primary">Decision terminal</Text>
          <Text className="text-[30px] leading-9 font-black text-foreground mt-1">Pressure, priced.</Text>
          <Text className="text-sm leading-5 text-muted mt-2 max-w-[330px]">
            Convert schedule stress, market movement, and performance context into auditable game intelligence.
          </Text>
        </View>

        <View className="bg-[#0B1723] border border-[#1D3A4D] rounded-[28px] p-5 mb-5 overflow-hidden">
          <View className="absolute -right-10 -top-12 w-40 h-40 rounded-full bg-primary/10" />
          <View className="absolute -right-3 bottom-[-54px] w-32 h-32 rounded-full bg-success/10" />
          <View className="flex-row items-start justify-between">
            <View>
              <Text className="text-[11px] uppercase tracking-[2px] font-bold text-[#8EA1B4]">Top pressure position</Text>
              <Text className="text-2xl font-black text-white mt-2">{featured.pick}</Text>
              <Text className="text-xs text-[#8EA1B4] mt-1">{featured.away.abbreviation} @ {featured.home.abbreviation} · {featured.market}</Text>
            </View>
            <View className="bg-[#102536] rounded-2xl px-3 py-2 items-end">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Edge</Text>
              <Text className="text-xl font-black text-[#9DFF4F]">+{formatPercent(featured.edge)}</Text>
            </View>
          </View>

          <View className="mt-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-xs font-bold text-white">Model confidence</Text>
              <Text className="text-xs font-black text-[#4DE3FF]">{formatPercent(featured.confidence, 0)}</Text>
            </View>
            <View className="h-2.5 bg-[#1D3142] rounded-full overflow-hidden">
              <View className="h-full bg-[#4DE3FF] rounded-full" style={{ width: `${featured.confidence * 100}%` }} />
            </View>
          </View>

          <Pressable
            onPress={() => router.push({ pathname: "/game/[id]", params: { id: featured.id } })}
            className="mt-5 bg-[#4DE3FF] rounded-2xl py-3.5 items-center active:opacity-85"
          >
            <Text className="text-[#071019] font-black">Open full analysis</Text>
          </Pressable>
        </View>

        <View className="flex-row gap-3 mb-6">
          <MetricTile label="Bankroll" value={`$${bankroll.toLocaleString()}`} detail="Demo portfolio" />
          <MetricTile label="Avg. edge" value={formatPercent(averageEdge)} detail="Top 5 positions" />
          <MetricTile
            label="Feed"
            value={backendMode === "clickhouse" ? "Live" : source === "api" ? "API demo" : "Demo"}
            detail={sourceLabel}
          />
        </View>

        {liveGame ? (
          <View className="bg-surface border border-border rounded-[22px] p-4 mb-6">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-row items-center">
                <View className="h-9 w-9 rounded-xl bg-error/10 items-center justify-center mr-3">
                  <MaterialCommunityIcons name="access-point" size={20} color={colors.error} />
                </View>
                <View>
                  <Text className="text-sm font-black text-foreground">Live pressure shift</Text>
                  <Text className="text-xs text-muted mt-0.5">{liveGame.away.abbreviation} @ {liveGame.home.abbreviation}</Text>
                </View>
              </View>
              <Text className="text-xs font-black text-success">+{formatPercent(liveGame.edge)}</Text>
            </View>
            <ProgressBar value={liveGame.confidence} />
            <Text className="text-xs leading-5 text-muted mt-3">Rotation load widened the model edge by 1.4 points since tipoff.</Text>
          </View>
        ) : null}

        <SectionHeader title="Priority board" action="View all" onPress={() => router.push("/markets")} />
        {games.slice(0, 3).map((game) => <GameCard key={game.id} game={game} />)}

        <View className="bg-warning/10 border border-warning/25 rounded-2xl p-4 mt-2">
          <Text className="text-xs font-black text-warning uppercase tracking-wider">Model-use notice</Text>
          <Text className="text-xs leading-5 text-muted mt-2">
            MPIE surfaces analytical signals, not guaranteed outcomes. {sourceLabel}.
          </Text>
          {errorMessage ? <Text className="text-[11px] leading-4 text-error mt-2">{errorMessage}</Text> : null}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
