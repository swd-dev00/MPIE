import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { ScrollView, Text, View } from "react-native";

import { AppHeader, GameCard, MetricTile, SectionHeader } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMpieData } from "@/lib/mpie-data-provider";
import { useMpieStore } from "@/lib/mpie-store";

export default function PortfolioScreen() {
  const colors = useColors();
  const { bankroll, savedGameIds } = useMpieStore();
  const { games, portfolioPositions } = useMpieData();
  const savedGames = games.filter((game) => savedGameIds.includes(game.id));
  const openRisk = portfolioPositions
    .filter((position) => !["Won", "Lost", "Settled"].includes(position.status))
    .reduce((sum, position) => sum + position.stake, 0);
  const demoPnl = portfolioPositions.reduce((sum, position) => sum + position.pnl, 0);

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <View className="pt-2">
          <AppHeader eyebrow="Risk workspace" title="Portfolio" />
        </View>

        <View className="bg-[#0B1723] border border-[#1D3A4D] rounded-[26px] p-5 mb-5">
          <Text className="text-[11px] uppercase tracking-[2px] font-bold text-[#8EA1B4]">Tracked bankroll</Text>
          <Text className="text-[38px] font-black text-white mt-1">${bankroll.toLocaleString()}</Text>
          <View className="flex-row mt-5 gap-3">
            <View className="flex-1 bg-[#102536] rounded-2xl p-3">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Open risk</Text>
              <Text className="text-xl font-black text-white mt-1">${openRisk.toFixed(0)}</Text>
            </View>
            <View className="flex-1 bg-[#102536] rounded-2xl p-3">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Demo P/L</Text>
              <Text className="text-xl font-black text-[#9DFF4F] mt-1">{demoPnl >= 0 ? "+" : ""}${demoPnl.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        <View className="flex-row gap-3 mb-6">
          <MetricTile label="Exposure" value={`${bankroll > 0 ? (openRisk / bankroll * 100).toFixed(1) : "0.0"}%`} detail="Tracked risk" />
          <MetricTile label="Positions" value={`${portfolioPositions.length}`} detail={`${portfolioPositions.filter((position) => position.status === "Live").length} live`} />
          <MetricTile label="Watchlist" value={`${savedGames.length}`} detail="Saved games" />
        </View>

        <SectionHeader title="Positions" />
        <View className="bg-surface border border-border rounded-[22px] px-4 mb-6">
          {portfolioPositions.map((position, index) => (
            <View key={position.id} className={`py-4 ${index < portfolioPositions.length - 1 ? "border-b border-border" : ""}`}>
              <View className="flex-row items-center justify-between">
                <View className="flex-1">
                  <Text className="text-sm font-black text-foreground">{position.label}</Text>
                  <Text className="text-xs text-muted mt-1">
                    {position.game} · {position.odds.toFixed(2)}
                    {position.bookmakerTitle ? ` · ${position.bookmakerTitle}` : ""}
                  </Text>
                </View>
                <View className="items-end">
                  <Text className="text-sm font-black text-foreground">${position.stake.toFixed(2)}</Text>
                  <Text className={`text-[11px] font-bold mt-1 ${position.status === "Won" || position.pnl > 0 ? "text-success" : "text-muted"}`}>
                    {position.status}{position.pnl ? ` · +$${position.pnl.toFixed(2)}` : ""}
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>

        <SectionHeader title="Watchlist" action="Browse" onPress={() => router.push("/markets")} />
        {savedGames.length ? (
          savedGames.map((game) => <GameCard key={game.id} game={game} compact />)
        ) : (
          <View className="bg-surface border border-border rounded-[22px] p-7 items-center">
            <MaterialCommunityIcons name="bookmark-outline" size={28} color={colors.muted} />
            <Text className="text-sm font-black text-foreground mt-3">No saved games</Text>
            <Text className="text-xs text-muted text-center mt-1">Bookmark a market position to keep it here.</Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
