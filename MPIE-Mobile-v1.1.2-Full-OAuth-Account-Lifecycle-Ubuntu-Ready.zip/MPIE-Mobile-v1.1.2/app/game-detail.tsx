import { Redirect, useLocalSearchParams } from "expo-router";

export default function LegacyGameDetailRoute() {
  const { gameId } = useLocalSearchParams<{ gameId?: string }>();
  return <Redirect href={{ pathname: "/game/[id]", params: { id: gameId ?? "bos-ny-0710" } }} />;
}
