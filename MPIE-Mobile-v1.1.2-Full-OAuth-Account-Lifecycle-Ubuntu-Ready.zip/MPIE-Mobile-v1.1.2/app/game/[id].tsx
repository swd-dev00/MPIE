import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useQuery } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ProgressBar, StatusPill } from "@/components/mpie/ui";
import { ScreenContainer } from "@/components/screen-container";
import {
  formatGameDate,
  formatGameTime,
  formatPercent,
  type BookmakerQuote,
} from "@/constants/mpie-data";
import { useColors } from "@/hooks/use-colors";
import { createRemotePosition, loadMarketPrices } from "@/lib/mpie-api";
import { useMpieData } from "@/lib/mpie-data-provider";
import { useMpieStore } from "@/lib/mpie-store";

function quoteStatusClasses(status: BookmakerQuote["status"]) {
  if (status === "ACTIVE") return "bg-success/10 text-success";
  if (status === "STALE") return "bg-warning/10 text-warning";
  return "bg-error/10 text-error";
}

function formatQuoteTime(value: string) {
  const timestamp = new Date(value);
  if (Number.isNaN(timestamp.getTime())) return "Update time unavailable";
  return `Updated ${timestamp.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  })}`;
}

export default function GameDetailScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  const { backendMode, findGameById, refresh } = useMpieData();
  const game = findGameById(params.id);
  const marketKey = game?.marketKey || "";
  const outcome = game?.outcome || game?.pick || "";
  const [isTracking, setIsTracking] = useState(false);
  const [trackingMessage, setTrackingMessage] = useState<string | null>(null);
  const [selectedBookmakerKey, setSelectedBookmakerKey] = useState<string>();
  const colors = useColors();
  const { bankroll, savedGameIds, toggleSavedGame, riskProfile } = useMpieStore();

  const priceQuery = useQuery({
    queryKey: ["mpie", "market-prices", game?.id, marketKey, outcome],
    queryFn: () => loadMarketPrices(game!.id, marketKey, outcome),
    enabled: Boolean(game && marketKey && outcome),
    staleTime: 15_000,
    refetchInterval: 30_000,
  });

  const priceBoard = priceQuery.data?.items ?? null;

  useEffect(() => {
    if (!priceBoard?.quotes.length) return;
    setSelectedBookmakerKey((current) => {
      const currentQuote = priceBoard.quotes.find(
        (quote) => quote.bookmakerKey === current && quote.status === "ACTIVE",
      );
      if (currentQuote) return current;
      return (
        priceBoard.quotes.find((quote) => quote.isBestPrice && quote.status === "ACTIVE")
          ?.bookmakerKey ?? priceBoard.quotes.find((quote) => quote.status === "ACTIVE")?.bookmakerKey
      );
    });
  }, [priceBoard]);

  if (!game) {
    return (
      <ScreenContainer className="px-5 items-center justify-center" edges={["top", "bottom", "left", "right"]}>
        <MaterialCommunityIcons name="alert-circle-outline" size={42} color={colors.muted} />
        <Text className="text-xl font-black text-foreground mt-4">Game not found</Text>
        <Pressable onPress={() => router.back()} className="mt-5 bg-primary px-5 py-3 rounded-2xl">
          <Text className="text-[#071019] font-black">Return to board</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  const selectedQuote =
    priceBoard?.quotes.find((quote) => quote.bookmakerKey === selectedBookmakerKey) ??
    priceBoard?.quotes.find((quote) => quote.isBestPrice) ??
    null;
  const selectedOdds = selectedQuote?.decimalOdds ?? game.decimalOdds;
  const selectedImpliedProbability = selectedQuote?.impliedProbability ?? game.impliedProbability;
  const isSaved = savedGameIds.includes(game.id);
  const riskMultiplier = riskProfile === "Conservative" ? 0.25 : riskProfile === "Aggressive" ? 0.75 : 0.5;
  const rawKelly = Math.max(0, (game.modelProbability * selectedOdds - 1) / (selectedOdds - 1));
  const suggestedStake = bankroll * rawKelly * riskMultiplier;
  const canTrack = selectedQuote?.status === "ACTIVE";

  const trackPosition = async () => {
    if (!selectedQuote || selectedQuote.status !== "ACTIVE") {
      setTrackingMessage("Select an active sportsbook price before tracking this position.");
      return;
    }

    setIsTracking(true);
    setTrackingMessage(null);
    try {
      const position = await createRemotePosition({
        eventId: game.id,
        marketKey,
        outcome,
        label: game.pick,
        game: `${game.away.abbreviation} @ ${game.home.abbreviation}`,
        entryPrice: selectedQuote.decimalOdds,
        sizeUnits: Math.max(1, Number(suggestedStake.toFixed(2))),
        bookmakerKey: selectedQuote.bookmakerKey,
        bookmakerTitle: selectedQuote.bookmakerTitle,
        status: game.status === "LIVE" ? "Live" : "Open",
      });
      if (!position) {
        setTrackingMessage("Connect the MPIE API to persist this tracked position.");
        return;
      }
      await refresh();
      setTrackingMessage(`Position tracked at ${selectedQuote.bookmakerTitle} ${selectedQuote.decimalOdds.toFixed(2)}.`);
    } catch (error) {
      setTrackingMessage(error instanceof Error ? error.message : "Unable to track this position.");
    } finally {
      setIsTracking(false);
    }
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View className="flex-row items-center justify-between pt-2 mb-5">
          <Pressable
            onPress={() => router.back()}
            className="h-11 w-11 rounded-2xl bg-surface border border-border items-center justify-center"
            accessibilityLabel="Go back"
          >
            <MaterialCommunityIcons name="arrow-left" size={22} color={colors.foreground} />
          </Pressable>
          <View className="items-center">
            <Text className="text-[10px] uppercase tracking-[2px] font-bold text-primary">Game intelligence</Text>
            <Text className="text-base font-black text-foreground mt-0.5">{game.away.abbreviation} @ {game.home.abbreviation}</Text>
          </View>
          <Pressable
            onPress={() => toggleSavedGame(game.id)}
            className={`h-11 w-11 rounded-2xl border items-center justify-center ${isSaved ? "bg-primary/10 border-primary/50" : "bg-surface border-border"}`}
            accessibilityLabel={isSaved ? "Remove from watchlist" : "Add to watchlist"}
          >
            <MaterialCommunityIcons name={isSaved ? "bookmark" : "bookmark-outline"} size={22} color={isSaved ? colors.primary : colors.foreground} />
          </Pressable>
        </View>

        <View className="bg-[#0B1723] border border-[#1D3A4D] rounded-[28px] p-5 mb-5">
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center gap-2">
              <StatusPill status={game.status} />
              <Text className="text-[11px] font-bold text-[#8EA1B4]">{game.league}</Text>
            </View>
            <Text className="text-[11px] font-bold text-[#8EA1B4]">{formatGameDate(game.startAt)} · {formatGameTime(game.startAt)}</Text>
          </View>

          <View className="flex-row items-center mt-7 mb-6">
            <View className="flex-1">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Away</Text>
              <Text className="text-[34px] font-black text-white mt-1">{game.away.abbreviation}</Text>
              <Text className="text-xs text-[#8EA1B4] mt-1">{game.away.city} · {game.away.record}</Text>
            </View>
            <View className="px-3 items-center">
              {game.status === "LIVE" ? (
                <Text className="text-2xl font-black text-[#4DE3FF]">{game.away.score}–{game.home.score}</Text>
              ) : (
                <Text className="text-sm font-black text-[#4DE3FF]">VS</Text>
              )}
            </View>
            <View className="flex-1 items-end">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Home</Text>
              <Text className="text-[34px] font-black text-white mt-1">{game.home.abbreviation}</Text>
              <Text className="text-xs text-[#8EA1B4] mt-1 text-right">{game.home.city} · {game.home.record}</Text>
            </View>
          </View>

          <View className="border-t border-[#1D3142] pt-4">
            <Text className="text-[10px] uppercase tracking-[1.6px] font-bold text-[#8EA1B4]">Model position</Text>
            <View className="flex-row items-end justify-between mt-1">
              <View className="flex-1 pr-4">
                <Text className="text-2xl font-black text-white">{game.pick}</Text>
                <Text className="text-xs text-[#8EA1B4] mt-1">
                  {game.market} · {selectedOdds.toFixed(2)} decimal
                </Text>
                <Text className="text-[11px] font-bold text-[#4DE3FF] mt-1">
                  {selectedQuote?.bookmakerTitle ?? game.bestBookmakerTitle ?? "Book unavailable"}
                  {selectedQuote?.isBestPrice ? " · Best price" : ""}
                </Text>
              </View>
              <View className="items-end">
                <Text className="text-[10px] uppercase tracking-wider font-bold text-[#8EA1B4]">Edge</Text>
                <Text className="text-2xl font-black text-[#9DFF4F]">+{formatPercent(game.edge)}</Text>
              </View>
            </View>
          </View>
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-4">
          <View className="flex-row items-start justify-between">
            <View className="flex-1 pr-4">
              <Text className="text-base font-black text-foreground">Sportsbook prices</Text>
              <Text className="text-xs text-muted mt-1">
                Select the executable price that will be saved with the tracked position.
              </Text>
            </View>
            <View className="items-end">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-muted">Consensus</Text>
              <Text className="text-lg font-black text-foreground">
                {priceBoard?.consensusDecimalOdds?.toFixed(2) ?? "—"}
              </Text>
            </View>
          </View>

          <View className="mt-4">
            {priceQuery.isFetching && !priceBoard ? (
              <Text className="text-xs text-muted">Loading bookmaker prices…</Text>
            ) : priceBoard?.quotes.length ? (
              priceBoard.quotes.map((quote, index) => {
                const selected = selectedQuote?.bookmakerKey === quote.bookmakerKey;
                const disabled = quote.status !== "ACTIVE";
                const statusClasses = quoteStatusClasses(quote.status).split(" ");
                return (
                  <Pressable
                    key={quote.bookmakerKey}
                    onPress={() => !disabled && setSelectedBookmakerKey(quote.bookmakerKey)}
                    disabled={disabled}
                    className={`py-3 ${index < priceBoard.quotes.length - 1 ? "border-b border-border" : ""} ${disabled ? "opacity-60" : ""}`}
                    accessibilityRole="radio"
                    accessibilityState={{ checked: selected, disabled }}
                    accessibilityLabel={`${quote.bookmakerTitle} ${quote.decimalOdds.toFixed(2)} ${quote.status}`}
                  >
                    <View className="flex-row items-center justify-between">
                      <View className="flex-row items-center flex-1 pr-3">
                        <View className={`h-9 w-9 rounded-xl items-center justify-center mr-3 ${selected ? "bg-primary/15" : "bg-background"}`}>
                          <MaterialCommunityIcons
                            name={selected ? "radiobox-marked" : "radiobox-blank"}
                            size={19}
                            color={selected ? colors.primary : colors.muted}
                          />
                        </View>
                        <View className="flex-1">
                          <View className="flex-row items-center flex-wrap">
                            <Text className="text-sm font-black text-foreground mr-2">{quote.bookmakerTitle}</Text>
                            {quote.isBestPrice ? (
                              <View className="bg-success/10 rounded-full px-2 py-1 mr-2">
                                <Text className="text-[9px] font-black uppercase tracking-wider text-success">Best price</Text>
                              </View>
                            ) : null}
                            <View className={`${statusClasses[0]} rounded-full px-2 py-1`}>
                              <Text className={`text-[9px] font-black uppercase tracking-wider ${statusClasses[1]}`}>
                                {quote.status}
                              </Text>
                            </View>
                          </View>
                          <Text className="text-[11px] text-muted mt-1">{formatQuoteTime(quote.lastUpdatedAt)}</Text>
                        </View>
                      </View>
                      <View className="items-end">
                        <Text className="text-lg font-black text-foreground">{quote.decimalOdds.toFixed(2)}</Text>
                        <Text className={`text-[11px] font-bold ${quote.differenceFromConsensusPct >= 0 ? "text-success" : "text-warning"}`}>
                          {quote.differenceFromConsensusPct >= 0 ? "+" : ""}
                          {quote.differenceFromConsensusPct.toFixed(1)}% vs consensus
                        </Text>
                      </View>
                    </View>
                  </Pressable>
                );
              })
            ) : (
              <View className="bg-warning/10 rounded-2xl p-3">
                <Text className="text-xs leading-5 text-muted">
                  No bookmaker comparison is available for this market. Tracking is disabled until an active price is returned.
                </Text>
              </View>
            )}
          </View>
          <Text className="text-[10px] text-muted mt-3">
            {priceQuery.data?.source !== "api"
              ? "Demonstration fallback price board."
              : backendMode === "clickhouse"
                ? "MPIE API · ClickHouse-backed bookmaker prices."
                : "MPIE API · Demonstration analytics."}
          </Text>
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-4">
          <Text className="text-base font-black text-foreground">Probability stack</Text>
          <Text className="text-xs text-muted mt-1">How the recommendation moves from baseline to market edge.</Text>

          <View className="mt-5">
            <View className="flex-row justify-between mb-2">
              <Text className="text-xs font-bold text-muted">Baseline probability</Text>
              <Text className="text-xs font-black text-foreground">{formatPercent(game.baselineProbability)}</Text>
            </View>
            <ProgressBar value={game.baselineProbability} />
          </View>

          <View className="mt-4">
            <View className="flex-row justify-between mb-2">
              <Text className="text-xs font-bold text-muted">Pressure adjusted</Text>
              <Text className="text-xs font-black text-primary">{formatPercent(game.modelProbability)}</Text>
            </View>
            <ProgressBar value={game.modelProbability} tone="success" />
          </View>

          <View className="mt-4">
            <View className="flex-row justify-between mb-2">
              <Text className="text-xs font-bold text-muted">Selected-book implied</Text>
              <Text className="text-xs font-black text-foreground">{formatPercent(selectedImpliedProbability)}</Text>
            </View>
            <ProgressBar value={selectedImpliedProbability} tone="warning" />
          </View>
        </View>

        <View className="flex-row gap-3 mb-4">
          <View className="flex-1 bg-surface border border-border rounded-[20px] p-4">
            <Text className="text-[10px] uppercase tracking-wider font-bold text-muted">Confidence</Text>
            <Text className="text-2xl font-black text-foreground mt-1">{formatPercent(game.confidence, 0)}</Text>
            <Text className="text-[11px] text-muted mt-1">Model certainty</Text>
          </View>
          <View className="flex-1 bg-surface border border-border rounded-[20px] p-4">
            <Text className="text-[10px] uppercase tracking-wider font-bold text-muted">Pressure index</Text>
            <Text className="text-2xl font-black text-foreground mt-1">{game.pressureIndex}</Text>
            <Text className="text-[11px] text-muted mt-1">0–100 scale</Text>
          </View>
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-4">
          <Text className="text-base font-black text-foreground">Pressure decomposition</Text>
          <Text className="text-xs text-muted mt-1 mb-4">Largest contributors to the probability adjustment.</Text>
          {game.factors.map((factor, index) => {
            const positive = factor.impact >= 0;
            return (
              <View key={factor.label} className={`py-3 ${index < game.factors.length - 1 ? "border-b border-border" : ""}`}>
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center flex-1 pr-4">
                    <View className={`h-9 w-9 rounded-xl items-center justify-center mr-3 ${positive ? "bg-success/10" : "bg-error/10"}`}>
                      <MaterialCommunityIcons name={positive ? "arrow-top-right" : "arrow-bottom-right"} size={18} color={positive ? colors.success : colors.error} />
                    </View>
                    <Text className="text-sm font-black text-foreground flex-1">{factor.label}</Text>
                  </View>
                  <Text className={`text-sm font-black ${positive ? "text-success" : "text-error"}`}>{positive ? "+" : ""}{formatPercent(factor.impact)}</Text>
                </View>
                <Text className="text-xs leading-5 text-muted mt-2 ml-12">{factor.detail}</Text>
              </View>
            );
          })}
        </View>

        <View className="bg-primary/10 border border-primary/25 rounded-[24px] p-4 mb-4">
          <View className="flex-row items-center mb-2">
            <MaterialCommunityIcons name="brain" size={21} color={colors.primary} />
            <Text className="text-sm font-black text-foreground ml-2">Model interpretation</Text>
          </View>
          <Text className="text-xs leading-5 text-muted">{game.insight}</Text>
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-4">
          <View className="flex-row items-center mb-3">
            <MaterialCommunityIcons name="shield-check" size={21} color={colors.primary} />
            <Text className="text-base font-black text-foreground ml-2">Model provenance</Text>
          </View>
          <View className="flex-row justify-between py-2 border-b border-border">
            <Text className="text-xs font-bold text-muted">Model version</Text>
            <Text className="text-xs font-black text-foreground">{game.modelVersion}</Text>
          </View>
          <View className="flex-row justify-between py-2">
            <Text className="text-xs font-bold text-muted">Calculated</Text>
            <Text className="text-xs font-black text-foreground text-right max-w-[60%]">
              {game.calculatedAt ? new Date(game.calculatedAt).toLocaleString() : "Timestamp unavailable"}
            </Text>
          </View>
          <Text className="text-[11px] leading-4 text-muted mt-2">
            Provenance identifies which model release produced this recommendation and when the calculation was recorded.
          </Text>
        </View>

        <View className="bg-surface border border-border rounded-[24px] p-4 mb-4">
          <View className="flex-row items-start justify-between">
            <View>
              <Text className="text-base font-black text-foreground">Position sizing</Text>
              <Text className="text-xs text-muted mt-1">{riskProfile} fractional-Kelly profile</Text>
            </View>
            <View className="items-end">
              <Text className="text-[10px] uppercase tracking-wider font-bold text-muted">Suggested</Text>
              <Text className="text-2xl font-black text-primary">${suggestedStake.toFixed(2)}</Text>
            </View>
          </View>
          <View className="bg-warning/10 rounded-2xl p-3 mt-4">
            <Text className="text-[11px] leading-4 text-muted">
              Demonstration calculation only. No bet is created, transmitted, or executed by this app.
            </Text>
          </View>
        </View>

        <Pressable
          onPress={() => void trackPosition()}
          disabled={isTracking || !canTrack}
          className={`rounded-2xl py-4 items-center border mb-3 ${canTrack ? "bg-[#102536] border-[#1D3A4D]" : "bg-surface border-border opacity-60"}`}
          accessibilityLabel="Track the selected sportsbook position in the MPIE portfolio"
        >
          <Text className={`font-black ${canTrack ? "text-[#4DE3FF]" : "text-muted"}`}>
            {isTracking ? "Tracking position…" : canTrack ? "Track selected sportsbook position" : "No active price available"}
          </Text>
        </Pressable>
        {trackingMessage ? (
          <Text className="text-xs leading-5 text-muted text-center mb-3">{trackingMessage}</Text>
        ) : null}

        <Pressable onPress={() => toggleSavedGame(game.id)} className={`rounded-2xl py-4 items-center ${isSaved ? "bg-surface border border-primary" : "bg-primary"}`}>
          <Text className={`font-black ${isSaved ? "text-primary" : "text-[#071019]"}`}>{isSaved ? "Remove from watchlist" : "Add to watchlist"}</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
