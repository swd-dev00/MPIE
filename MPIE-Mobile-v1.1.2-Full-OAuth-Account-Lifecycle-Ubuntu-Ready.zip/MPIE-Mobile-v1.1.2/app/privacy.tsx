import { InfoPage } from "@/components/mpie/info-page";

export default function PrivacyScreen() {
  return (
    <InfoPage
      eyebrow="Data handling"
      title="Privacy"
      icon="lock-outline"
      intro="MPIE stores different categories of information in different places. This page documents the current v1.1.2 application behavior so the interface does not imply that all information remains only on the device."
      sections={[
        {
          title: "Stored on the device",
          bullets: [
            "Theme, risk-profile, bankroll-display, notification, and related application preferences.",
            "Unsynchronized Playbook drafts used for loss recovery.",
            "Local watchlist state and pending synchronization operations.",
          ],
        },
        {
          title: "Stored by the FastAPI service",
          bullets: [
            "Watchlist event identifiers.",
            "Portfolio positions, including selected sportsbook and entry price.",
            "Saved Playbook titles and Markdown bodies.",
          ],
        },
        {
          title: "Stored in ClickHouse when live mode is enabled",
          bullets: [
            "Market events and bookmaker quotes.",
            "Predictions, model version, calculation timestamp, pressure attribution, and signals.",
            "Analytical aggregates used by the MPIE data service.",
          ],
        },
        {
          title: "Identity and access",
          bullets: [
            "OAuth is prebuilt but disabled by default; development mode continues to use X-MPIE-User-ID until provider clients are configured.",
            "When OAuth is enabled, MPIE stores an internal user UUID, linked provider subjects, and revocable server-session records.",
            "Provider tokens, authorization codes, session secrets, and Apple private keys must not be logged or committed.",
          ],
        },
        {
          title: "Account deletion",
          body: [
            "The Settings deletion flow requires the exact phrase DELETE. An authenticated deletion removes sessions, linked identities, watchlist records, portfolio positions, Playbook entries, and the MPIE user. Retained audit rows, when present, are de-identified according to the configured retention policy.",
          ],
        },
        {
          title: "No wagering execution",
          body: [
            "MPIE does not transmit or execute bets. Portfolio tracking records analytical positions inside the application.",
          ],
        },
      ]}
      notice="This is an implementation disclosure for the current application, not a substitute for a jurisdiction-specific legal privacy policy or counsel review."
    />
  );
}
