# MPIE Mobile v1.1.2 — OAuth and Account Lifecycle Prebuild

The v1.1.2 backend includes provider-neutral user persistence, Google and Apple
identity-token verification, rotating refresh sessions, user-initiated account
deletion, and signed Apple account-change notifications. OAuth remains disabled
by default until real provider client IDs and a session secret are configured.

## Security state

```env
MPIE_AUTH_ENABLED=false
```

With authentication disabled, existing v1.1.2 development behavior remains in
place: `X-MPIE-User-ID` selects the development user. When authentication is
enabled, user-state endpoints require an MPIE Bearer access token and the header
is no longer accepted as identity.

## Persistence

SQLite adds provider-neutral identity and lifecycle tables without changing
existing watchlist, portfolio, or Playbook records:

- `users` — internal MPIE UUID, profile, status, and login timestamps
- `auth_identities` — provider plus immutable provider `sub` mapped to an MPIE user
- `auth_sessions` — hashed rotating refresh tokens, provider identity attribution,
  expiry, and revocation state
- `stake_suggestion_audit` — optional de-identification target for future retained
  audit rows

Email is metadata, not the durable provider key. Accounts are not automatically
linked merely because Google and Apple return the same email address.

## Backend routes

```text
POST   /api/v1/auth/google
POST   /api/v1/auth/apple
POST   /api/v1/auth/apple/webhook
POST   /api/v1/auth/refresh
POST   /api/v1/auth/logout
GET    /api/v1/auth/me
DELETE /api/v1/auth/me
```

Google and Apple login payload:

```json
{
  "idToken": "provider-issued-id-token",
  "nonce": "client-generated-nonce",
  "displayName": "optional-first-Apple-login-name"
}
```

Apple webhook payload:

```json
{
  "payload": "apple-signed-server-notification-jwt"
}
```

## User-initiated account deletion

The mobile Settings screen requires an exact typed `DELETE` phrase before calling
`DELETE /api/v1/auth/me`. A successful request:

1. Revokes all MPIE sessions for the user.
2. De-identifies retained stake-audit rows when present.
3. Deletes provider identities.
4. Deletes watchlist, portfolio, and Playbook state.
5. Deletes the internal MPIE user.
6. Clears local access and refresh tokens.

The current prebuild does not yet revoke an Apple refresh token at Apple's
`/auth/revoke` endpoint because Apple authorization-code exchange and provider
refresh-token storage still require the final Team ID, Key ID, private key, and
client configuration.

## Apple server-to-server notifications

Register the public HTTPS endpoint:

```text
https://<api-host>/api/v1/auth/apple/webhook
```

The backend verifies the signed JWT using Apple's JWK endpoint and configured
Apple client-ID audiences. Event handling is idempotent:

- `consent-revoked`: revoke sessions attributable to Apple and detach Apple.
- `account-delete`: detach Apple; if no other identity remains, delete the MPIE
  user and owned state.
- `email-disabled`: clear Apple identity email metadata.
- `email-enabled`: acknowledge and wait for verified metadata on a later login.
- Unknown identity: return HTTP 200 with `unknown_identity`.
- Invalid signature: log and return HTTP 200 with `ignored`.

New sessions carry `identity_id`. Existing pre-migration sessions do not; on an
identity disconnect, unscoped legacy sessions for the same user are revoked as a
conservative fallback.

## Required backend configuration

Generate a random session secret of at least 32 characters. Do not commit it.

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

```env
MPIE_AUTH_ENABLED=true
MPIE_SESSION_SECRET=<generated-secret>
MPIE_SESSION_TTL_SECONDS=3600
MPIE_REFRESH_TTL_SECONDS=2592000
MPIE_SESSION_ISSUER=mpie-api
MPIE_SESSION_AUDIENCE=mpie-mobile

GOOGLE_CLIENT_IDS=<comma-separated accepted audiences>
GOOGLE_WEB_CLIENT_ID=
GOOGLE_IOS_CLIENT_ID=
GOOGLE_ANDROID_CLIENT_ID=

APPLE_CLIENT_IDS=<comma-separated accepted audiences>
APPLE_CLIENT_ID=com.sierrawarrendevelopments.mpie
```

The backend accepts multiple audiences so web, iOS, and Android OAuth clients can
share one verification service without weakening audience validation.

## Provider verification

The verifier enforces:

- RS256 only
- provider signing-key lookup by `kid`
- one forced JWK refresh when an unknown `kid` appears
- issuer, audience, expiration when supplied, issued-at, subject, and nonce checks
- provider `sub` as the immutable login identity

JWK responses are cached according to `Cache-Control: max-age`, bounded between
one minute and one day.

## Mobile token storage

`lib/mpie-auth.ts` prebuilds:

- `getStoredJwt`
- `getStoredRefreshToken`
- `storeAuthSession`
- `clearStoredAuth`
- `signOut`

Native platforms use `expo-secure-store`; web uses localStorage. The login landing
screen is valid but intentionally does not initiate provider authorization until
real OAuth client settings are inserted.

## Mobile wiring still required

After provider clients exist:

1. Connect Google and Apple sign-in controls to the provider SDK/browser flow.
2. Generate and retain a cryptographically random nonce per attempt.
3. Send the provider ID token and expected nonce to FastAPI.
4. Persist the returned MPIE session with `storeAuthSession`.
5. Replace development `X-MPIE-User-ID` requests with `Authorization: Bearer ...`.
6. Add access-token refresh handling for expired API calls.
7. Add explicit account-linking UI; never link providers by email alone.
8. Implement Apple authorization-code exchange and provider-token revocation.

## Tests

```bash
cd ~/MPIE-Mobile-v1.1.2
bash backend/install_backend.sh
cd backend
.venv/bin/python -m unittest discover -s tests -v
```

The suite mocks Google and Apple JWK endpoints and covers valid tokens, wrong
issuer/audience, expiration, nonce mismatch, key rotation, returning Apple users,
identity CRUD, session rotation, account deletion, all locked Apple webhook
behaviors, and preservation of existing state.
