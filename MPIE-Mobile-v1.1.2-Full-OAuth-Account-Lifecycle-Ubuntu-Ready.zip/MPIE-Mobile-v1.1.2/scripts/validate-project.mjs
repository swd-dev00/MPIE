import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const root = process.cwd();
const requiredFiles = [
  "app/_layout.tsx",
  "app/(tabs)/_layout.tsx",
  "app/(tabs)/index.tsx",
  "app/(tabs)/markets.tsx",
  "app/(tabs)/signals.tsx",
  "app/(tabs)/portfolio.tsx",
  "app/(tabs)/settings.tsx",
  "app/(tabs)/playbook.tsx",
  "app/(auth)/_layout.tsx",
  "app/(auth)/login.tsx",
  "app/about.tsx",
  "app/methodology.tsx",
  "app/privacy.tsx",
  "app/data-provenance.tsx",
  "app/data-source.tsx",
  "app/watchlist-sync.tsx",
  "app/game/[id].tsx",
  "components/mpie/brand-mark.tsx",
  "components/mpie/ui.tsx",
  "components/mpie/markdown-preview.tsx",
  "components/mpie/info-page.tsx",
  "constants/mpie-data.ts",
  "lib/mpie-api.ts",
  "lib/mpie-data-provider.tsx",
  "lib/mpie-store.tsx",
  "lib/markdown.ts",
  "lib/playbook-draft.ts",
  "lib/mpie-auth.ts",
  "tests/market-pricing.test.ts",
  "tests/settings-navigation.test.ts",
  "eslint.config.mjs",
  "backend/app/main.py",
  "backend/app/state.py",
  "backend/app/models.py",
  "backend/app/config.py",
  "backend/app/auth/__init__.py",
  "backend/app/auth/claims.py",
  "backend/app/auth/jwks.py",
  "backend/app/auth/google.py",
  "backend/app/auth/apple.py",
  "backend/app/auth/sessions.py",
  "backend/app/auth/service.py",
  "backend/tests/test_auth_state.py",
  "backend/tests/test_auth_service.py",
  "backend/tests/test_auth_api_contract.py",
  "backend/tests/test_oauth_google.py",
  "backend/tests/test_oauth_apple.py",
  "backend/requirements.txt",
  "backend/.env.example",
  "backend/sql/001_clickhouse_schema.sql",
  "backend/scripts/validate_backend.py",
  "backend/install_backend.sh",
  "backend/start_api.sh",
  "scripts/ubuntu_update.sh",
  "scripts/ubuntu_smoke_test.sh",
  "README.md",
  "UBUNTU_UPDATE.md",
  "TEST_REPORT.md",
  "API_VERIFICATION.md",
  "OAUTH_SETUP.md",
  "MOBILE_PR_DESCRIPTION.md",
  "FULL_BUILD_MANIFEST.md",
  "ACCOUNT_LIFECYCLE_RECONCILIATION.md",
  "assets/images/icon.png",
  "assets/images/splash-icon.png",
];

const failures = [];
for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) failures.push(`Missing required file: ${file}`);
}

const require = createRequire(import.meta.url);
let ts;
try {
  ts = require("typescript");
} catch (error) {
  failures.push(`Unable to load local TypeScript for syntax validation: ${error.message}`);
}

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) return walk(full);
    return /\.(ts|tsx)$/.test(entry.name) ? [full] : [];
  });
}

if (ts) {
  const sourceRoots = ["app", "components", "constants", "hooks", "lib", "shared", "tests"]
    .map((dir) => path.join(root, dir))
    .filter(fs.existsSync);
  const sources = sourceRoots.flatMap(walk);
  for (const file of sources) {
    const source = fs.readFileSync(file, "utf8");
    const result = ts.transpileModule(source, {
      fileName: file,
      reportDiagnostics: true,
      compilerOptions: {
        target: ts.ScriptTarget.ES2022,
        module: ts.ModuleKind.CommonJS,
        jsx: ts.JsxEmit.ReactJSX,
        strict: true,
      },
    });
    for (const diagnostic of result.diagnostics ?? []) {
      if (diagnostic.category !== ts.DiagnosticCategory.Error) continue;
      const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, " ");
      failures.push(`${path.relative(root, file)}: ${message}`);
    }
  }

  const dataFile = path.join(root, "constants/mpie-data.ts");
  const transpiled = ts.transpileModule(fs.readFileSync(dataFile, "utf8"), {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
    },
  }).outputText;
  const dataModule = { exports: {} };
  new Function("module", "exports", transpiled)(dataModule, dataModule.exports);
  const { games, marketPriceBoards } = dataModule.exports;
  if (!Array.isArray(games) || games.length < 5) failures.push("Expected at least five demonstration games.");
  const ids = new Set();
  for (const game of games ?? []) {
    if (ids.has(game.id)) failures.push(`Duplicate game ID: ${game.id}`);
    ids.add(game.id);
    for (const key of ["impliedProbability", "modelProbability", "baselineProbability", "confidence"]) {
      if (!(game[key] >= 0 && game[key] <= 1)) failures.push(`${game.id}.${key} must be between 0 and 1.`);
    }
    if (!Array.isArray(game.factors) || game.factors.length < 3) failures.push(`${game.id} needs at least three pressure factors.`);
    for (const key of ["marketKey", "outcome", "bestBookmakerKey", "bestBookmakerTitle", "modelVersion", "calculatedAt"]) {
      if (!game[key]) failures.push(`${game.id}.${key} is required for transparent market pricing.`);
    }
    if (!(game.bookmakerCount >= 1)) failures.push(`${game.id}.bookmakerCount must be at least 1.`);
    const board = marketPriceBoards?.[game.id];
    if (!board || !Array.isArray(board.quotes) || board.quotes.length < 3) {
      failures.push(`${game.id} must provide a bookmaker comparison board.`);
    } else if (!board.quotes.some((quote) => quote.isBestPrice)) {
      failures.push(`${game.id} bookmaker board must identify the best price.`);
    }
  }
}

function readPngSize(file) {
  const buffer = fs.readFileSync(file);
  if (buffer.toString("ascii", 1, 4) !== "PNG") throw new Error(`${file} is not a PNG.`);
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

for (const [file, expected] of [
  ["assets/images/icon.png", 1024],
  ["assets/images/splash-icon.png", 1024],
  ["assets/images/android-icon-foreground.png", 432],
]) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) continue;
  const size = readPngSize(full);
  if (size.width !== expected || size.height !== expected) {
    failures.push(`${file} must be ${expected}×${expected}; received ${size.width}×${size.height}.`);
  }
}


const authMainSource = fs.readFileSync(path.join(root, "backend/app/main.py"), "utf8");
for (const route of [
  "/api/v1/auth/google",
  "/api/v1/auth/apple",
  "/api/v1/auth/apple/webhook",
  "/api/v1/auth/refresh",
  "/api/v1/auth/logout",
  "/api/v1/auth/me",
]) {
  if (!authMainSource.includes(route)) failures.push(`OAuth API route missing: ${route}`);
}
for (const token of ["settings.auth_enabled", "Authorization", "Bearer", "auth_service.authenticate_access_token"]) {
  if (!authMainSource.includes(token)) failures.push(`OAuth API boundary missing token: ${token}`);
}
for (const token of ["delete_current_user", "apple_webhook", "apple_webhook_verify_failed"]) {
  if (!authMainSource.includes(token)) failures.push(`OAuth lifecycle API missing token: ${token}`);
}

const authStateSource = fs.readFileSync(path.join(root, "backend/app/state.py"), "utf8");
for (const token of [
  "CREATE TABLE IF NOT EXISTS users",
  "CREATE TABLE IF NOT EXISTS auth_identities",
  "CREATE TABLE IF NOT EXISTS auth_sessions",
  "find_user_by_provider",
  "find_identity",
  "create_auth_identity",
  "update_identity_claims",
  "delete_auth_identity",
  "get_or_create_oauth_user",
  "create_auth_session",
  "rotate_auth_session",
  "revoke_auth_session",
  "revoke_all_sessions_for_identity",
  "user_has_other_identities",
  "delete_user_and_cascade",
  "anonymize_stake_audit",
]) {
  if (!authStateSource.includes(token)) failures.push(`OAuth state layer missing token: ${token}`);
}

const authConfigSource = fs.readFileSync(path.join(root, "backend/app/config.py"), "utf8");
for (const token of ["MPIE_AUTH_ENABLED", "MPIE_SESSION_SECRET", "GOOGLE_CLIENT_IDS", "APPLE_CLIENT_IDS"]) {
  if (!authConfigSource.includes(token)) failures.push(`OAuth configuration missing token: ${token}`);
}

const backendEnvExample = fs.readFileSync(path.join(root, "backend/.env.example"), "utf8");
if (!backendEnvExample.includes("MPIE_AUTH_ENABLED=false")) {
  failures.push("OAuth must remain disabled by default in backend/.env.example.");
}
if (!backendEnvExample.includes("MPIE_SESSION_SECRET=\n")) {
  failures.push("OAuth session secret placeholder must remain empty.");
}

const backendRequirements = fs.readFileSync(path.join(root, "backend/requirements.txt"), "utf8");
if (!backendRequirements.includes("PyJWT[crypto]==")) {
  failures.push("Backend requirements must pin PyJWT with cryptography support.");
}

const packageJson = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
if (packageJson.main !== "expo-router/entry") failures.push("package.json must use expo-router/entry.");
if (packageJson.name !== "mpie-mobile") failures.push("package.json name is not finalized.");
if (packageJson.version !== "1.1.2") failures.push("package.json version must be 1.1.2.");

const appConfig = fs.readFileSync(path.join(root, "app.config.ts"), "utf8");
for (const token of ["name: \"MPIE\"", "version: \"1.1.2\"", "scheme: \"mpie\"", "com.sierrawarrendevelopments.mpie"]) {
  if (!appConfig.includes(token)) failures.push(`app.config.ts missing branding token: ${token}`);
}

const appSources = walk(path.join(root, "app")).map((file) => fs.readFileSync(file, "utf8")).join("\n");
if (/trpc\.(games|predictions)/.test(appSources)) failures.push("Frontend still references unimplemented game or prediction API routers.");

const integrationSource = [
  fs.readFileSync(path.join(root, "lib/mpie-api.ts"), "utf8"),
  fs.readFileSync(path.join(root, "lib/mpie-data-provider.tsx"), "utf8"),
  fs.readFileSync(path.join(root, "lib/mpie-store.tsx"), "utf8"),
].join("\n");
for (const token of [
  "EXPO_PUBLIC_MPIE_API_URL",
  "/api/v1/markets",
  "/api/v1/markets/",
  "/api/v1/signals",
  "/api/v1/portfolio",
  "/api/v1/watchlist",
  "/api/v1/playbook",
  "MpieDataProvider",
  "loadMarketPrices",
  "loadHealth",
  "bookmakerKey",
  "bookmakerTitle",
]) {
  if (!integrationSource.includes(token)) failures.push(`MPIE live integration missing token: ${token}`);
}


const playbookSource = fs.readFileSync(path.join(root, "app/(tabs)/playbook.tsx"), "utf8");
for (const required of [
  'title="Playbook"',
  "bodyMarkdown",
  "MarkdownPreview",
  "Create entry",
  "Preview",
  "savePlaybookDraft",
  "draftSequence.current !== sequence",
  "Save Playbook entry",
]) {
  if (!playbookSource.includes(required)) failures.push(`Playbook feature missing token: ${required}`);
}
for (const forbidden of ["fontFamilyPicker", "font size picker", "font choice", "rich-text toolbar"]) {
  if (playbookSource.toLowerCase().includes(forbidden.toLowerCase())) {
    failures.push(`Playbook must remain Markdown-only; found forbidden UI token: ${forbidden}`);
  }
}

const playbookApi = fs.readFileSync(path.join(root, "lib/mpie-api.ts"), "utf8");
for (const method of ["loadPlaybookEntries", "createPlaybookEntry", "updatePlaybookEntry", "deletePlaybookEntry"]) {
  if (!playbookApi.includes(method)) failures.push(`Playbook API client missing method: ${method}`);
}

const playbookDraftSource = fs.readFileSync(path.join(root, "lib/playbook-draft.ts"), "utf8");
for (const required of ["AsyncStorage", "userId", "updatedAt", "clearPlaybookDraft"]) {
  if (!playbookDraftSource.includes(required)) failures.push(`Playbook draft safety missing token: ${required}`);
}

const rootLayout = fs.readFileSync(path.join(root, "app/_layout.tsx"), "utf8");
for (const forbidden of ["trpc.Provider", "createTRPCClient", "initManusRuntime"]) {
  if (rootLayout.includes(forbidden)) failures.push(`Root layout still initializes unused legacy runtime: ${forbidden}`);
}

const storeSource = fs.readFileSync(path.join(root, "lib/mpie-store.tsx"), "utf8");
for (const required of ["PENDING_WATCHLIST_KEY", "applyPendingOperations", "remoteWatchlist !== null", "watchlistPendingCount"]) {
  if (!storeSource.includes(required)) failures.push(`Watchlist synchronization safety missing token: ${required}`);
}

const gameDetailSource = fs.readFileSync(path.join(root, "app/game/[id].tsx"), "utf8");
for (const required of [
  "Sportsbook prices",
  "Best price",
  "differenceFromConsensusPct",
  "bookmakerKey",
  "bookmakerTitle",
  "No active price available",
  "ClickHouse-backed bookmaker prices",
  "Model provenance",
  "modelVersion",
  "calculatedAt",
]) {
  if (!gameDetailSource.includes(required)) failures.push(`Market transparency UI missing token: ${required}`);
}


const settingsSource = fs.readFileSync(path.join(root, "app/(tabs)/settings.tsx"), "utf8");
for (const required of [
  'router.push("/about")',
  'router.push("/methodology")',
  'router.push("/privacy")',
  'router.push("/data-provenance")',
  'router.push("/data-source")',
  'router.push("/watchlist-sync")',
  "Device, API, SQLite, and ClickHouse data handling",
]) {
  if (!settingsSource.includes(required)) failures.push(`Settings product pages missing token: ${required}`);
}
for (const required of ["DeleteAccountModal", "Type DELETE to confirm", "/api/v1/auth/me"]) {
  if (!settingsSource.includes(required)) {
    failures.push(`Settings screen missing account deletion token: ${required}`);
  }
}
const authClientSource = fs.readFileSync(path.join(root, "lib/mpie-auth.ts"), "utf8");
for (const required of ["getStoredJwt", "storeAuthSession", "signOut", "expo-secure-store"]) {
  if (!authClientSource.includes(required)) failures.push(`Mobile auth storage missing token: ${required}`);
}
for (const page of ["about", "methodology", "privacy", "data-provenance"]) {
  const pageSource = fs.readFileSync(path.join(root, `app/${page}.tsx`), "utf8");
  if (!pageSource.includes("InfoPage")) failures.push(`${page} page is not wired to the product information layout.`);
}

if (!packageJson.scripts["dev:full"]?.includes("dev:api") || packageJson.scripts["dev:full"]?.includes("legacy")) {
  failures.push("dev:full must start FastAPI and Metro without the unused legacy server.");
}

if (!packageJson.scripts["dev:metro"]?.includes("expo start") || packageJson.scripts["dev:metro"]?.includes("npx expo")) {
  failures.push("dev:metro must use the project-local Expo binary under WSL.");
}
if (!packageJson.scripts["dev:metro"]?.includes("--host lan")) {
  failures.push("dev:metro must bind Expo in LAN mode for same-network device access.");
}

if (failures.length) {
  console.error("MPIE validation failed:\n" + failures.map((item) => ` - ${item}`).join("\n"));
  process.exit(1);
}

console.log("MPIE validation passed.");
console.log(`Validated ${requiredFiles.length} required deliverables, TypeScript syntax, live API wiring, route structure, ${5} data scenarios, and branded PNG assets.`);
