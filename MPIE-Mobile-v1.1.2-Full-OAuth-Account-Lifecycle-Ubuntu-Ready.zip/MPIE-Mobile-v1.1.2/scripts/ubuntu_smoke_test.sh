#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
PORT="${MPIE_SMOKE_PORT:-18000}"
BASE_URL="http://127.0.0.1:${PORT}"
LOG_FILE="${TMPDIR:-/tmp}/mpie-smoke-${PORT}.log"
STATE_DB="${TMPDIR:-/tmp}/mpie-smoke-state-${PORT}.db"
USER_ID="123e4567-e89b-12d3-a456-426614174001"
PID=""

stop_api() {
  if [[ -n "$PID" ]] && kill -0 "$PID" 2>/dev/null; then
    kill "$PID" 2>/dev/null || true
    wait "$PID" 2>/dev/null || true
  fi
  PID=""
}

cleanup() {
  stop_api
  rm -f "$STATE_DB" "$STATE_DB-shm" "$STATE_DB-wal"
}
trap cleanup EXIT

start_api() {
  : >"$LOG_FILE"
  MPIE_DEMO_MODE=true \
  MPIE_STATE_DB="$STATE_DB" \
  MPIE_SKIP_INSTALL=true \
  PORT="$PORT" \
  bash start_api.sh >"$LOG_FILE" 2>&1 &
  PID=$!

  for _ in $(seq 1 60); do
    if curl --fail --silent "$BASE_URL/health" >/dev/null 2>&1; then
      return
    fi
    if ! kill -0 "$PID" 2>/dev/null; then
      echo "API exited during smoke test. Log follows:" >&2
      cat "$LOG_FILE" >&2
      exit 1
    fi
    sleep 0.25
  done

  echo "API did not become healthy on port $PORT. Log follows:" >&2
  cat "$LOG_FILE" >&2
  exit 1
}

cd "$BACKEND_DIR"
[[ -x .venv/bin/python ]] || bash install_backend.sh
rm -f "$STATE_DB" "$STATE_DB-shm" "$STATE_DB-wal"

start_api

curl --fail --silent "$BASE_URL/health" | grep -q '"status":"ok"'
MARKETS_RESPONSE="$(curl --fail --silent "$BASE_URL/api/v1/markets")"
printf '%s' "$MARKETS_RESPONSE" | grep -q '"id"'
printf '%s' "$MARKETS_RESPONSE" | grep -q '"modelVersion"'
printf '%s' "$MARKETS_RESPONSE" | grep -q '"calculatedAt"'
curl --fail --silent \
  "$BASE_URL/api/v1/markets/bos-ny-0710/prices?market_key=h2h&outcome=Boston" \
  | grep -q '"bestBookmakerTitle"'
OPENAPI_RESPONSE="$(curl --fail --silent "$BASE_URL/openapi.json")"
printf '%s' "$OPENAPI_RESPONSE" | grep -q '"/api/v1/playbook"'
printf '%s' "$OPENAPI_RESPONSE" | grep -q '"/api/v1/auth/google"'
printf '%s' "$OPENAPI_RESPONSE" | grep -q '"/api/v1/auth/apple"'
printf '%s' "$OPENAPI_RESPONSE" | grep -q '"/api/v1/auth/apple/webhook"'
curl --fail --silent "$BASE_URL/docs" | grep -qi 'swagger'

AUTH_STATUS="$(curl --silent --output /dev/null --write-out '%{http_code}' \
  -X POST \
  -H 'Content-Type: application/json' \
  --data '{"idToken":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx","nonce":"nonce-123"}' \
  "$BASE_URL/api/v1/auth/google")"
[[ "$AUTH_STATUS" == "503" ]] || {
  echo "OAuth must be safely disabled by default; received HTTP $AUTH_STATUS." >&2
  exit 1
}

DELETE_STATUS="$(curl --silent --output /dev/null --write-out '%{http_code}' \
  -X DELETE "$BASE_URL/api/v1/auth/me")"
[[ "$DELETE_STATUS" == "503" ]] || {
  echo "Account deletion must require enabled OAuth; received HTTP $DELETE_STATUS." >&2
  exit 1
}

ENTRY_RESPONSE="$(curl --fail --silent \
  -X POST \
  -H 'Content-Type: application/json' \
  -H "X-MPIE-User-ID: $USER_ID" \
  --data '{"title":"Smoke-test idea","bodyMarkdown":"# Observation\n\n- [ ] Verify persistence"}' \
  "$BASE_URL/api/v1/playbook")"
ENTRY_ID="$(printf '%s' "$ENTRY_RESPONSE" | .venv/bin/python -c 'import json,sys; print(json.load(sys.stdin)["id"])')"

curl --fail --silent \
  -X PATCH \
  -H 'Content-Type: application/json' \
  -H "X-MPIE-User-ID: $USER_ID" \
  --data '{"bodyMarkdown":"# Updated\n\nSaved across an API restart"}' \
  "$BASE_URL/api/v1/playbook/${ENTRY_ID}" \
  | grep -q 'Saved across an API restart'

# Restart against the same SQLite file to prove that Save is durable.
stop_api
start_api

curl --fail --silent \
  -H "X-MPIE-User-ID: $USER_ID" \
  "$BASE_URL/api/v1/playbook/${ENTRY_ID}" \
  | grep -q 'Saved across an API restart'

curl --fail --silent \
  -X DELETE \
  -H "X-MPIE-User-ID: $USER_ID" \
  "$BASE_URL/api/v1/playbook/${ENTRY_ID}" \
  >/dev/null

POSITION_RESPONSE="$(curl --fail --silent \
  -X POST \
  -H 'Content-Type: application/json' \
  -H "X-MPIE-User-ID: $USER_ID" \
  --data '{"eventId":"bos-ny-0710","marketKey":"h2h","outcome":"Boston","label":"Boston ML","game":"BOS @ NYY","entryPrice":2.10,"sizeUnits":20,"bookmakerKey":"draftkings","bookmakerTitle":"DraftKings","status":"Open"}' \
  "$BASE_URL/api/v1/portfolio/positions")"
printf '%s' "$POSITION_RESPONSE" | grep -q '"bookmakerKey":"draftkings"'
printf '%s' "$POSITION_RESPONSE" | grep -q '"bookmakerTitle":"DraftKings"'

echo "Ubuntu API, OAuth/account-deletion disabled boundary, market pricing, bookmaker attribution, and Playbook persistence smoke test passed on temporary port $PORT."
