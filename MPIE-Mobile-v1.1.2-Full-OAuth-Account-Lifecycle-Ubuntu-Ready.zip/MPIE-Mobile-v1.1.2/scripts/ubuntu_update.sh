#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FROM_DIR=""
SKIP_MOBILE=false
SKIP_SMOKE=false
PREPARE_ONLY=false

usage() {
  cat <<'EOF'
Usage: bash scripts/ubuntu_update.sh [options]

Options:
  --from PATH      Import .env files and backend/data from an existing v1.1.2 directory.
  --skip-mobile    Skip Node/pnpm dependency installation and TypeScript checks.
  --skip-smoke     Skip the temporary live API smoke test.
  --prepare-only   Import configuration/state and stop before installing dependencies.
  -h, --help       Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --from)
      [[ $# -ge 2 ]] || { echo "--from requires a path." >&2; exit 2; }
      FROM_DIR="$(cd "$2" && pwd)"
      shift 2
      ;;
    --skip-mobile)
      SKIP_MOBILE=true
      shift
      ;;
    --skip-smoke)
      SKIP_SMOKE=true
      shift
      ;;
    --prepare-only)
      PREPARE_ONLY=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

cd "$ROOT_DIR"
export PATH="$HOME/.local/bin:$PATH"

echo "Preparing MPIE Mobile v1.1.2 in $ROOT_DIR"

if [[ -n "$FROM_DIR" && "$FROM_DIR" != "$ROOT_DIR" ]]; then
  echo "Importing runtime configuration and state from $FROM_DIR"
  [[ -f "$FROM_DIR/.env" ]] && cp -a "$FROM_DIR/.env" "$ROOT_DIR/.env"
  [[ -f "$FROM_DIR/backend/.env" ]] && cp -a "$FROM_DIR/backend/.env" "$ROOT_DIR/backend/.env"
  if [[ -d "$FROM_DIR/backend/data" ]]; then
    mkdir -p "$ROOT_DIR/backend/data"
    cp -a "$FROM_DIR/backend/data/." "$ROOT_DIR/backend/data/"
  fi
fi

[[ -f .env ]] || cp .env.example .env
[[ -f backend/.env ]] || cp backend/.env.example backend/.env

if [[ "$PREPARE_ONLY" == "true" ]]; then
  echo "Configuration and state import completed; dependency installation was skipped."
  exit 0
fi

bash backend/install_backend.sh

if [[ "$SKIP_MOBILE" != "true" ]]; then
  if ! command -v node >/dev/null 2>&1; then
    echo "ERROR: Node.js 20 or newer is required for Expo." >&2
    exit 1
  fi
  if ! node -e 'const [a,b,c]=process.versions.node.split(".").map(Number); process.exit(a>20 || (a===20 && (b>19 || (b===19 && c>=4))) ? 0 : 1)'; then
    echo "ERROR: Node.js 20.19.4 or newer is required; found $(node --version)." >&2
    exit 1
  fi

  if ! command -v pnpm >/dev/null 2>&1; then
    if command -v corepack >/dev/null 2>&1; then
      corepack enable 2>/dev/null || true
      corepack prepare pnpm@9.12.0 --activate
    else
      npm install --global pnpm@9.12.0
    fi
  fi

  pnpm install --frozen-lockfile
fi

echo "Running static and contract validation..."
if [[ "$SKIP_MOBILE" != "true" ]]; then
  node scripts/validate-project.mjs
fi
backend/.venv/bin/python backend/scripts/validate_backend.py
(
  cd backend
  .venv/bin/python -m unittest discover -s tests -v
)

if [[ "$SKIP_MOBILE" != "true" ]]; then
  pnpm check
  pnpm lint
  pnpm test
fi

if [[ "$SKIP_SMOKE" != "true" ]]; then
  bash scripts/ubuntu_smoke_test.sh
fi

cat <<'EOF'

MPIE v1.1.2 update validation passed.

Start the API:
  bash backend/start_api.sh

Start API + Expo web/Metro:
  pnpm dev:full

Swagger documentation:
  http://localhost:8000/docs
EOF
