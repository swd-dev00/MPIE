# MPIE Mobile v1.1.2 — Complete Test Report

## Backend suite

Thirty-eight test methods pass:

- Existing health, market, bookmaker-price, prediction, pressure, watchlist,
  portfolio, and Playbook contracts
- Playbook validation and per-user isolation
- SQLite legacy-notes and bookmaker-column migrations
- Bounded ClickHouse repository paths and shared-client safety
- User CRUD, provider lookup, provider-subject idempotency, and disable behavior
- Identity-link conflict prevention
- Existing watchlist and Playbook preservation through the auth migration
- Refresh-session creation, rotation, replay rejection, revocation, and access-token
  invalidation
- Identity-scoped session revocation and legacy-session fallback
- Authenticated permanent account deletion and owned-state cascade
- Google valid token, wrong audience, wrong issuer, expiration, nonce mismatch,
  unknown key, and JWK rotation
- Apple first-login and returning-user behavior, private relay email, wrong audience,
  wrong issuer, expiration, nonce mismatch, and JWK rotation
- Signed Apple notification verification
- Apple consent-revoked detach-only behavior
- Apple account-delete sole-identity deletion
- Apple account-delete multi-identity preservation
- Repeated-notification idempotency
- Unknown Apple subject acknowledgement
- Invalid webhook signature logging and HTTP 200 acknowledgement
- OAuth-disabled API behavior
- Auth service login, access, refresh, logout, and account lifecycle integration

## Static validation

- **65/65 required deliverables**
- Python syntax across recursive backend application, auth package, scripts, and tests
- Required v1.1.2 app routes, Settings destinations, Playbook, market transparency,
  account deletion, images, deployment scripts, OAuth files, docs, and tests
- TypeScript/TSX syntax validation across frontend sources
- ClickHouse schema hash and safety patterns
- Intentionally updated Pydantic model hash
- OAuth disabled by default and empty session-secret placeholder
- No Apple private key, provider secret, runtime database, or user token in the archive

## Runtime checks

- FastAPI OpenAPI generation
- Swagger UI
- Existing application API smoke path
- SQLite identity/session migration in isolated databases
- User deletion state cascade
- Mocked Google and Apple JWK endpoints; no provider network credentials required

## Target Ubuntu verification

```bash
cd ~/MPIE-Mobile-v1.1.2
bash backend/install_backend.sh
pnpm install --frozen-lockfile
pnpm validate
pnpm validate:backend
pnpm test:backend
pnpm check
pnpm lint
pnpm test
bash scripts/ubuntu_smoke_test.sh
```

OAuth remains disabled during the standard smoke test. Provider-client testing is
performed with mocked JWKs until real Apple and Google clients are configured.
