# MPIE Mobile v1.1.2 — Playbook + Market Transparency

**Market Pressure Intelligence Engine** — an Expo/React Native decision interface backed by FastAPI, ClickHouse analytics, and a transactional SQLite state store.

## Included in v1.1.2

### Playbook

Playbook is a dedicated application feature for recording ideas, model changes, market observations, and follow-up work.

- Dedicated **Playbook** tab
- Markdown-only user input
- Write and rendered-preview modes
- Create, save, reopen, edit, search, and delete entries
- Per-user server persistence through FastAPI and SQLite
- Local draft autosave and restoration before server synchronization
- Created and last-updated timestamps
- No font picker, custom typeface selection, or rich-text toolbar

### Transparent market pricing and provenance

- Best available decimal price and sportsbook on each market card
- Bookmaker comparison panel on game detail
- Consensus decimal price and each book's percentage difference from consensus
- Last-updated timestamps
- Active, stale, and suspended quote states
- Explicit sportsbook selection before tracking a position
- Sportsbook key and display name persisted with the portfolio position
- Data-source labels distinguish ClickHouse live data, API demo analytics, and
  local demonstration fallback
- Model version and calculation timestamp are visible on game detail

### Product information pages

Settings now opens complete About MPIE, Methodology, Data Provenance, and Privacy pages. The privacy summary accurately distinguishes local preferences and drafts, FastAPI/SQLite user state, and ClickHouse analytics.

The ClickHouse analytical schema is unchanged. The market-price API reads the existing `mpie.odds_snapshot` table. SQLite adds two nullable portfolio columns through an idempotent migration: `bookmaker_key` and `bookmaker_title`.

## OAuth backend prebuild

The complete v1.1.2 archive now includes an additive OAuth backend foundation:

- Provider-neutral `users` and `auth_identities` persistence
- Identity-bound, rotating, hashed refresh sessions
- Google and Apple identity-token verification
- Signed Apple account-change notification verification
- JWK cache and key-rotation handling
- `/api/v1/auth/google`, `/apple`, `/apple/webhook`, `/refresh`, `/logout`, and `/me`
- Authenticated `DELETE /api/v1/auth/me` account deletion
- Typed `DELETE` confirmation and cross-platform token-storage helpers
- Mocked-provider tests and migration/state-preservation coverage

OAuth is deliberately disabled by default:

```env
MPIE_AUTH_ENABLED=false
```

No Apple private key, Google secret, provider token, or production session secret
is included. See [`OAUTH_SETUP.md`](OAUTH_SETUP.md). Existing v1.1.2 clients
continue using the development `X-MPIE-User-ID` header until authentication is
enabled and the provider authorization controls are wired. The account-deletion
UI and token-storage helpers are already present.

## Replace or install v1.1.2 on Ubuntu

See [`UBUNTU_UPDATE.md`](UBUNTU_UPDATE.md). The updater preserves `.env` files and everything in `backend/data/`, including watchlist, portfolio, and Playbook state, when a prior v1.1.2 directory is supplied through `--from`.

## Start the API

```bash
cd ~/MPIE-Mobile-v1.1.2
bash backend/start_api.sh
```

- Swagger UI: `http://localhost:8000/docs`
- OpenAPI JSON: `http://localhost:8000/openapi.json`
- Health: `http://localhost:8000/health`

## Start API and Expo together

```bash
cd ~/MPIE-Mobile-v1.1.2
pnpm dev:full
```

This starts:

- FastAPI on port 8000
- Expo web/Metro on port 8081 in LAN mode

The Expo launcher uses the project-local binary and does not route through Windows `npx` under WSL.

## Environment

Root `.env`:

```env
EXPO_PUBLIC_MPIE_API_URL=http://127.0.0.1:8000
EXPO_PUBLIC_MPIE_USER_ID=123e4567-e89b-12d3-a456-426614174000
```

Backend `backend/.env`:

```env
MPIE_DEMO_MODE=true
MPIE_CORS_ORIGINS=http://localhost:8081,http://localhost:19006
MPIE_DEFAULT_USER_ID=123e4567-e89b-12d3-a456-426614174000
MPIE_STATE_DB=./data/mpie_state.db
MPIE_MARKET_LIMIT=100
MPIE_MARKET_LOOKBACK_DAYS=30
MPIE_SIGNAL_LIMIT=50
MPIE_ODDS_STALE_SECONDS=300
CLICKHOUSE_HOST=localhost
CLICKHOUSE_PORT=8123
CLICKHOUSE_USER=default
CLICKHOUSE_PASSWORD=
CLICKHOUSE_DATABASE=mpie
CLICKHOUSE_SECURE=false
```

Host selection:

- Web or iOS simulator: `127.0.0.1`
- Android emulator: `10.0.2.2`
- Physical device on the same LAN: Windows/host LAN IP

## Market pricing API

```text
GET /api/v1/markets/{event_id}/prices?market_key={market_key}&outcome={outcome}
```

The response includes:

- Best bookmaker and best decimal odds
- Consensus decimal odds
- All current bookmaker quotes
- Quote freshness state
- Last-updated timestamp
- Difference from consensus

## OAuth account lifecycle API

```text
POST   /api/v1/auth/google
POST   /api/v1/auth/apple
POST   /api/v1/auth/apple/webhook
POST   /api/v1/auth/refresh
POST   /api/v1/auth/logout
GET    /api/v1/auth/me
DELETE /api/v1/auth/me
```

Settings requires the exact phrase `DELETE` before sending an authenticated
account-deletion request. Apple account notifications detach Apple while other
identities remain, and delete the full MPIE user only when Apple was the final
identity.

## Playbook API

```text
GET    /api/v1/playbook
POST   /api/v1/playbook
GET    /api/v1/playbook/{entry_id}
PATCH  /api/v1/playbook/{entry_id}
DELETE /api/v1/playbook/{entry_id}
```

With OAuth disabled, every user-state operation is scoped by `X-MPIE-User-ID`. That header is a development identity boundary, not secure authentication. With OAuth enabled, protected user-state routes require an MPIE Bearer access token.

## Validation

```bash
node scripts/validate-project.mjs
backend/.venv/bin/python backend/scripts/validate_backend.py
cd backend && .venv/bin/python -m unittest discover -s tests -v
cd ..
pnpm check
pnpm lint
pnpm test
bash scripts/ubuntu_smoke_test.sh
```

The smoke test verifies live market-price retrieval, sportsbook attribution on tracked positions, and Playbook persistence across an API restart.

## Architecture

- `app/(tabs)/playbook.tsx` — Playbook list and Markdown editor
- `app/game/[id].tsx` — bookmaker comparison, selected-book tracking, and model provenance
- `app/methodology.tsx`, `app/data-provenance.tsx`, `app/privacy.tsx` — functional product disclosure pages
- `components/mpie/markdown-preview.tsx` — safe native Markdown preview
- `lib/playbook-draft.ts` — local draft persistence
- `lib/mpie-api.ts` — typed REST client
- `lib/mpie-auth.ts` — SecureStore/localStorage session persistence and sign-out
- `app/(auth)/login.tsx` — valid post-deletion landing route
- `backend/app/main.py` — FastAPI contract
- `backend/app/repository.py` — bounded ClickHouse pricing and analytical reads
- `backend/app/state.py` — parameterized SQLite persistence and migrations
- `backend/sql/` — existing ClickHouse analytical schema, unchanged

## Security boundary

`X-MPIE-User-ID` remains available only while `MPIE_AUTH_ENABLED=false`. The OAuth prebuild verifies provider identity tokens and issues revocable MPIE sessions, but production exposure still requires real provider clients, secure secret storage,
provider authorization UI, access-token refresh integration, rate limiting,
account-linking UX, Apple provider-token revocation, and operational review.

## Product disclaimer

MPIE surfaces analytical signals rather than guaranteed outcomes. No sportsbook account, payment rail, or wagering execution path is included.
