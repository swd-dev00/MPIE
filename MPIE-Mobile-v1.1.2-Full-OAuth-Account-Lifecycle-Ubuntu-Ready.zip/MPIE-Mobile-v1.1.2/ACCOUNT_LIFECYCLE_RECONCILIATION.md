# MPIE Mobile v1.1.2 — Account Lifecycle Reconciliation

This table reconciles the typed-DELETE mobile flow and Apple server-to-server
notification behavior against the complete OAuth-prebuilt v1.1.2 archive.

| File | Action | Reconciliation |
|---|---|---|
| `app/(tabs)/settings.tsx` | Merge | Preserve all existing Settings destinations and add the cross-platform typed `DELETE` modal. |
| `app/_layout.tsx` | Merge | Preserve existing routes and register the `(auth)` route group. |
| `app/(auth)/_layout.tsx` | Add | Add the auth route group layout. |
| `app/(auth)/login.tsx` | Add | Add a valid post-deletion landing page while provider clients remain disabled. |
| `lib/mpie-auth.ts` | Add | Add cross-platform SecureStore/localStorage token access, session storage, and sign-out cleanup. |
| `backend/app/models.py` | Merge | Add `AppleWebhookPayload`; preserve all market, portfolio, Playbook, and OAuth models. |
| `backend/app/main.py` | Merge | Add `DELETE /api/v1/auth/me` and `POST /api/v1/auth/apple/webhook`. |
| `backend/app/auth/apple.py` | Merge | Add signed Apple notification verification using the existing JWK cache. |
| `backend/app/auth/service.py` | Merge | Bind new sessions to provider identities; add account deletion and idempotent Apple event processing. |
| `backend/app/state.py` | Merge | Add identity-scoped session migration, revocation helpers, conditional identity/user deletion, and audit de-identification support. |
| `backend/tests/test_oauth_apple.py` | Merge | Add notification signature and five webhook behavior cases. |
| `backend/tests/test_auth_state.py` | Merge | Add identity-session revocation and user-state cascade tests. |
| `backend/tests/test_auth_api_contract.py` | Replace with superset | Preserve OAuth-disabled tests and add webhook acknowledgement plus authenticated delete-account API tests. |
| `tests/settings-navigation.test.ts` | Merge | Add static regression checks for typed `DELETE`, auth storage, and the valid login destination. |
| `scripts/validate-project.mjs` | Merge | Increase required deliverables and enforce account-deletion and Apple lifecycle tokens. |
| `backend/scripts/validate_backend.py` | Merge | Validate webhook verification, lifecycle API routes, state helpers, and the intentionally changed model hash. |
| Product/OAuth documentation | Merge | Update routes, data retention disclosure, test matrix, setup steps, and rollback notes. |
| ClickHouse schema and analytics | Skip | No analytical schema change is required for this account-lifecycle revision. |
| Existing Playbook, markets, watchlist, portfolio, and Settings pages | Skip | Preserve unchanged functionality. |
| Legacy generated server scaffolding | Skip | No new dependency on the unused tRPC/Drizzle server is introduced. |
| Files to delete | None | No current v1.1.2 source file must be removed for this revision. |

## Locked behavior

- User-initiated deletion requires an exact typed `DELETE` phrase.
- User-initiated deletion removes the internal MPIE user, sessions, identities,
  watchlist, portfolio positions, and Playbook entries.
- Apple `consent-revoked` detaches only the Apple identity and revokes sessions
  attributable to that identity.
- Apple `account-delete` detaches Apple; it fully deletes the MPIE user only when
  no other identity remains.
- Repeated Apple notifications are safe no-ops after the first successful mutation.
- Invalid signed notifications are logged and acknowledged with HTTP 200 as
  `{"status":"ignored"}`.
