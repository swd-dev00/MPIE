import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createContext, useContext, useMemo } from "react";

import {
  games as demoGames,
  portfolioPositions as demoPortfolio,
  pressureSignals as demoSignals,
  type MpieGame,
  type PortfolioPosition,
  type PressureSignal,
} from "@/constants/mpie-data";
import {
  isMpieApiConfigured,
  loadGames,
  loadHealth,
  loadPortfolio,
  loadSignals,
  type FeedSource,
} from "@/lib/mpie-api";

type MpieDataValue = {
  games: MpieGame[];
  signals: PressureSignal[];
  portfolioPositions: PortfolioPosition[];
  source: FeedSource;
  sourceLabel: string;
  backendMode?: "demo" | "clickhouse";
  isRefreshing: boolean;
  errorMessage?: string;
  refresh: () => Promise<void>;
  findGameById: (id: string | string[] | undefined) => MpieGame | undefined;
};

const MpieDataContext = createContext<MpieDataValue | null>(null);

export function MpieDataProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const refreshInterval = isMpieApiConfigured() ? 30_000 : false;

  const healthQuery = useQuery({
    queryKey: ["mpie", "health"],
    queryFn: loadHealth,
    enabled: isMpieApiConfigured(),
    refetchInterval: refreshInterval,
    staleTime: 15_000,
  });

  const gamesQuery = useQuery({
    queryKey: ["mpie", "games"],
    queryFn: loadGames,
    placeholderData: { items: demoGames, source: "demo" },
    refetchInterval: refreshInterval,
    staleTime: 15_000,
  });
  const signalsQuery = useQuery({
    queryKey: ["mpie", "signals"],
    queryFn: loadSignals,
    placeholderData: { items: demoSignals, source: "demo" },
    refetchInterval: refreshInterval,
    staleTime: 15_000,
  });
  const portfolioQuery = useQuery({
    queryKey: ["mpie", "portfolio"],
    queryFn: loadPortfolio,
    placeholderData: { items: demoPortfolio, source: "demo" },
    refetchInterval: refreshInterval,
    staleTime: 15_000,
  });

  const value = useMemo<MpieDataValue>(() => {
    const gameFeed = gamesQuery.data ?? { items: [], source: "demo" as const };
    const signalFeed = signalsQuery.data ?? { items: [], source: "demo" as const };
    const portfolioFeed = portfolioQuery.data ?? { items: [], source: "demo" as const };
    const source: FeedSource =
      gameFeed.source === "api" && signalFeed.source === "api" && portfolioFeed.source === "api"
        ? "api"
        : "demo";
    const errors = [gameFeed.error, signalFeed.error, portfolioFeed.error].filter(Boolean);
    const backendMode = healthQuery.data?.mode;
    const sourceLabel =
      source !== "api"
        ? "Demonstration fallback"
        : backendMode === "clickhouse"
          ? "API connected · ClickHouse live"
          : backendMode === "demo"
            ? "API connected · Demo analytics"
            : "API connected · mode unavailable";

    return {
      games: gameFeed.items,
      signals: signalFeed.items,
      portfolioPositions: portfolioFeed.items,
      source,
      sourceLabel,
      backendMode,
      isRefreshing:
        gamesQuery.isFetching ||
        signalsQuery.isFetching ||
        portfolioQuery.isFetching ||
        healthQuery.isFetching,
      errorMessage: errors.length ? errors.join(" · ") : undefined,
      refresh: async () => {
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ["mpie", "games"] }),
          queryClient.invalidateQueries({ queryKey: ["mpie", "signals"] }),
          queryClient.invalidateQueries({ queryKey: ["mpie", "portfolio"] }),
          queryClient.invalidateQueries({ queryKey: ["mpie", "health"] }),
        ]);
      },
      findGameById: (id) => {
        const normalized = Array.isArray(id) ? id[0] : id;
        return gameFeed.items.find((game) => game.id === normalized);
      },
    };
  }, [gamesQuery.data, gamesQuery.isFetching, healthQuery.data, healthQuery.isFetching, portfolioQuery.data, portfolioQuery.isFetching, queryClient, signalsQuery.data, signalsQuery.isFetching]);

  return <MpieDataContext.Provider value={value}>{children}</MpieDataContext.Provider>;
}

export function useMpieData() {
  const value = useContext(MpieDataContext);
  if (!value) throw new Error("useMpieData must be used inside MpieDataProvider");
  return value;
}
