import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

const ACCESS_TOKEN_KEY = "mpie.auth.accessToken";
const REFRESH_TOKEN_KEY = "mpie.auth.refreshToken";
const API_URL = process.env.EXPO_PUBLIC_MPIE_API_URL ?? "http://localhost:8000";

type AuthSession = {
  accessToken: string;
  refreshToken: string;
};

async function readValue(key: string): Promise<string | null> {
  if (Platform.OS === "web") {
    return typeof window === "undefined" ? null : window.localStorage.getItem(key);
  }
  return SecureStore.getItemAsync(key);
}

async function writeValue(key: string, value: string): Promise<void> {
  if (Platform.OS === "web") {
    if (typeof window !== "undefined") window.localStorage.setItem(key, value);
    return;
  }
  await SecureStore.setItemAsync(key, value);
}

async function removeValue(key: string): Promise<void> {
  if (Platform.OS === "web") {
    if (typeof window !== "undefined") window.localStorage.removeItem(key);
    return;
  }
  await SecureStore.deleteItemAsync(key);
}

export function getStoredJwt(): Promise<string | null> {
  return readValue(ACCESS_TOKEN_KEY);
}

export function getStoredRefreshToken(): Promise<string | null> {
  return readValue(REFRESH_TOKEN_KEY);
}

export async function storeAuthSession(session: AuthSession): Promise<void> {
  await Promise.all([
    writeValue(ACCESS_TOKEN_KEY, session.accessToken),
    writeValue(REFRESH_TOKEN_KEY, session.refreshToken),
  ]);
}

export async function clearStoredAuth(): Promise<void> {
  await Promise.all([removeValue(ACCESS_TOKEN_KEY), removeValue(REFRESH_TOKEN_KEY)]);
}

export async function signOut(options: { notifyServer?: boolean } = {}): Promise<void> {
  const notifyServer = options.notifyServer ?? true;
  const refreshToken = await getStoredRefreshToken();

  try {
    if (notifyServer && refreshToken) {
      await fetch(`${API_URL}/api/v1/auth/logout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken }),
      });
    }
  } finally {
    await clearStoredAuth();
  }
}
