export type MarkdownBlock =
  | { type: "heading"; level: 1 | 2 | 3; text: string }
  | { type: "paragraph"; text: string }
  | { type: "bullet"; items: string[] }
  | { type: "ordered"; items: string[] }
  | { type: "task"; items: { checked: boolean; text: string }[] }
  | { type: "quote"; text: string }
  | { type: "code"; code: string }
  | { type: "rule" };

const headingPattern = /^(#{1,3})\s+(.+)$/;
const taskPattern = /^[-*+]\s+\[([ xX])\]\s+(.+)$/;
const bulletPattern = /^[-*+]\s+(.+)$/;
const orderedPattern = /^\d+[.)]\s+(.+)$/;
const quotePattern = /^>\s?(.*)$/;
const rulePattern = /^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/;

export function parseMarkdownBlocks(markdown: string): MarkdownBlock[] {
  const lines = markdown.replace(/\r\n?/g, "\n").split("\n");
  const blocks: MarkdownBlock[] = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];

    if (!line.trim()) {
      index += 1;
      continue;
    }

    if (line.trimStart().startsWith("```")) {
      const code: string[] = [];
      index += 1;
      while (index < lines.length && !lines[index].trimStart().startsWith("```")) {
        code.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) index += 1;
      blocks.push({ type: "code", code: code.join("\n") });
      continue;
    }

    const heading = line.match(headingPattern);
    if (heading) {
      blocks.push({
        type: "heading",
        level: heading[1].length as 1 | 2 | 3,
        text: heading[2].trim(),
      });
      index += 1;
      continue;
    }

    if (rulePattern.test(line)) {
      blocks.push({ type: "rule" });
      index += 1;
      continue;
    }

    const task = line.match(taskPattern);
    if (task) {
      const items: { checked: boolean; text: string }[] = [];
      while (index < lines.length) {
        const match = lines[index].match(taskPattern);
        if (!match) break;
        items.push({ checked: match[1].toLowerCase() === "x", text: match[2].trim() });
        index += 1;
      }
      blocks.push({ type: "task", items });
      continue;
    }

    const bullet = line.match(bulletPattern);
    if (bullet) {
      const items: string[] = [];
      while (index < lines.length) {
        const match = lines[index].match(bulletPattern);
        if (!match || taskPattern.test(lines[index])) break;
        items.push(match[1].trim());
        index += 1;
      }
      blocks.push({ type: "bullet", items });
      continue;
    }

    const ordered = line.match(orderedPattern);
    if (ordered) {
      const items: string[] = [];
      while (index < lines.length) {
        const match = lines[index].match(orderedPattern);
        if (!match) break;
        items.push(match[1].trim());
        index += 1;
      }
      blocks.push({ type: "ordered", items });
      continue;
    }

    const quote = line.match(quotePattern);
    if (quote) {
      const quoteLines: string[] = [];
      while (index < lines.length) {
        const match = lines[index].match(quotePattern);
        if (!match) break;
        quoteLines.push(match[1]);
        index += 1;
      }
      blocks.push({ type: "quote", text: quoteLines.join("\n").trim() });
      continue;
    }

    const paragraph: string[] = [];
    while (index < lines.length && lines[index].trim()) {
      const candidate = lines[index];
      if (
        paragraph.length > 0 &&
        (candidate.trimStart().startsWith("```") ||
          headingPattern.test(candidate) ||
          taskPattern.test(candidate) ||
          bulletPattern.test(candidate) ||
          orderedPattern.test(candidate) ||
          quotePattern.test(candidate) ||
          rulePattern.test(candidate))
      ) {
        break;
      }
      paragraph.push(candidate.trim());
      index += 1;
    }
    blocks.push({ type: "paragraph", text: paragraph.join("\n") });
  }

  return blocks;
}

export function markdownExcerpt(markdown: string, maxLength = 150): string {
  const text = markdown
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/^\s*>\s?/gm, "")
    .replace(/^\s*[-*+]\s+\[[ xX]\]\s+/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/[*_~`]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`;
}

export function isSafeMarkdownLink(value: string): boolean {
  return /^(https?:|mailto:)/i.test(value.trim());
}
