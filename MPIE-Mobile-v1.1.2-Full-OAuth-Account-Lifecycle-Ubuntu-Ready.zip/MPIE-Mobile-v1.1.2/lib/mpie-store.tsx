import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import { addRemoteWatchlistEvent, loadRemoteWatchlist, removeRemoteWatchlistEvent } from "@/lib/mpie-api";

const STORAGE_KEY = "mpie:mobile-preferences";
const PENDING_WATCHLIST_KEY = "mpie:pending-watchlist-operations";
const DEFAULT_SAVED_GAME_IDS = ["bos-ny-0710", "la-sf-0711"];

type RiskProfile = "Conservative" | "Balanced" | "Aggressive";
type WatchlistAction = "add" | "remove";
type PendingWatchlistOperations = Record<string, WatchlistAction>;

type StoreValue = {
  savedGameIds: string[];
  bankroll: number;
  riskProfile: RiskProfile;
  notificationsEnabled: boolean;
  isHydrated: boolean;
  watchlistPendingCount: number;
  watchlistSyncError?: string;
  toggleSavedGame: (id: string) => void;
  retryWatchlistSync: () => void;
  setBankroll: (value: number) => void;
  setRiskProfile: (value: RiskProfile) => void;
  setNotificationsEnabled: (value: boolean) => void;
};

const MpieStoreContext = createContext<StoreValue | null>(null);

function normalizeIds(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((item): item is string => typeof item === "string" && item.length > 0))];
}

function normalizePendingOperations(value: unknown): PendingWatchlistOperations {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(
    Object.entries(value).filter(
      (entry): entry is [string, WatchlistAction] =>
        entry[0].length > 0 && (entry[1] === "add" || entry[1] === "remove"),
    ),
  );
}

function applyPendingOperations(
  ids: string[],
  operations: PendingWatchlistOperations,
): string[] {
  const result = new Set(ids);
  for (const [eventId, action] of Object.entries(operations)) {
    if (action === "add") result.add(eventId);
    else result.delete(eventId);
  }
  return [...result];
}

export function MpieStoreProvider({ children }: { children: React.ReactNode }) {
  const [savedGameIds, setSavedGameIds] = useState<string[]>(DEFAULT_SAVED_GAME_IDS);
  const [bankroll, setBankroll] = useState(2500);
  const [riskProfile, setRiskProfile] = useState<RiskProfile>("Balanced");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [isHydrated, setIsHydrated] = useState(false);
  const [pendingWatchlistOperations, setPendingWatchlistOperations] =
    useState<PendingWatchlistOperations>({});
  const [watchlistSyncError, setWatchlistSyncError] = useState<string>();
  const [retryNonce, setRetryNonce] = useState(0);
  const syncingRef = useRef(false);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryDelayRef = useRef(5_000);

  useEffect(() => {
    let active = true;

    async function hydrate() {
      let localSavedIds = DEFAULT_SAVED_GAME_IDS;
      let hasPersistedWatchlist = false;
      let pendingOperations: PendingWatchlistOperations = {};

      try {
        const [rawPreferences, rawPending] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(PENDING_WATCHLIST_KEY),
        ]);

        if (rawPreferences) {
          const parsed = JSON.parse(rawPreferences) as Partial<{
            savedGameIds: string[];
            bankroll: number;
            riskProfile: RiskProfile;
            notificationsEnabled: boolean;
          }>;
          if (Array.isArray(parsed.savedGameIds)) {
            localSavedIds = normalizeIds(parsed.savedGameIds);
            hasPersistedWatchlist = true;
          }
          if (typeof parsed.bankroll === "number") setBankroll(parsed.bankroll);
          if (parsed.riskProfile) setRiskProfile(parsed.riskProfile);
          if (typeof parsed.notificationsEnabled === "boolean") {
            setNotificationsEnabled(parsed.notificationsEnabled);
          }
        }

        if (rawPending) {
          pendingOperations = normalizePendingOperations(JSON.parse(rawPending));
        }
      } catch (error) {
        syncingRef.current = false;
        setWatchlistSyncError(
          error instanceof Error ? `Local state could not be read: ${error.message}` : "Local state could not be read.",
        );
      }

      let reconciledIds = localSavedIds;
      try {
        const remoteWatchlist = await loadRemoteWatchlist();
        if (remoteWatchlist !== null) {
          const remoteIds = normalizeIds(remoteWatchlist);
          if (hasPersistedWatchlist) {
            // Preserve explicit local saves and additions made from another
            // client. Pending removals are applied afterward so they win.
            reconciledIds = [...new Set([...localSavedIds, ...remoteIds])];
            for (const localId of localSavedIds) {
              if (!remoteIds.includes(localId) && !pendingOperations[localId]) {
                pendingOperations[localId] = "add";
              }
            }
          } else {
            // On a true first launch, the server is authoritative; an empty
            // remote watchlist must not be replaced by demonstration defaults.
            reconciledIds = remoteIds;
          }
        }
      } catch (error) {
        syncingRef.current = false;
        setWatchlistSyncError(
          error instanceof Error ? `Watchlist sync unavailable: ${error.message}` : "Watchlist sync unavailable.",
        );
      }

      reconciledIds = applyPendingOperations(reconciledIds, pendingOperations);
      if (!active) return;
      setSavedGameIds(reconciledIds);
      setPendingWatchlistOperations(pendingOperations);
      setIsHydrated(true);
    }

    void hydrate();
    return () => {
      active = false;
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    AsyncStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ savedGameIds, bankroll, riskProfile, notificationsEnabled }),
    ).catch((error: unknown) => {
      setWatchlistSyncError(
        error instanceof Error ? `Local preferences could not be saved: ${error.message}` : "Local preferences could not be saved.",
      );
    });
  }, [bankroll, isHydrated, notificationsEnabled, riskProfile, savedGameIds]);

  useEffect(() => {
    if (!isHydrated) return;
    AsyncStorage.setItem(PENDING_WATCHLIST_KEY, JSON.stringify(pendingWatchlistOperations)).catch(
      (error: unknown) => {
        setWatchlistSyncError(
          error instanceof Error ? `Pending sync state could not be saved: ${error.message}` : "Pending sync state could not be saved.",
        );
      },
    );
  }, [isHydrated, pendingWatchlistOperations]);

  useEffect(() => {
    if (!isHydrated || syncingRef.current) return;
    const operations = Object.entries(pendingWatchlistOperations) as [string, WatchlistAction][];
    const nextOperation = operations[0];
    if (!nextOperation) return;

    const [eventId, action] = nextOperation;
    syncingRef.current = true;

    async function flushOne() {
      try {
        if (action === "add") await addRemoteWatchlistEvent(eventId);
        else await removeRemoteWatchlistEvent(eventId);

        syncingRef.current = false;
        retryDelayRef.current = 5_000;
        setWatchlistSyncError(undefined);
        setPendingWatchlistOperations((current) => {
          if (current[eventId] !== action) return current;
          const next = { ...current };
          delete next[eventId];
          return next;
        });
        // Guarantee another pass when the user changed this event while the
        // previous network operation was still in flight.
        setRetryNonce((value) => value + 1);
      } catch (error) {
        syncingRef.current = false;
        setWatchlistSyncError(
          error instanceof Error ? `Watchlist sync failed: ${error.message}` : "Watchlist sync failed.",
        );
        if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
        const delay = retryDelayRef.current;
        retryTimerRef.current = setTimeout(() => setRetryNonce((value) => value + 1), delay);
        retryDelayRef.current = Math.min(delay * 2, 60_000);
      }
    }

    void flushOne();
  }, [isHydrated, pendingWatchlistOperations, retryNonce]);

  const toggleSavedGame = useCallback((id: string) => {
    setSavedGameIds((current) => {
      const isSaved = current.includes(id);
      setPendingWatchlistOperations((operations) => ({
        ...operations,
        [id]: isSaved ? "remove" : "add",
      }));
      return isSaved ? current.filter((gameId) => gameId !== id) : [...current, id];
    });
  }, []);

  const retryWatchlistSync = useCallback(() => {
    if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    retryDelayRef.current = 5_000;
    setPendingWatchlistOperations((current) => {
      if (Object.keys(current).length) return current;
      return Object.fromEntries(savedGameIds.map((eventId) => [eventId, "add" as const]));
    });
    setRetryNonce((value) => value + 1);
  }, [savedGameIds]);

  const value = useMemo(
    () => ({
      savedGameIds,
      bankroll,
      riskProfile,
      notificationsEnabled,
      isHydrated,
      watchlistPendingCount: Object.keys(pendingWatchlistOperations).length,
      watchlistSyncError,
      toggleSavedGame,
      retryWatchlistSync,
      setBankroll,
      setRiskProfile,
      setNotificationsEnabled,
    }),
    [
      bankroll,
      isHydrated,
      notificationsEnabled,
      pendingWatchlistOperations,
      retryWatchlistSync,
      riskProfile,
      savedGameIds,
      toggleSavedGame,
      watchlistSyncError,
    ],
  );

  return <MpieStoreContext.Provider value={value}>{children}</MpieStoreContext.Provider>;
}

export function useMpieStore() {
  const value = useContext(MpieStoreContext);
  if (!value) throw new Error("useMpieStore must be used inside MpieStoreProvider");
  return value;
}
