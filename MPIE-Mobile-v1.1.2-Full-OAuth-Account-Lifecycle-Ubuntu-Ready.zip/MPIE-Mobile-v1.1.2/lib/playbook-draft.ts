import AsyncStorage from "@react-native-async-storage/async-storage";

function playbookDraftKey(userId: string, entryId: string | null) {
  return `mpie:playbook:draft:v1:${userId}:${entryId ?? "new"}`;
}

export type PlaybookDraft = {
  entryId: string | null;
  title: string;
  bodyMarkdown: string;
  updatedAt: string;
};

function isPlaybookDraft(value: unknown): value is PlaybookDraft {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<PlaybookDraft>;
  return (
    (candidate.entryId === null || typeof candidate.entryId === "string") &&
    typeof candidate.title === "string" &&
    typeof candidate.bodyMarkdown === "string" &&
    typeof candidate.updatedAt === "string"
  );
}

export async function loadPlaybookDraft(
  userId: string,
  entryId: string | null,
): Promise<PlaybookDraft | null> {
  const key = playbookDraftKey(userId, entryId);
  const raw = await AsyncStorage.getItem(key);
  if (!raw) return null;

  try {
    const parsed: unknown = JSON.parse(raw);
    if (isPlaybookDraft(parsed) && parsed.entryId === entryId) return parsed;
  } catch {
    // Invalid local state is removed below.
  }

  await AsyncStorage.removeItem(key);
  return null;
}

export async function savePlaybookDraft(
  userId: string,
  draft: Omit<PlaybookDraft, "updatedAt">,
): Promise<PlaybookDraft> {
  const persisted: PlaybookDraft = {
    ...draft,
    updatedAt: new Date().toISOString(),
  };
  await AsyncStorage.setItem(
    playbookDraftKey(userId, draft.entryId),
    JSON.stringify(persisted),
  );
  return persisted;
}

export async function clearPlaybookDraft(
  userId: string,
  entryId: string | null,
): Promise<void> {
  await AsyncStorage.removeItem(playbookDraftKey(userId, entryId));
}
