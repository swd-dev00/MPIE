import {
  games as demoGames,
  marketPriceBoards,
  portfolioPositions as demoPortfolio,
  pressureSignals as demoSignals,
  type MarketPriceResponse,
  type MpieGame,
  type MpieHealth,
  type MpiePlaybookEntry,
  type PortfolioPosition,
  type PressureSignal,
} from "@/constants/mpie-data";

export type FeedSource = "api" | "demo";

export type FeedResult<T> = {
  items: T;
  source: FeedSource;
  error?: string;
};

const API_BASE_URL = (process.env.EXPO_PUBLIC_MPIE_API_URL ?? "").replace(/\/$/, "");
const USER_ID = process.env.EXPO_PUBLIC_MPIE_USER_ID ?? "123e4567-e89b-12d3-a456-426614174000";

export function isMpieApiConfigured() {
  return API_BASE_URL.length > 0;
}

export function getMpieApiBaseUrl() {
  return API_BASE_URL;
}

export function getMpieUserId() {
  return USER_ID;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (!API_BASE_URL) throw new Error("EXPO_PUBLIC_MPIE_API_URL is not configured.");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "X-MPIE-User-ID": USER_ID,
        ...((options.headers as Record<string, string> | undefined) ?? {}),
      },
    });

    if (response.status === 204) return undefined as T;
    const body = await response.text();
    if (!response.ok) {
      let message = body || `Request failed with status ${response.status}.`;
      try {
        const parsed = JSON.parse(body) as { detail?: string; message?: string };
        message = parsed.detail ?? parsed.message ?? message;
      } catch {
        // Preserve the plain-text response.
      }
      throw new Error(message);
    }
    return (body ? JSON.parse(body) : undefined) as T;
  } finally {
    clearTimeout(timeout);
  }
}

async function withFallback<T>(
  loader: () => Promise<T>,
  fallback: T,
): Promise<FeedResult<T>> {
  if (!isMpieApiConfigured()) return { items: fallback, source: "demo" };
  try {
    return { items: await loader(), source: "api" };
  } catch (error) {
    return {
      items: fallback,
      source: "demo",
      error: error instanceof Error ? error.message : "Unknown MPIE API error.",
    };
  }
}

export function loadGames(): Promise<FeedResult<MpieGame[]>> {
  return withFallback(() => request<MpieGame[]>("/api/v1/markets"), demoGames);
}

export async function loadHealth(): Promise<MpieHealth | null> {
  if (!isMpieApiConfigured()) return null;
  return request<MpieHealth>("/health");
}

export function loadSignals(): Promise<FeedResult<PressureSignal[]>> {
  return withFallback(() => request<PressureSignal[]>("/api/v1/signals"), demoSignals);
}

export function loadPortfolio(): Promise<FeedResult<PortfolioPosition[]>> {
  return withFallback(() => request<PortfolioPosition[]>("/api/v1/portfolio"), demoPortfolio);
}

export function loadMarketPrices(
  eventId: string,
  marketKey: string,
  outcome: string,
): Promise<FeedResult<MarketPriceResponse | null>> {
  const fallback = marketPriceBoards[eventId] ?? null;
  const query = `market_key=${encodeURIComponent(marketKey)}&outcome=${encodeURIComponent(outcome)}`;
  return withFallback(
    () => request<MarketPriceResponse>(
      `/api/v1/markets/${encodeURIComponent(eventId)}/prices?${query}`,
    ),
    fallback,
  );
}

export async function loadRemoteWatchlist(): Promise<string[] | null> {
  if (!isMpieApiConfigured()) return null;
  const response = await request<{ eventIds: string[] }>("/api/v1/watchlist");
  return response.eventIds;
}

export async function addRemoteWatchlistEvent(eventId: string): Promise<void> {
  if (!isMpieApiConfigured()) return;
  await request(`/api/v1/watchlist/${encodeURIComponent(eventId)}`, { method: "POST" });
}

export async function removeRemoteWatchlistEvent(eventId: string): Promise<void> {
  if (!isMpieApiConfigured()) return;
  await request(`/api/v1/watchlist/${encodeURIComponent(eventId)}`, { method: "DELETE" });
}

export async function createRemotePosition(input: {
  eventId: string;
  marketKey: string;
  outcome: string;
  label?: string;
  game?: string;
  entryPrice: number;
  sizeUnits: number;
  bookmakerKey?: string;
  bookmakerTitle?: string;
  status?: string;
}): Promise<PortfolioPosition | null> {
  if (!isMpieApiConfigured()) return null;
  return request<PortfolioPosition>("/api/v1/portfolio/positions", {
    method: "POST",
    body: JSON.stringify(input),
  });
}


export async function loadPlaybookEntries(): Promise<MpiePlaybookEntry[]> {
  return request<MpiePlaybookEntry[]>("/api/v1/playbook");
}

export async function createPlaybookEntry(
  input: { title: string; bodyMarkdown: string },
): Promise<MpiePlaybookEntry> {
  return request<MpiePlaybookEntry>("/api/v1/playbook", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function updatePlaybookEntry(
  entryId: string,
  input: { title?: string; bodyMarkdown?: string },
): Promise<MpiePlaybookEntry> {
  return request<MpiePlaybookEntry>(`/api/v1/playbook/${encodeURIComponent(entryId)}`, {
    method: "PATCH",
    body: JSON.stringify(input),
  });
}

export async function deletePlaybookEntry(entryId: string): Promise<void> {
  return request(`/api/v1/playbook/${encodeURIComponent(entryId)}`, { method: "DELETE" });
}
