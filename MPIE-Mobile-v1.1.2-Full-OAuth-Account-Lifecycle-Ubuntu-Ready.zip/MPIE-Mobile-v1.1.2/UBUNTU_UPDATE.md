# MPIE Mobile v1.1.2 — Ubuntu Update Guide

This package replaces or installs **MPIE Mobile v1.1.2** with Playbook, transparent market pricing, model provenance, and functional Settings product pages. It does not change the ClickHouse schema.

## What is preserved

When the installer is pointed at an existing v1.1.2 directory, it preserves:

- Root `.env`
- `backend/.env`
- Everything under `backend/data/`, including `mpie_state.db`

The SQLite migration adds nullable `bookmaker_key` and `bookmaker_title` columns to `portfolio_positions`. Existing watchlist, portfolio, and Playbook data remains intact.

## Stop the running stack

Stop `pnpm dev:full` with `Ctrl+C`, then clear any stale listeners:

```bash
sudo lsof -t -iTCP:8000 -sTCP:LISTEN | xargs -r kill
sudo lsof -t -iTCP:8081 -sTCP:LISTEN | xargs -r kill
```

## Install the release

Assuming the ZIP is in `C:\Downloads`, run the documented replacement block supplied with the delivery. It verifies the SHA-256 checksum, backs up any existing `~/MPIE-Mobile-v1.1.2` directory, extracts the new package, imports the prior v1.1.2 environment and state, and executes:

```bash
bash scripts/ubuntu_update.sh --from <existing-v1.1.2-backup>
```

For a clean installation with no prior v1.1.2 directory:

```bash
cd ~/MPIE-Mobile-v1.1.2
bash scripts/ubuntu_update.sh
```

The updater performs:

1. Environment and SQLite-state import when `--from` is provided.
2. Python 3.12/`uv` backend preparation.
3. Pinned backend dependency installation.
4. Node and pnpm verification.
5. Locked frontend dependency installation.
6. Project and backend structural validation.
7. The complete Python/API/repository/state/OAuth suite.
8. TypeScript checking, Expo linting, and Vitest.
9. A temporary live API test on port 18000 covering market prices, sportsbook attribution, and Playbook persistence.

The script stops on the first failure.

## Start v1.1.2

```bash
cd ~/MPIE-Mobile-v1.1.2
pnpm dev:full
```

Open:

- App: `http://localhost:8081/`
- API docs: `http://localhost:8000/docs`

For LAN access, use the Windows/host LAN address already configured in `.env` and Windows port forwarding.

Start only the API:

```bash
cd ~/MPIE-Mobile-v1.1.2
bash backend/start_api.sh
```

## Re-run verification

```bash
cd ~/MPIE-Mobile-v1.1.2
node scripts/validate-project.mjs
backend/.venv/bin/python backend/scripts/validate_backend.py
(
  cd backend
  .venv/bin/python -m unittest discover -s tests -v
)
pnpm check
pnpm lint
pnpm test
bash scripts/ubuntu_smoke_test.sh
```

## Verify the market feature

Open a game and confirm:

- The market card shows a sportsbook, best-price label, and bookmaker count.
- The game-detail page lists multiple sportsbooks.
- Active, stale, and suspended states are visible.
- Selecting a different active book changes the tracked entry price.
- The Portfolio row shows the selected sportsbook after tracking.
- Game detail shows the model version and calculation timestamp.
- Settings opens About, Methodology, Data Provenance, and Privacy pages.

## Settings navigation hotfix

The settings hotfix keeps the application version at v1.1.2 and replaces inert chevron rows with six verified destinations: Data source, Watchlist sync, About MPIE, Methodology, Data provenance, and Privacy. The protected updater preserves `.env`, `backend/.env`, SQLite state, Playbook entries, watchlist state, and portfolio positions.

## OAuth preservation and activation

The updater preserves `backend/.env`, so it will not silently enable authentication
or erase provider configuration. The complete release defaults to:

```env
MPIE_AUTH_ENABLED=false
```

Install and validate the release before entering provider client IDs or a session
secret. See `OAUTH_SETUP.md`. No Apple `.p8` file belongs inside the project tree
or release archive.
